
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00019117          	auipc	sp,0x19
    80000004:	de010113          	addi	sp,sp,-544 # 80018de0 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	5eb040ef          	jal	ra,80004e00 <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    8000001c:	1101                	addi	sp,sp,-32
    8000001e:	ec06                	sd	ra,24(sp)
    80000020:	e822                	sd	s0,16(sp)
    80000022:	e426                	sd	s1,8(sp)
    80000024:	e04a                	sd	s2,0(sp)
    80000026:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000028:	03451793          	slli	a5,a0,0x34
    8000002c:	e7a9                	bnez	a5,80000076 <kfree+0x5a>
    8000002e:	84aa                	mv	s1,a0
    80000030:	00021797          	auipc	a5,0x21
    80000034:	eb078793          	addi	a5,a5,-336 # 80020ee0 <end>
    80000038:	02f56f63          	bltu	a0,a5,80000076 <kfree+0x5a>
    8000003c:	47c5                	li	a5,17
    8000003e:	07ee                	slli	a5,a5,0x1b
    80000040:	02f57b63          	bgeu	a0,a5,80000076 <kfree+0x5a>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000044:	6605                	lui	a2,0x1
    80000046:	4585                	li	a1,1
    80000048:	104000ef          	jal	ra,8000014c <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    8000004c:	00008917          	auipc	s2,0x8
    80000050:	96490913          	addi	s2,s2,-1692 # 800079b0 <kmem>
    80000054:	854a                	mv	a0,s2
    80000056:	7b4050ef          	jal	ra,8000580a <acquire>
  r->next = kmem.freelist;
    8000005a:	01893783          	ld	a5,24(s2)
    8000005e:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000060:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000064:	854a                	mv	a0,s2
    80000066:	03d050ef          	jal	ra,800058a2 <release>
}
    8000006a:	60e2                	ld	ra,24(sp)
    8000006c:	6442                	ld	s0,16(sp)
    8000006e:	64a2                	ld	s1,8(sp)
    80000070:	6902                	ld	s2,0(sp)
    80000072:	6105                	addi	sp,sp,32
    80000074:	8082                	ret
    panic("kfree");
    80000076:	00007517          	auipc	a0,0x7
    8000007a:	f9a50513          	addi	a0,a0,-102 # 80007010 <etext+0x10>
    8000007e:	478050ef          	jal	ra,800054f6 <panic>

0000000080000082 <freerange>:
{
    80000082:	7179                	addi	sp,sp,-48
    80000084:	f406                	sd	ra,40(sp)
    80000086:	f022                	sd	s0,32(sp)
    80000088:	ec26                	sd	s1,24(sp)
    8000008a:	e84a                	sd	s2,16(sp)
    8000008c:	e44e                	sd	s3,8(sp)
    8000008e:	e052                	sd	s4,0(sp)
    80000090:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000092:	6785                	lui	a5,0x1
    80000094:	fff78493          	addi	s1,a5,-1 # fff <_entry-0x7ffff001>
    80000098:	94aa                	add	s1,s1,a0
    8000009a:	757d                	lui	a0,0xfffff
    8000009c:	8ce9                	and	s1,s1,a0
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    8000009e:	94be                	add	s1,s1,a5
    800000a0:	0095ec63          	bltu	a1,s1,800000b8 <freerange+0x36>
    800000a4:	892e                	mv	s2,a1
    kfree(p);
    800000a6:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000a8:	6985                	lui	s3,0x1
    kfree(p);
    800000aa:	01448533          	add	a0,s1,s4
    800000ae:	f6fff0ef          	jal	ra,8000001c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000b2:	94ce                	add	s1,s1,s3
    800000b4:	fe997be3          	bgeu	s2,s1,800000aa <freerange+0x28>
}
    800000b8:	70a2                	ld	ra,40(sp)
    800000ba:	7402                	ld	s0,32(sp)
    800000bc:	64e2                	ld	s1,24(sp)
    800000be:	6942                	ld	s2,16(sp)
    800000c0:	69a2                	ld	s3,8(sp)
    800000c2:	6a02                	ld	s4,0(sp)
    800000c4:	6145                	addi	sp,sp,48
    800000c6:	8082                	ret

00000000800000c8 <kinit>:
{
    800000c8:	1141                	addi	sp,sp,-16
    800000ca:	e406                	sd	ra,8(sp)
    800000cc:	e022                	sd	s0,0(sp)
    800000ce:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    800000d0:	00007597          	auipc	a1,0x7
    800000d4:	f4858593          	addi	a1,a1,-184 # 80007018 <etext+0x18>
    800000d8:	00008517          	auipc	a0,0x8
    800000dc:	8d850513          	addi	a0,a0,-1832 # 800079b0 <kmem>
    800000e0:	6aa050ef          	jal	ra,8000578a <initlock>
  freerange(end, (void*)PHYSTOP);
    800000e4:	45c5                	li	a1,17
    800000e6:	05ee                	slli	a1,a1,0x1b
    800000e8:	00021517          	auipc	a0,0x21
    800000ec:	df850513          	addi	a0,a0,-520 # 80020ee0 <end>
    800000f0:	f93ff0ef          	jal	ra,80000082 <freerange>
}
    800000f4:	60a2                	ld	ra,8(sp)
    800000f6:	6402                	ld	s0,0(sp)
    800000f8:	0141                	addi	sp,sp,16
    800000fa:	8082                	ret

00000000800000fc <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    800000fc:	1101                	addi	sp,sp,-32
    800000fe:	ec06                	sd	ra,24(sp)
    80000100:	e822                	sd	s0,16(sp)
    80000102:	e426                	sd	s1,8(sp)
    80000104:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000106:	00008497          	auipc	s1,0x8
    8000010a:	8aa48493          	addi	s1,s1,-1878 # 800079b0 <kmem>
    8000010e:	8526                	mv	a0,s1
    80000110:	6fa050ef          	jal	ra,8000580a <acquire>
  r = kmem.freelist;
    80000114:	6c84                	ld	s1,24(s1)
  if(r)
    80000116:	c485                	beqz	s1,8000013e <kalloc+0x42>
    kmem.freelist = r->next;
    80000118:	609c                	ld	a5,0(s1)
    8000011a:	00008517          	auipc	a0,0x8
    8000011e:	89650513          	addi	a0,a0,-1898 # 800079b0 <kmem>
    80000122:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000124:	77e050ef          	jal	ra,800058a2 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000128:	6605                	lui	a2,0x1
    8000012a:	4595                	li	a1,5
    8000012c:	8526                	mv	a0,s1
    8000012e:	01e000ef          	jal	ra,8000014c <memset>
  return (void*)r;
}
    80000132:	8526                	mv	a0,s1
    80000134:	60e2                	ld	ra,24(sp)
    80000136:	6442                	ld	s0,16(sp)
    80000138:	64a2                	ld	s1,8(sp)
    8000013a:	6105                	addi	sp,sp,32
    8000013c:	8082                	ret
  release(&kmem.lock);
    8000013e:	00008517          	auipc	a0,0x8
    80000142:	87250513          	addi	a0,a0,-1934 # 800079b0 <kmem>
    80000146:	75c050ef          	jal	ra,800058a2 <release>
  if(r)
    8000014a:	b7e5                	j	80000132 <kalloc+0x36>

000000008000014c <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    8000014c:	1141                	addi	sp,sp,-16
    8000014e:	e422                	sd	s0,8(sp)
    80000150:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000152:	ca19                	beqz	a2,80000168 <memset+0x1c>
    80000154:	87aa                	mv	a5,a0
    80000156:	1602                	slli	a2,a2,0x20
    80000158:	9201                	srli	a2,a2,0x20
    8000015a:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    8000015e:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000162:	0785                	addi	a5,a5,1
    80000164:	fee79de3          	bne	a5,a4,8000015e <memset+0x12>
  }
  return dst;
}
    80000168:	6422                	ld	s0,8(sp)
    8000016a:	0141                	addi	sp,sp,16
    8000016c:	8082                	ret

000000008000016e <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    8000016e:	1141                	addi	sp,sp,-16
    80000170:	e422                	sd	s0,8(sp)
    80000172:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000174:	ca05                	beqz	a2,800001a4 <memcmp+0x36>
    80000176:	fff6069b          	addiw	a3,a2,-1
    8000017a:	1682                	slli	a3,a3,0x20
    8000017c:	9281                	srli	a3,a3,0x20
    8000017e:	0685                	addi	a3,a3,1
    80000180:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000182:	00054783          	lbu	a5,0(a0)
    80000186:	0005c703          	lbu	a4,0(a1)
    8000018a:	00e79863          	bne	a5,a4,8000019a <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    8000018e:	0505                	addi	a0,a0,1
    80000190:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000192:	fed518e3          	bne	a0,a3,80000182 <memcmp+0x14>
  }

  return 0;
    80000196:	4501                	li	a0,0
    80000198:	a019                	j	8000019e <memcmp+0x30>
      return *s1 - *s2;
    8000019a:	40e7853b          	subw	a0,a5,a4
}
    8000019e:	6422                	ld	s0,8(sp)
    800001a0:	0141                	addi	sp,sp,16
    800001a2:	8082                	ret
  return 0;
    800001a4:	4501                	li	a0,0
    800001a6:	bfe5                	j	8000019e <memcmp+0x30>

00000000800001a8 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    800001a8:	1141                	addi	sp,sp,-16
    800001aa:	e422                	sd	s0,8(sp)
    800001ac:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    800001ae:	c205                	beqz	a2,800001ce <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    800001b0:	02a5e263          	bltu	a1,a0,800001d4 <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    800001b4:	1602                	slli	a2,a2,0x20
    800001b6:	9201                	srli	a2,a2,0x20
    800001b8:	00c587b3          	add	a5,a1,a2
{
    800001bc:	872a                	mv	a4,a0
      *d++ = *s++;
    800001be:	0585                	addi	a1,a1,1
    800001c0:	0705                	addi	a4,a4,1
    800001c2:	fff5c683          	lbu	a3,-1(a1)
    800001c6:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    800001ca:	fef59ae3          	bne	a1,a5,800001be <memmove+0x16>

  return dst;
}
    800001ce:	6422                	ld	s0,8(sp)
    800001d0:	0141                	addi	sp,sp,16
    800001d2:	8082                	ret
  if(s < d && s + n > d){
    800001d4:	02061693          	slli	a3,a2,0x20
    800001d8:	9281                	srli	a3,a3,0x20
    800001da:	00d58733          	add	a4,a1,a3
    800001de:	fce57be3          	bgeu	a0,a4,800001b4 <memmove+0xc>
    d += n;
    800001e2:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    800001e4:	fff6079b          	addiw	a5,a2,-1
    800001e8:	1782                	slli	a5,a5,0x20
    800001ea:	9381                	srli	a5,a5,0x20
    800001ec:	fff7c793          	not	a5,a5
    800001f0:	97ba                	add	a5,a5,a4
      *--d = *--s;
    800001f2:	177d                	addi	a4,a4,-1
    800001f4:	16fd                	addi	a3,a3,-1
    800001f6:	00074603          	lbu	a2,0(a4)
    800001fa:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    800001fe:	fee79ae3          	bne	a5,a4,800001f2 <memmove+0x4a>
    80000202:	b7f1                	j	800001ce <memmove+0x26>

0000000080000204 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000204:	1141                	addi	sp,sp,-16
    80000206:	e406                	sd	ra,8(sp)
    80000208:	e022                	sd	s0,0(sp)
    8000020a:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    8000020c:	f9dff0ef          	jal	ra,800001a8 <memmove>
}
    80000210:	60a2                	ld	ra,8(sp)
    80000212:	6402                	ld	s0,0(sp)
    80000214:	0141                	addi	sp,sp,16
    80000216:	8082                	ret

0000000080000218 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000218:	1141                	addi	sp,sp,-16
    8000021a:	e422                	sd	s0,8(sp)
    8000021c:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    8000021e:	ce11                	beqz	a2,8000023a <strncmp+0x22>
    80000220:	00054783          	lbu	a5,0(a0)
    80000224:	cf89                	beqz	a5,8000023e <strncmp+0x26>
    80000226:	0005c703          	lbu	a4,0(a1)
    8000022a:	00f71a63          	bne	a4,a5,8000023e <strncmp+0x26>
    n--, p++, q++;
    8000022e:	367d                	addiw	a2,a2,-1
    80000230:	0505                	addi	a0,a0,1
    80000232:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000234:	f675                	bnez	a2,80000220 <strncmp+0x8>
  if(n == 0)
    return 0;
    80000236:	4501                	li	a0,0
    80000238:	a809                	j	8000024a <strncmp+0x32>
    8000023a:	4501                	li	a0,0
    8000023c:	a039                	j	8000024a <strncmp+0x32>
  if(n == 0)
    8000023e:	ca09                	beqz	a2,80000250 <strncmp+0x38>
  return (uchar)*p - (uchar)*q;
    80000240:	00054503          	lbu	a0,0(a0)
    80000244:	0005c783          	lbu	a5,0(a1)
    80000248:	9d1d                	subw	a0,a0,a5
}
    8000024a:	6422                	ld	s0,8(sp)
    8000024c:	0141                	addi	sp,sp,16
    8000024e:	8082                	ret
    return 0;
    80000250:	4501                	li	a0,0
    80000252:	bfe5                	j	8000024a <strncmp+0x32>

0000000080000254 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000254:	1141                	addi	sp,sp,-16
    80000256:	e422                	sd	s0,8(sp)
    80000258:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    8000025a:	872a                	mv	a4,a0
    8000025c:	8832                	mv	a6,a2
    8000025e:	367d                	addiw	a2,a2,-1
    80000260:	01005963          	blez	a6,80000272 <strncpy+0x1e>
    80000264:	0705                	addi	a4,a4,1
    80000266:	0005c783          	lbu	a5,0(a1)
    8000026a:	fef70fa3          	sb	a5,-1(a4)
    8000026e:	0585                	addi	a1,a1,1
    80000270:	f7f5                	bnez	a5,8000025c <strncpy+0x8>
    ;
  while(n-- > 0)
    80000272:	86ba                	mv	a3,a4
    80000274:	00c05c63          	blez	a2,8000028c <strncpy+0x38>
    *s++ = 0;
    80000278:	0685                	addi	a3,a3,1
    8000027a:	fe068fa3          	sb	zero,-1(a3)
  while(n-- > 0)
    8000027e:	fff6c793          	not	a5,a3
    80000282:	9fb9                	addw	a5,a5,a4
    80000284:	010787bb          	addw	a5,a5,a6
    80000288:	fef048e3          	bgtz	a5,80000278 <strncpy+0x24>
  return os;
}
    8000028c:	6422                	ld	s0,8(sp)
    8000028e:	0141                	addi	sp,sp,16
    80000290:	8082                	ret

0000000080000292 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000292:	1141                	addi	sp,sp,-16
    80000294:	e422                	sd	s0,8(sp)
    80000296:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000298:	02c05363          	blez	a2,800002be <safestrcpy+0x2c>
    8000029c:	fff6069b          	addiw	a3,a2,-1
    800002a0:	1682                	slli	a3,a3,0x20
    800002a2:	9281                	srli	a3,a3,0x20
    800002a4:	96ae                	add	a3,a3,a1
    800002a6:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    800002a8:	00d58963          	beq	a1,a3,800002ba <safestrcpy+0x28>
    800002ac:	0585                	addi	a1,a1,1
    800002ae:	0785                	addi	a5,a5,1
    800002b0:	fff5c703          	lbu	a4,-1(a1)
    800002b4:	fee78fa3          	sb	a4,-1(a5)
    800002b8:	fb65                	bnez	a4,800002a8 <safestrcpy+0x16>
    ;
  *s = 0;
    800002ba:	00078023          	sb	zero,0(a5)
  return os;
}
    800002be:	6422                	ld	s0,8(sp)
    800002c0:	0141                	addi	sp,sp,16
    800002c2:	8082                	ret

00000000800002c4 <strlen>:

int
strlen(const char *s)
{
    800002c4:	1141                	addi	sp,sp,-16
    800002c6:	e422                	sd	s0,8(sp)
    800002c8:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    800002ca:	00054783          	lbu	a5,0(a0)
    800002ce:	cf91                	beqz	a5,800002ea <strlen+0x26>
    800002d0:	0505                	addi	a0,a0,1
    800002d2:	87aa                	mv	a5,a0
    800002d4:	4685                	li	a3,1
    800002d6:	9e89                	subw	a3,a3,a0
    800002d8:	00f6853b          	addw	a0,a3,a5
    800002dc:	0785                	addi	a5,a5,1
    800002de:	fff7c703          	lbu	a4,-1(a5)
    800002e2:	fb7d                	bnez	a4,800002d8 <strlen+0x14>
    ;
  return n;
}
    800002e4:	6422                	ld	s0,8(sp)
    800002e6:	0141                	addi	sp,sp,16
    800002e8:	8082                	ret
  for(n = 0; s[n]; n++)
    800002ea:	4501                	li	a0,0
    800002ec:	bfe5                	j	800002e4 <strlen+0x20>

00000000800002ee <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    800002ee:	1141                	addi	sp,sp,-16
    800002f0:	e406                	sd	ra,8(sp)
    800002f2:	e022                	sd	s0,0(sp)
    800002f4:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    800002f6:	2e1000ef          	jal	ra,80000dd6 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    800002fa:	00007717          	auipc	a4,0x7
    800002fe:	68670713          	addi	a4,a4,1670 # 80007980 <started>
  if(cpuid() == 0){
    80000302:	c51d                	beqz	a0,80000330 <main+0x42>
    while(started == 0)
    80000304:	431c                	lw	a5,0(a4)
    80000306:	2781                	sext.w	a5,a5
    80000308:	dff5                	beqz	a5,80000304 <main+0x16>
      ;
    __sync_synchronize();
    8000030a:	0ff0000f          	fence
    printf("hart %d starting\n", cpuid());
    8000030e:	2c9000ef          	jal	ra,80000dd6 <cpuid>
    80000312:	85aa                	mv	a1,a0
    80000314:	00007517          	auipc	a0,0x7
    80000318:	d2450513          	addi	a0,a0,-732 # 80007038 <etext+0x38>
    8000031c:	727040ef          	jal	ra,80005242 <printf>
    kvminithart();    // turn on paging
    80000320:	122000ef          	jal	ra,80000442 <kvminithart>
    trapinithart();   // install kernel trap vector
    80000324:	656010ef          	jal	ra,8000197a <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000328:	52c040ef          	jal	ra,80004854 <plicinithart>
  }

  scheduler();        
    8000032c:	793000ef          	jal	ra,800012be <scheduler>
    consoleinit();
    80000330:	63b040ef          	jal	ra,8000516a <consoleinit>
    printfinit();
    80000334:	1fc050ef          	jal	ra,80005530 <printfinit>
    printf("\n");
    80000338:	00007517          	auipc	a0,0x7
    8000033c:	d1050513          	addi	a0,a0,-752 # 80007048 <etext+0x48>
    80000340:	703040ef          	jal	ra,80005242 <printf>
    printf("xv6 kernel is booting\n");
    80000344:	00007517          	auipc	a0,0x7
    80000348:	cdc50513          	addi	a0,a0,-804 # 80007020 <etext+0x20>
    8000034c:	6f7040ef          	jal	ra,80005242 <printf>
    printf("\n");
    80000350:	00007517          	auipc	a0,0x7
    80000354:	cf850513          	addi	a0,a0,-776 # 80007048 <etext+0x48>
    80000358:	6eb040ef          	jal	ra,80005242 <printf>
    kinit();         // physical page allocator
    8000035c:	d6dff0ef          	jal	ra,800000c8 <kinit>
    kvminit();       // create kernel page table
    80000360:	374000ef          	jal	ra,800006d4 <kvminit>
    kvminithart();   // turn on paging
    80000364:	0de000ef          	jal	ra,80000442 <kvminithart>
    procinit();      // process table
    80000368:	1c9000ef          	jal	ra,80000d30 <procinit>
    trapinit();      // trap vectors
    8000036c:	5ea010ef          	jal	ra,80001956 <trapinit>
    trapinithart();  // install kernel trap vector
    80000370:	60a010ef          	jal	ra,8000197a <trapinithart>
    plicinit();      // set up interrupt controller
    80000374:	4ca040ef          	jal	ra,8000483e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000378:	4dc040ef          	jal	ra,80004854 <plicinithart>
    binit();         // buffer cache
    8000037c:	543010ef          	jal	ra,800020be <binit>
    iinit();         // inode table
    80000380:	324020ef          	jal	ra,800026a4 <iinit>
    fileinit();      // file table
    80000384:	0c2030ef          	jal	ra,80003446 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000388:	5bc040ef          	jal	ra,80004944 <virtio_disk_init>
    userinit();      // first user process
    8000038c:	55f000ef          	jal	ra,800010ea <userinit>
    __sync_synchronize();
    80000390:	0ff0000f          	fence
    started = 1;
    80000394:	4785                	li	a5,1
    80000396:	00007717          	auipc	a4,0x7
    8000039a:	5ef72523          	sw	a5,1514(a4) # 80007980 <started>
    8000039e:	b779                	j	8000032c <main+0x3e>

00000000800003a0 <vmprint_level>:
}


#ifdef LAB_PGTBL
static void
vmprint_level(pagetable_t pt, int level) {
    800003a0:	711d                	addi	sp,sp,-96
    800003a2:	ec86                	sd	ra,88(sp)
    800003a4:	e8a2                	sd	s0,80(sp)
    800003a6:	e4a6                	sd	s1,72(sp)
    800003a8:	e0ca                	sd	s2,64(sp)
    800003aa:	fc4e                	sd	s3,56(sp)
    800003ac:	f852                	sd	s4,48(sp)
    800003ae:	f456                	sd	s5,40(sp)
    800003b0:	f05a                	sd	s6,32(sp)
    800003b2:	ec5e                	sd	s7,24(sp)
    800003b4:	e862                	sd	s8,16(sp)
    800003b6:	e466                	sd	s9,8(sp)
    800003b8:	e06a                	sd	s10,0(sp)
    800003ba:	1080                	addi	s0,sp,96
    800003bc:	8aae                	mv	s5,a1
  for (int i = 0; i < 512; i++) {
    800003be:	8a2a                	mv	s4,a0
    800003c0:	4981                	li	s3,0
    pte_t pte = pt[i];
    if (pte & PTE_V) {
      for (int d = 0; d <= level; d++) printf("..");
      printf("%d: pte 0x%lx pa 0x%lx\n", i, pte, PTE2PA(pte));
    800003c2:	00007c17          	auipc	s8,0x7
    800003c6:	c96c0c13          	addi	s8,s8,-874 # 80007058 <etext+0x58>
      if ((pte & (PTE_R|PTE_W|PTE_X)) == 0) { // non-leaf
        vmprint_level((pagetable_t)PTE2PA(pte), level+1); // no KADDR/P2V
    800003ca:	00158d1b          	addiw	s10,a1,1
      for (int d = 0; d <= level; d++) printf("..");
    800003ce:	4c81                	li	s9,0
    800003d0:	00007b17          	auipc	s6,0x7
    800003d4:	c80b0b13          	addi	s6,s6,-896 # 80007050 <etext+0x50>
  for (int i = 0; i < 512; i++) {
    800003d8:	20000b93          	li	s7,512
    800003dc:	a029                	j	800003e6 <vmprint_level+0x46>
    800003de:	2985                	addiw	s3,s3,1
    800003e0:	0a21                	addi	s4,s4,8
    800003e2:	05798263          	beq	s3,s7,80000426 <vmprint_level+0x86>
    pte_t pte = pt[i];
    800003e6:	000a3903          	ld	s2,0(s4) # fffffffffffff000 <end+0xffffffff7ffde120>
    if (pte & PTE_V) {
    800003ea:	00197793          	andi	a5,s2,1
    800003ee:	dbe5                	beqz	a5,800003de <vmprint_level+0x3e>
      for (int d = 0; d <= level; d++) printf("..");
    800003f0:	000ac963          	bltz	s5,80000402 <vmprint_level+0x62>
    800003f4:	84e6                	mv	s1,s9
    800003f6:	855a                	mv	a0,s6
    800003f8:	64b040ef          	jal	ra,80005242 <printf>
    800003fc:	2485                	addiw	s1,s1,1
    800003fe:	fe9adce3          	bge	s5,s1,800003f6 <vmprint_level+0x56>
      printf("%d: pte 0x%lx pa 0x%lx\n", i, pte, PTE2PA(pte));
    80000402:	00a95493          	srli	s1,s2,0xa
    80000406:	04b2                	slli	s1,s1,0xc
    80000408:	86a6                	mv	a3,s1
    8000040a:	864a                	mv	a2,s2
    8000040c:	85ce                	mv	a1,s3
    8000040e:	8562                	mv	a0,s8
    80000410:	633040ef          	jal	ra,80005242 <printf>
      if ((pte & (PTE_R|PTE_W|PTE_X)) == 0) { // non-leaf
    80000414:	00e97913          	andi	s2,s2,14
    80000418:	fc0913e3          	bnez	s2,800003de <vmprint_level+0x3e>
        vmprint_level((pagetable_t)PTE2PA(pte), level+1); // no KADDR/P2V
    8000041c:	85ea                	mv	a1,s10
    8000041e:	8526                	mv	a0,s1
    80000420:	f81ff0ef          	jal	ra,800003a0 <vmprint_level>
    80000424:	bf6d                	j	800003de <vmprint_level+0x3e>
      }
    }
  }
}
    80000426:	60e6                	ld	ra,88(sp)
    80000428:	6446                	ld	s0,80(sp)
    8000042a:	64a6                	ld	s1,72(sp)
    8000042c:	6906                	ld	s2,64(sp)
    8000042e:	79e2                	ld	s3,56(sp)
    80000430:	7a42                	ld	s4,48(sp)
    80000432:	7aa2                	ld	s5,40(sp)
    80000434:	7b02                	ld	s6,32(sp)
    80000436:	6be2                	ld	s7,24(sp)
    80000438:	6c42                	ld	s8,16(sp)
    8000043a:	6ca2                	ld	s9,8(sp)
    8000043c:	6d02                	ld	s10,0(sp)
    8000043e:	6125                	addi	sp,sp,96
    80000440:	8082                	ret

0000000080000442 <kvminithart>:
{
    80000442:	1141                	addi	sp,sp,-16
    80000444:	e422                	sd	s0,8(sp)
    80000446:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000448:	12000073          	sfence.vma
  w_satp(MAKE_SATP(kernel_pagetable));
    8000044c:	00007797          	auipc	a5,0x7
    80000450:	53c7b783          	ld	a5,1340(a5) # 80007988 <kernel_pagetable>
    80000454:	83b1                	srli	a5,a5,0xc
    80000456:	577d                	li	a4,-1
    80000458:	177e                	slli	a4,a4,0x3f
    8000045a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    8000045c:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000460:	12000073          	sfence.vma
}
    80000464:	6422                	ld	s0,8(sp)
    80000466:	0141                	addi	sp,sp,16
    80000468:	8082                	ret

000000008000046a <walk>:
{
    8000046a:	7139                	addi	sp,sp,-64
    8000046c:	fc06                	sd	ra,56(sp)
    8000046e:	f822                	sd	s0,48(sp)
    80000470:	f426                	sd	s1,40(sp)
    80000472:	f04a                	sd	s2,32(sp)
    80000474:	ec4e                	sd	s3,24(sp)
    80000476:	e852                	sd	s4,16(sp)
    80000478:	e456                	sd	s5,8(sp)
    8000047a:	e05a                	sd	s6,0(sp)
    8000047c:	0080                	addi	s0,sp,64
    8000047e:	892a                	mv	s2,a0
    80000480:	89ae                	mv	s3,a1
    80000482:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    80000484:	57fd                	li	a5,-1
    80000486:	83e9                	srli	a5,a5,0x1a
    80000488:	4a79                	li	s4,30
  for(int level = 2; level > 0; level--) {
    8000048a:	4b31                	li	s6,12
  if(va >= MAXVA)
    8000048c:	02b7fb63          	bgeu	a5,a1,800004c2 <walk+0x58>
    panic("walk");
    80000490:	00007517          	auipc	a0,0x7
    80000494:	be050513          	addi	a0,a0,-1056 # 80007070 <etext+0x70>
    80000498:	05e050ef          	jal	ra,800054f6 <panic>
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    8000049c:	060a8463          	beqz	s5,80000504 <walk+0x9a>
    800004a0:	c5dff0ef          	jal	ra,800000fc <kalloc>
    800004a4:	892a                	mv	s2,a0
    800004a6:	c12d                	beqz	a0,80000508 <walk+0x9e>
      memset(pagetable, 0, PGSIZE);
    800004a8:	6605                	lui	a2,0x1
    800004aa:	4581                	li	a1,0
    800004ac:	ca1ff0ef          	jal	ra,8000014c <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    800004b0:	00c95793          	srli	a5,s2,0xc
    800004b4:	07aa                	slli	a5,a5,0xa
    800004b6:	0017e793          	ori	a5,a5,1
    800004ba:	e09c                	sd	a5,0(s1)
  for(int level = 2; level > 0; level--) {
    800004bc:	3a5d                	addiw	s4,s4,-9
    800004be:	036a0263          	beq	s4,s6,800004e2 <walk+0x78>
    pte_t *pte = &pagetable[PX(level, va)];
    800004c2:	0149d4b3          	srl	s1,s3,s4
    800004c6:	1ff4f493          	andi	s1,s1,511
    800004ca:	048e                	slli	s1,s1,0x3
    800004cc:	94ca                	add	s1,s1,s2
    if(*pte & PTE_V) {
    800004ce:	609c                	ld	a5,0(s1)
    800004d0:	0017f713          	andi	a4,a5,1
    800004d4:	d761                	beqz	a4,8000049c <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    800004d6:	00a7d913          	srli	s2,a5,0xa
    800004da:	0932                	slli	s2,s2,0xc
      if(PTE_LEAF(*pte)) {
    800004dc:	8bb9                	andi	a5,a5,14
    800004de:	dff9                	beqz	a5,800004bc <walk+0x52>
    800004e0:	a039                	j	800004ee <walk+0x84>
  return &pagetable[PX(0, va)];
    800004e2:	00c9d493          	srli	s1,s3,0xc
    800004e6:	1ff4f493          	andi	s1,s1,511
    800004ea:	048e                	slli	s1,s1,0x3
    800004ec:	94ca                	add	s1,s1,s2
}
    800004ee:	8526                	mv	a0,s1
    800004f0:	70e2                	ld	ra,56(sp)
    800004f2:	7442                	ld	s0,48(sp)
    800004f4:	74a2                	ld	s1,40(sp)
    800004f6:	7902                	ld	s2,32(sp)
    800004f8:	69e2                	ld	s3,24(sp)
    800004fa:	6a42                	ld	s4,16(sp)
    800004fc:	6aa2                	ld	s5,8(sp)
    800004fe:	6b02                	ld	s6,0(sp)
    80000500:	6121                	addi	sp,sp,64
    80000502:	8082                	ret
        return 0;
    80000504:	4481                	li	s1,0
    80000506:	b7e5                	j	800004ee <walk+0x84>
    80000508:	84aa                	mv	s1,a0
    8000050a:	b7d5                	j	800004ee <walk+0x84>

000000008000050c <walkaddr>:
  if(va >= MAXVA)
    8000050c:	57fd                	li	a5,-1
    8000050e:	83e9                	srli	a5,a5,0x1a
    80000510:	00b7f463          	bgeu	a5,a1,80000518 <walkaddr+0xc>
    return 0;
    80000514:	4501                	li	a0,0
}
    80000516:	8082                	ret
{
    80000518:	1141                	addi	sp,sp,-16
    8000051a:	e406                	sd	ra,8(sp)
    8000051c:	e022                	sd	s0,0(sp)
    8000051e:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000520:	4601                	li	a2,0
    80000522:	f49ff0ef          	jal	ra,8000046a <walk>
  if(pte == 0)
    80000526:	c105                	beqz	a0,80000546 <walkaddr+0x3a>
  if((*pte & PTE_V) == 0)
    80000528:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    8000052a:	0117f693          	andi	a3,a5,17
    8000052e:	4745                	li	a4,17
    return 0;
    80000530:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80000532:	00e68663          	beq	a3,a4,8000053e <walkaddr+0x32>
}
    80000536:	60a2                	ld	ra,8(sp)
    80000538:	6402                	ld	s0,0(sp)
    8000053a:	0141                	addi	sp,sp,16
    8000053c:	8082                	ret
  pa = PTE2PA(*pte);
    8000053e:	00a7d513          	srli	a0,a5,0xa
    80000542:	0532                	slli	a0,a0,0xc
  return pa;
    80000544:	bfcd                	j	80000536 <walkaddr+0x2a>
    return 0;
    80000546:	4501                	li	a0,0
    80000548:	b7fd                	j	80000536 <walkaddr+0x2a>

000000008000054a <mappages>:
{
    8000054a:	715d                	addi	sp,sp,-80
    8000054c:	e486                	sd	ra,72(sp)
    8000054e:	e0a2                	sd	s0,64(sp)
    80000550:	fc26                	sd	s1,56(sp)
    80000552:	f84a                	sd	s2,48(sp)
    80000554:	f44e                	sd	s3,40(sp)
    80000556:	f052                	sd	s4,32(sp)
    80000558:	ec56                	sd	s5,24(sp)
    8000055a:	e85a                	sd	s6,16(sp)
    8000055c:	e45e                	sd	s7,8(sp)
    8000055e:	0880                	addi	s0,sp,80
  if((va % PGSIZE) != 0)
    80000560:	03459793          	slli	a5,a1,0x34
    80000564:	e7a9                	bnez	a5,800005ae <mappages+0x64>
    80000566:	8aaa                	mv	s5,a0
    80000568:	8b3a                	mv	s6,a4
  if((size % PGSIZE) != 0)
    8000056a:	03461793          	slli	a5,a2,0x34
    8000056e:	e7b1                	bnez	a5,800005ba <mappages+0x70>
  if(size == 0)
    80000570:	ca39                	beqz	a2,800005c6 <mappages+0x7c>
  last = va + size - PGSIZE;
    80000572:	79fd                	lui	s3,0xfffff
    80000574:	964e                	add	a2,a2,s3
    80000576:	00b609b3          	add	s3,a2,a1
  a = va;
    8000057a:	892e                	mv	s2,a1
    8000057c:	40b68a33          	sub	s4,a3,a1
    a += PGSIZE;
    80000580:	6b85                	lui	s7,0x1
    80000582:	012a04b3          	add	s1,s4,s2
    if((pte = walk(pagetable, a, 1)) == 0)
    80000586:	4605                	li	a2,1
    80000588:	85ca                	mv	a1,s2
    8000058a:	8556                	mv	a0,s5
    8000058c:	edfff0ef          	jal	ra,8000046a <walk>
    80000590:	c539                	beqz	a0,800005de <mappages+0x94>
    if(*pte & PTE_V)
    80000592:	611c                	ld	a5,0(a0)
    80000594:	8b85                	andi	a5,a5,1
    80000596:	ef95                	bnez	a5,800005d2 <mappages+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80000598:	80b1                	srli	s1,s1,0xc
    8000059a:	04aa                	slli	s1,s1,0xa
    8000059c:	0164e4b3          	or	s1,s1,s6
    800005a0:	0014e493          	ori	s1,s1,1
    800005a4:	e104                	sd	s1,0(a0)
    if(a == last)
    800005a6:	05390863          	beq	s2,s3,800005f6 <mappages+0xac>
    a += PGSIZE;
    800005aa:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    800005ac:	bfd9                	j	80000582 <mappages+0x38>
    panic("mappages: va not aligned");
    800005ae:	00007517          	auipc	a0,0x7
    800005b2:	aca50513          	addi	a0,a0,-1334 # 80007078 <etext+0x78>
    800005b6:	741040ef          	jal	ra,800054f6 <panic>
    panic("mappages: size not aligned");
    800005ba:	00007517          	auipc	a0,0x7
    800005be:	ade50513          	addi	a0,a0,-1314 # 80007098 <etext+0x98>
    800005c2:	735040ef          	jal	ra,800054f6 <panic>
    panic("mappages: size");
    800005c6:	00007517          	auipc	a0,0x7
    800005ca:	af250513          	addi	a0,a0,-1294 # 800070b8 <etext+0xb8>
    800005ce:	729040ef          	jal	ra,800054f6 <panic>
      panic("mappages: remap");
    800005d2:	00007517          	auipc	a0,0x7
    800005d6:	af650513          	addi	a0,a0,-1290 # 800070c8 <etext+0xc8>
    800005da:	71d040ef          	jal	ra,800054f6 <panic>
      return -1;
    800005de:	557d                	li	a0,-1
}
    800005e0:	60a6                	ld	ra,72(sp)
    800005e2:	6406                	ld	s0,64(sp)
    800005e4:	74e2                	ld	s1,56(sp)
    800005e6:	7942                	ld	s2,48(sp)
    800005e8:	79a2                	ld	s3,40(sp)
    800005ea:	7a02                	ld	s4,32(sp)
    800005ec:	6ae2                	ld	s5,24(sp)
    800005ee:	6b42                	ld	s6,16(sp)
    800005f0:	6ba2                	ld	s7,8(sp)
    800005f2:	6161                	addi	sp,sp,80
    800005f4:	8082                	ret
  return 0;
    800005f6:	4501                	li	a0,0
    800005f8:	b7e5                	j	800005e0 <mappages+0x96>

00000000800005fa <kvmmap>:
{
    800005fa:	1141                	addi	sp,sp,-16
    800005fc:	e406                	sd	ra,8(sp)
    800005fe:	e022                	sd	s0,0(sp)
    80000600:	0800                	addi	s0,sp,16
    80000602:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80000604:	86b2                	mv	a3,a2
    80000606:	863e                	mv	a2,a5
    80000608:	f43ff0ef          	jal	ra,8000054a <mappages>
    8000060c:	e509                	bnez	a0,80000616 <kvmmap+0x1c>
}
    8000060e:	60a2                	ld	ra,8(sp)
    80000610:	6402                	ld	s0,0(sp)
    80000612:	0141                	addi	sp,sp,16
    80000614:	8082                	ret
    panic("kvmmap");
    80000616:	00007517          	auipc	a0,0x7
    8000061a:	ac250513          	addi	a0,a0,-1342 # 800070d8 <etext+0xd8>
    8000061e:	6d9040ef          	jal	ra,800054f6 <panic>

0000000080000622 <kvmmake>:
{
    80000622:	1101                	addi	sp,sp,-32
    80000624:	ec06                	sd	ra,24(sp)
    80000626:	e822                	sd	s0,16(sp)
    80000628:	e426                	sd	s1,8(sp)
    8000062a:	e04a                	sd	s2,0(sp)
    8000062c:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    8000062e:	acfff0ef          	jal	ra,800000fc <kalloc>
    80000632:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80000634:	6605                	lui	a2,0x1
    80000636:	4581                	li	a1,0
    80000638:	b15ff0ef          	jal	ra,8000014c <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    8000063c:	4719                	li	a4,6
    8000063e:	6685                	lui	a3,0x1
    80000640:	10000637          	lui	a2,0x10000
    80000644:	100005b7          	lui	a1,0x10000
    80000648:	8526                	mv	a0,s1
    8000064a:	fb1ff0ef          	jal	ra,800005fa <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    8000064e:	4719                	li	a4,6
    80000650:	6685                	lui	a3,0x1
    80000652:	10001637          	lui	a2,0x10001
    80000656:	100015b7          	lui	a1,0x10001
    8000065a:	8526                	mv	a0,s1
    8000065c:	f9fff0ef          	jal	ra,800005fa <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80000660:	4719                	li	a4,6
    80000662:	040006b7          	lui	a3,0x4000
    80000666:	0c000637          	lui	a2,0xc000
    8000066a:	0c0005b7          	lui	a1,0xc000
    8000066e:	8526                	mv	a0,s1
    80000670:	f8bff0ef          	jal	ra,800005fa <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    80000674:	00007917          	auipc	s2,0x7
    80000678:	98c90913          	addi	s2,s2,-1652 # 80007000 <etext>
    8000067c:	4729                	li	a4,10
    8000067e:	80007697          	auipc	a3,0x80007
    80000682:	98268693          	addi	a3,a3,-1662 # 7000 <_entry-0x7fff9000>
    80000686:	4605                	li	a2,1
    80000688:	067e                	slli	a2,a2,0x1f
    8000068a:	85b2                	mv	a1,a2
    8000068c:	8526                	mv	a0,s1
    8000068e:	f6dff0ef          	jal	ra,800005fa <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    80000692:	4719                	li	a4,6
    80000694:	46c5                	li	a3,17
    80000696:	06ee                	slli	a3,a3,0x1b
    80000698:	412686b3          	sub	a3,a3,s2
    8000069c:	864a                	mv	a2,s2
    8000069e:	85ca                	mv	a1,s2
    800006a0:	8526                	mv	a0,s1
    800006a2:	f59ff0ef          	jal	ra,800005fa <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800006a6:	4729                	li	a4,10
    800006a8:	6685                	lui	a3,0x1
    800006aa:	00006617          	auipc	a2,0x6
    800006ae:	95660613          	addi	a2,a2,-1706 # 80006000 <_trampoline>
    800006b2:	040005b7          	lui	a1,0x4000
    800006b6:	15fd                	addi	a1,a1,-1
    800006b8:	05b2                	slli	a1,a1,0xc
    800006ba:	8526                	mv	a0,s1
    800006bc:	f3fff0ef          	jal	ra,800005fa <kvmmap>
  proc_mapstacks(kpgtbl);
    800006c0:	8526                	mv	a0,s1
    800006c2:	5e6000ef          	jal	ra,80000ca8 <proc_mapstacks>
}
    800006c6:	8526                	mv	a0,s1
    800006c8:	60e2                	ld	ra,24(sp)
    800006ca:	6442                	ld	s0,16(sp)
    800006cc:	64a2                	ld	s1,8(sp)
    800006ce:	6902                	ld	s2,0(sp)
    800006d0:	6105                	addi	sp,sp,32
    800006d2:	8082                	ret

00000000800006d4 <kvminit>:
{
    800006d4:	1141                	addi	sp,sp,-16
    800006d6:	e406                	sd	ra,8(sp)
    800006d8:	e022                	sd	s0,0(sp)
    800006da:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800006dc:	f47ff0ef          	jal	ra,80000622 <kvmmake>
    800006e0:	00007797          	auipc	a5,0x7
    800006e4:	2aa7b423          	sd	a0,680(a5) # 80007988 <kernel_pagetable>
}
    800006e8:	60a2                	ld	ra,8(sp)
    800006ea:	6402                	ld	s0,0(sp)
    800006ec:	0141                	addi	sp,sp,16
    800006ee:	8082                	ret

00000000800006f0 <uvmunmap>:
{
    800006f0:	715d                	addi	sp,sp,-80
    800006f2:	e486                	sd	ra,72(sp)
    800006f4:	e0a2                	sd	s0,64(sp)
    800006f6:	fc26                	sd	s1,56(sp)
    800006f8:	f84a                	sd	s2,48(sp)
    800006fa:	f44e                	sd	s3,40(sp)
    800006fc:	f052                	sd	s4,32(sp)
    800006fe:	ec56                	sd	s5,24(sp)
    80000700:	e85a                	sd	s6,16(sp)
    80000702:	e45e                	sd	s7,8(sp)
    80000704:	0880                	addi	s0,sp,80
  if((va % PGSIZE) != 0)
    80000706:	03459793          	slli	a5,a1,0x34
    8000070a:	e795                	bnez	a5,80000736 <uvmunmap+0x46>
    8000070c:	8a2a                	mv	s4,a0
    8000070e:	892e                	mv	s2,a1
    80000710:	8ab6                	mv	s5,a3
  for(a = va; a < va + npages*PGSIZE; a += sz){
    80000712:	0632                	slli	a2,a2,0xc
    80000714:	00b609b3          	add	s3,a2,a1
    if(PTE_FLAGS(*pte) == PTE_V)
    80000718:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += sz){
    8000071a:	6b05                	lui	s6,0x1
    8000071c:	0735e163          	bltu	a1,s3,8000077e <uvmunmap+0x8e>
}
    80000720:	60a6                	ld	ra,72(sp)
    80000722:	6406                	ld	s0,64(sp)
    80000724:	74e2                	ld	s1,56(sp)
    80000726:	7942                	ld	s2,48(sp)
    80000728:	79a2                	ld	s3,40(sp)
    8000072a:	7a02                	ld	s4,32(sp)
    8000072c:	6ae2                	ld	s5,24(sp)
    8000072e:	6b42                	ld	s6,16(sp)
    80000730:	6ba2                	ld	s7,8(sp)
    80000732:	6161                	addi	sp,sp,80
    80000734:	8082                	ret
    panic("uvmunmap: not aligned");
    80000736:	00007517          	auipc	a0,0x7
    8000073a:	9aa50513          	addi	a0,a0,-1622 # 800070e0 <etext+0xe0>
    8000073e:	5b9040ef          	jal	ra,800054f6 <panic>
      panic("uvmunmap: walk");
    80000742:	00007517          	auipc	a0,0x7
    80000746:	9b650513          	addi	a0,a0,-1610 # 800070f8 <etext+0xf8>
    8000074a:	5ad040ef          	jal	ra,800054f6 <panic>
      printf("va=%ld pte=%ld\n", a, *pte);
    8000074e:	85ca                	mv	a1,s2
    80000750:	00007517          	auipc	a0,0x7
    80000754:	9b850513          	addi	a0,a0,-1608 # 80007108 <etext+0x108>
    80000758:	2eb040ef          	jal	ra,80005242 <printf>
      panic("uvmunmap: not mapped");
    8000075c:	00007517          	auipc	a0,0x7
    80000760:	9bc50513          	addi	a0,a0,-1604 # 80007118 <etext+0x118>
    80000764:	593040ef          	jal	ra,800054f6 <panic>
      panic("uvmunmap: not a leaf");
    80000768:	00007517          	auipc	a0,0x7
    8000076c:	9c850513          	addi	a0,a0,-1592 # 80007130 <etext+0x130>
    80000770:	587040ef          	jal	ra,800054f6 <panic>
    *pte = 0;
    80000774:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += sz){
    80000778:	995a                	add	s2,s2,s6
    8000077a:	fb3973e3          	bgeu	s2,s3,80000720 <uvmunmap+0x30>
    if((pte = walk(pagetable, a, 0)) == 0)
    8000077e:	4601                	li	a2,0
    80000780:	85ca                	mv	a1,s2
    80000782:	8552                	mv	a0,s4
    80000784:	ce7ff0ef          	jal	ra,8000046a <walk>
    80000788:	84aa                	mv	s1,a0
    8000078a:	dd45                	beqz	a0,80000742 <uvmunmap+0x52>
    if((*pte & PTE_V) == 0) {
    8000078c:	6110                	ld	a2,0(a0)
    8000078e:	00167793          	andi	a5,a2,1
    80000792:	dfd5                	beqz	a5,8000074e <uvmunmap+0x5e>
    if(PTE_FLAGS(*pte) == PTE_V)
    80000794:	3ff67793          	andi	a5,a2,1023
    80000798:	fd7788e3          	beq	a5,s7,80000768 <uvmunmap+0x78>
    if(do_free){
    8000079c:	fc0a8ce3          	beqz	s5,80000774 <uvmunmap+0x84>
      uint64 pa = PTE2PA(*pte);
    800007a0:	8229                	srli	a2,a2,0xa
      kfree((void*)pa);
    800007a2:	00c61513          	slli	a0,a2,0xc
    800007a6:	877ff0ef          	jal	ra,8000001c <kfree>
    800007aa:	b7e9                	j	80000774 <uvmunmap+0x84>

00000000800007ac <uvmcreate>:
{
    800007ac:	1101                	addi	sp,sp,-32
    800007ae:	ec06                	sd	ra,24(sp)
    800007b0:	e822                	sd	s0,16(sp)
    800007b2:	e426                	sd	s1,8(sp)
    800007b4:	1000                	addi	s0,sp,32
  pagetable = (pagetable_t) kalloc();
    800007b6:	947ff0ef          	jal	ra,800000fc <kalloc>
    800007ba:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800007bc:	c509                	beqz	a0,800007c6 <uvmcreate+0x1a>
  memset(pagetable, 0, PGSIZE);
    800007be:	6605                	lui	a2,0x1
    800007c0:	4581                	li	a1,0
    800007c2:	98bff0ef          	jal	ra,8000014c <memset>
}
    800007c6:	8526                	mv	a0,s1
    800007c8:	60e2                	ld	ra,24(sp)
    800007ca:	6442                	ld	s0,16(sp)
    800007cc:	64a2                	ld	s1,8(sp)
    800007ce:	6105                	addi	sp,sp,32
    800007d0:	8082                	ret

00000000800007d2 <uvmfirst>:
{
    800007d2:	7179                	addi	sp,sp,-48
    800007d4:	f406                	sd	ra,40(sp)
    800007d6:	f022                	sd	s0,32(sp)
    800007d8:	ec26                	sd	s1,24(sp)
    800007da:	e84a                	sd	s2,16(sp)
    800007dc:	e44e                	sd	s3,8(sp)
    800007de:	e052                	sd	s4,0(sp)
    800007e0:	1800                	addi	s0,sp,48
  if(sz >= PGSIZE)
    800007e2:	6785                	lui	a5,0x1
    800007e4:	04f67063          	bgeu	a2,a5,80000824 <uvmfirst+0x52>
    800007e8:	8a2a                	mv	s4,a0
    800007ea:	89ae                	mv	s3,a1
    800007ec:	84b2                	mv	s1,a2
  mem = kalloc();
    800007ee:	90fff0ef          	jal	ra,800000fc <kalloc>
    800007f2:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    800007f4:	6605                	lui	a2,0x1
    800007f6:	4581                	li	a1,0
    800007f8:	955ff0ef          	jal	ra,8000014c <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    800007fc:	4779                	li	a4,30
    800007fe:	86ca                	mv	a3,s2
    80000800:	6605                	lui	a2,0x1
    80000802:	4581                	li	a1,0
    80000804:	8552                	mv	a0,s4
    80000806:	d45ff0ef          	jal	ra,8000054a <mappages>
  memmove(mem, src, sz);
    8000080a:	8626                	mv	a2,s1
    8000080c:	85ce                	mv	a1,s3
    8000080e:	854a                	mv	a0,s2
    80000810:	999ff0ef          	jal	ra,800001a8 <memmove>
}
    80000814:	70a2                	ld	ra,40(sp)
    80000816:	7402                	ld	s0,32(sp)
    80000818:	64e2                	ld	s1,24(sp)
    8000081a:	6942                	ld	s2,16(sp)
    8000081c:	69a2                	ld	s3,8(sp)
    8000081e:	6a02                	ld	s4,0(sp)
    80000820:	6145                	addi	sp,sp,48
    80000822:	8082                	ret
    panic("uvmfirst: more than a page");
    80000824:	00007517          	auipc	a0,0x7
    80000828:	92450513          	addi	a0,a0,-1756 # 80007148 <etext+0x148>
    8000082c:	4cb040ef          	jal	ra,800054f6 <panic>

0000000080000830 <uvmdealloc>:
{
    80000830:	1101                	addi	sp,sp,-32
    80000832:	ec06                	sd	ra,24(sp)
    80000834:	e822                	sd	s0,16(sp)
    80000836:	e426                	sd	s1,8(sp)
    80000838:	1000                	addi	s0,sp,32
    return oldsz;
    8000083a:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    8000083c:	00b67d63          	bgeu	a2,a1,80000856 <uvmdealloc+0x26>
    80000840:	84b2                	mv	s1,a2
  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    80000842:	6785                	lui	a5,0x1
    80000844:	17fd                	addi	a5,a5,-1
    80000846:	00f60733          	add	a4,a2,a5
    8000084a:	767d                	lui	a2,0xfffff
    8000084c:	8f71                	and	a4,a4,a2
    8000084e:	97ae                	add	a5,a5,a1
    80000850:	8ff1                	and	a5,a5,a2
    80000852:	00f76863          	bltu	a4,a5,80000862 <uvmdealloc+0x32>
}
    80000856:	8526                	mv	a0,s1
    80000858:	60e2                	ld	ra,24(sp)
    8000085a:	6442                	ld	s0,16(sp)
    8000085c:	64a2                	ld	s1,8(sp)
    8000085e:	6105                	addi	sp,sp,32
    80000860:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80000862:	8f99                	sub	a5,a5,a4
    80000864:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    80000866:	4685                	li	a3,1
    80000868:	0007861b          	sext.w	a2,a5
    8000086c:	85ba                	mv	a1,a4
    8000086e:	e83ff0ef          	jal	ra,800006f0 <uvmunmap>
    80000872:	b7d5                	j	80000856 <uvmdealloc+0x26>

0000000080000874 <uvmalloc>:
  if(newsz < oldsz)
    80000874:	08b66963          	bltu	a2,a1,80000906 <uvmalloc+0x92>
{
    80000878:	7139                	addi	sp,sp,-64
    8000087a:	fc06                	sd	ra,56(sp)
    8000087c:	f822                	sd	s0,48(sp)
    8000087e:	f426                	sd	s1,40(sp)
    80000880:	f04a                	sd	s2,32(sp)
    80000882:	ec4e                	sd	s3,24(sp)
    80000884:	e852                	sd	s4,16(sp)
    80000886:	e456                	sd	s5,8(sp)
    80000888:	e05a                	sd	s6,0(sp)
    8000088a:	0080                	addi	s0,sp,64
    8000088c:	8aaa                	mv	s5,a0
    8000088e:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80000890:	6985                	lui	s3,0x1
    80000892:	19fd                	addi	s3,s3,-1
    80000894:	95ce                	add	a1,a1,s3
    80000896:	79fd                	lui	s3,0xfffff
    80000898:	0135f9b3          	and	s3,a1,s3
  for(a = oldsz; a < newsz; a += sz){
    8000089c:	06c9f763          	bgeu	s3,a2,8000090a <uvmalloc+0x96>
    800008a0:	894e                	mv	s2,s3
    if(mappages(pagetable, a, sz, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800008a2:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800008a6:	857ff0ef          	jal	ra,800000fc <kalloc>
    800008aa:	84aa                	mv	s1,a0
    if(mem == 0){
    800008ac:	c11d                	beqz	a0,800008d2 <uvmalloc+0x5e>
    memset(mem, 0, sz);
    800008ae:	6605                	lui	a2,0x1
    800008b0:	4581                	li	a1,0
    800008b2:	89bff0ef          	jal	ra,8000014c <memset>
    if(mappages(pagetable, a, sz, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800008b6:	875a                	mv	a4,s6
    800008b8:	86a6                	mv	a3,s1
    800008ba:	6605                	lui	a2,0x1
    800008bc:	85ca                	mv	a1,s2
    800008be:	8556                	mv	a0,s5
    800008c0:	c8bff0ef          	jal	ra,8000054a <mappages>
    800008c4:	e51d                	bnez	a0,800008f2 <uvmalloc+0x7e>
  for(a = oldsz; a < newsz; a += sz){
    800008c6:	6785                	lui	a5,0x1
    800008c8:	993e                	add	s2,s2,a5
    800008ca:	fd496ee3          	bltu	s2,s4,800008a6 <uvmalloc+0x32>
  return newsz;
    800008ce:	8552                	mv	a0,s4
    800008d0:	a039                	j	800008de <uvmalloc+0x6a>
      uvmdealloc(pagetable, a, oldsz);
    800008d2:	864e                	mv	a2,s3
    800008d4:	85ca                	mv	a1,s2
    800008d6:	8556                	mv	a0,s5
    800008d8:	f59ff0ef          	jal	ra,80000830 <uvmdealloc>
      return 0;
    800008dc:	4501                	li	a0,0
}
    800008de:	70e2                	ld	ra,56(sp)
    800008e0:	7442                	ld	s0,48(sp)
    800008e2:	74a2                	ld	s1,40(sp)
    800008e4:	7902                	ld	s2,32(sp)
    800008e6:	69e2                	ld	s3,24(sp)
    800008e8:	6a42                	ld	s4,16(sp)
    800008ea:	6aa2                	ld	s5,8(sp)
    800008ec:	6b02                	ld	s6,0(sp)
    800008ee:	6121                	addi	sp,sp,64
    800008f0:	8082                	ret
      kfree(mem);
    800008f2:	8526                	mv	a0,s1
    800008f4:	f28ff0ef          	jal	ra,8000001c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    800008f8:	864e                	mv	a2,s3
    800008fa:	85ca                	mv	a1,s2
    800008fc:	8556                	mv	a0,s5
    800008fe:	f33ff0ef          	jal	ra,80000830 <uvmdealloc>
      return 0;
    80000902:	4501                	li	a0,0
    80000904:	bfe9                	j	800008de <uvmalloc+0x6a>
    return oldsz;
    80000906:	852e                	mv	a0,a1
}
    80000908:	8082                	ret
  return newsz;
    8000090a:	8532                	mv	a0,a2
    8000090c:	bfc9                	j	800008de <uvmalloc+0x6a>

000000008000090e <freewalk>:
{
    8000090e:	7179                	addi	sp,sp,-48
    80000910:	f406                	sd	ra,40(sp)
    80000912:	f022                	sd	s0,32(sp)
    80000914:	ec26                	sd	s1,24(sp)
    80000916:	e84a                	sd	s2,16(sp)
    80000918:	e44e                	sd	s3,8(sp)
    8000091a:	e052                	sd	s4,0(sp)
    8000091c:	1800                	addi	s0,sp,48
    8000091e:	8a2a                	mv	s4,a0
  for(int i = 0; i < 512; i++){
    80000920:	84aa                	mv	s1,a0
    80000922:	6905                	lui	s2,0x1
    80000924:	992a                	add	s2,s2,a0
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80000926:	4985                	li	s3,1
    80000928:	a811                	j	8000093c <freewalk+0x2e>
      uint64 child = PTE2PA(pte);
    8000092a:	8129                	srli	a0,a0,0xa
      freewalk((pagetable_t)child);
    8000092c:	0532                	slli	a0,a0,0xc
    8000092e:	fe1ff0ef          	jal	ra,8000090e <freewalk>
      pagetable[i] = 0;
    80000932:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    80000936:	04a1                	addi	s1,s1,8
    80000938:	01248f63          	beq	s1,s2,80000956 <freewalk+0x48>
    pte_t pte = pagetable[i];
    8000093c:	6088                	ld	a0,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    8000093e:	00f57793          	andi	a5,a0,15
    80000942:	ff3784e3          	beq	a5,s3,8000092a <freewalk+0x1c>
    } else if(pte & PTE_V){
    80000946:	8905                	andi	a0,a0,1
    80000948:	d57d                	beqz	a0,80000936 <freewalk+0x28>
      panic("freewalk: leaf");
    8000094a:	00007517          	auipc	a0,0x7
    8000094e:	81e50513          	addi	a0,a0,-2018 # 80007168 <etext+0x168>
    80000952:	3a5040ef          	jal	ra,800054f6 <panic>
  kfree((void*)pagetable);
    80000956:	8552                	mv	a0,s4
    80000958:	ec4ff0ef          	jal	ra,8000001c <kfree>
}
    8000095c:	70a2                	ld	ra,40(sp)
    8000095e:	7402                	ld	s0,32(sp)
    80000960:	64e2                	ld	s1,24(sp)
    80000962:	6942                	ld	s2,16(sp)
    80000964:	69a2                	ld	s3,8(sp)
    80000966:	6a02                	ld	s4,0(sp)
    80000968:	6145                	addi	sp,sp,48
    8000096a:	8082                	ret

000000008000096c <uvmfree>:
{
    8000096c:	1101                	addi	sp,sp,-32
    8000096e:	ec06                	sd	ra,24(sp)
    80000970:	e822                	sd	s0,16(sp)
    80000972:	e426                	sd	s1,8(sp)
    80000974:	1000                	addi	s0,sp,32
    80000976:	84aa                	mv	s1,a0
  if(sz > 0)
    80000978:	e989                	bnez	a1,8000098a <uvmfree+0x1e>
  freewalk(pagetable);
    8000097a:	8526                	mv	a0,s1
    8000097c:	f93ff0ef          	jal	ra,8000090e <freewalk>
}
    80000980:	60e2                	ld	ra,24(sp)
    80000982:	6442                	ld	s0,16(sp)
    80000984:	64a2                	ld	s1,8(sp)
    80000986:	6105                	addi	sp,sp,32
    80000988:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    8000098a:	6605                	lui	a2,0x1
    8000098c:	167d                	addi	a2,a2,-1
    8000098e:	962e                	add	a2,a2,a1
    80000990:	4685                	li	a3,1
    80000992:	8231                	srli	a2,a2,0xc
    80000994:	4581                	li	a1,0
    80000996:	d5bff0ef          	jal	ra,800006f0 <uvmunmap>
    8000099a:	b7c5                	j	8000097a <uvmfree+0xe>

000000008000099c <uvmcopy>:
  for(i = 0; i < sz; i += szinc){
    8000099c:	c65d                	beqz	a2,80000a4a <uvmcopy+0xae>
{
    8000099e:	715d                	addi	sp,sp,-80
    800009a0:	e486                	sd	ra,72(sp)
    800009a2:	e0a2                	sd	s0,64(sp)
    800009a4:	fc26                	sd	s1,56(sp)
    800009a6:	f84a                	sd	s2,48(sp)
    800009a8:	f44e                	sd	s3,40(sp)
    800009aa:	f052                	sd	s4,32(sp)
    800009ac:	ec56                	sd	s5,24(sp)
    800009ae:	e85a                	sd	s6,16(sp)
    800009b0:	e45e                	sd	s7,8(sp)
    800009b2:	0880                	addi	s0,sp,80
    800009b4:	8b2a                	mv	s6,a0
    800009b6:	8aae                	mv	s5,a1
    800009b8:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += szinc){
    800009ba:	4981                	li	s3,0
    if((pte = walk(old, i, 0)) == 0)
    800009bc:	4601                	li	a2,0
    800009be:	85ce                	mv	a1,s3
    800009c0:	855a                	mv	a0,s6
    800009c2:	aa9ff0ef          	jal	ra,8000046a <walk>
    800009c6:	c121                	beqz	a0,80000a06 <uvmcopy+0x6a>
    if((*pte & PTE_V) == 0)
    800009c8:	6118                	ld	a4,0(a0)
    800009ca:	00177793          	andi	a5,a4,1
    800009ce:	c3b1                	beqz	a5,80000a12 <uvmcopy+0x76>
    pa = PTE2PA(*pte);
    800009d0:	00a75593          	srli	a1,a4,0xa
    800009d4:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    800009d8:	3ff77493          	andi	s1,a4,1023
    if((mem = kalloc()) == 0)
    800009dc:	f20ff0ef          	jal	ra,800000fc <kalloc>
    800009e0:	892a                	mv	s2,a0
    800009e2:	c129                	beqz	a0,80000a24 <uvmcopy+0x88>
    memmove(mem, (char*)pa, PGSIZE);
    800009e4:	6605                	lui	a2,0x1
    800009e6:	85de                	mv	a1,s7
    800009e8:	fc0ff0ef          	jal	ra,800001a8 <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    800009ec:	8726                	mv	a4,s1
    800009ee:	86ca                	mv	a3,s2
    800009f0:	6605                	lui	a2,0x1
    800009f2:	85ce                	mv	a1,s3
    800009f4:	8556                	mv	a0,s5
    800009f6:	b55ff0ef          	jal	ra,8000054a <mappages>
    800009fa:	e115                	bnez	a0,80000a1e <uvmcopy+0x82>
  for(i = 0; i < sz; i += szinc){
    800009fc:	6785                	lui	a5,0x1
    800009fe:	99be                	add	s3,s3,a5
    80000a00:	fb49eee3          	bltu	s3,s4,800009bc <uvmcopy+0x20>
    80000a04:	a805                	j	80000a34 <uvmcopy+0x98>
      panic("uvmcopy: pte should exist");
    80000a06:	00006517          	auipc	a0,0x6
    80000a0a:	77250513          	addi	a0,a0,1906 # 80007178 <etext+0x178>
    80000a0e:	2e9040ef          	jal	ra,800054f6 <panic>
      panic("uvmcopy: page not present");
    80000a12:	00006517          	auipc	a0,0x6
    80000a16:	78650513          	addi	a0,a0,1926 # 80007198 <etext+0x198>
    80000a1a:	2dd040ef          	jal	ra,800054f6 <panic>
      kfree(mem);
    80000a1e:	854a                	mv	a0,s2
    80000a20:	dfcff0ef          	jal	ra,8000001c <kfree>
  uvmunmap(new, 0, i / PGSIZE, 1);
    80000a24:	4685                	li	a3,1
    80000a26:	00c9d613          	srli	a2,s3,0xc
    80000a2a:	4581                	li	a1,0
    80000a2c:	8556                	mv	a0,s5
    80000a2e:	cc3ff0ef          	jal	ra,800006f0 <uvmunmap>
  return -1;
    80000a32:	557d                	li	a0,-1
}
    80000a34:	60a6                	ld	ra,72(sp)
    80000a36:	6406                	ld	s0,64(sp)
    80000a38:	74e2                	ld	s1,56(sp)
    80000a3a:	7942                	ld	s2,48(sp)
    80000a3c:	79a2                	ld	s3,40(sp)
    80000a3e:	7a02                	ld	s4,32(sp)
    80000a40:	6ae2                	ld	s5,24(sp)
    80000a42:	6b42                	ld	s6,16(sp)
    80000a44:	6ba2                	ld	s7,8(sp)
    80000a46:	6161                	addi	sp,sp,80
    80000a48:	8082                	ret
  return 0;
    80000a4a:	4501                	li	a0,0
}
    80000a4c:	8082                	ret

0000000080000a4e <uvmclear>:
{
    80000a4e:	1141                	addi	sp,sp,-16
    80000a50:	e406                	sd	ra,8(sp)
    80000a52:	e022                	sd	s0,0(sp)
    80000a54:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000a56:	4601                	li	a2,0
    80000a58:	a13ff0ef          	jal	ra,8000046a <walk>
  if(pte == 0)
    80000a5c:	c901                	beqz	a0,80000a6c <uvmclear+0x1e>
  *pte &= ~PTE_U;
    80000a5e:	611c                	ld	a5,0(a0)
    80000a60:	9bbd                	andi	a5,a5,-17
    80000a62:	e11c                	sd	a5,0(a0)
}
    80000a64:	60a2                	ld	ra,8(sp)
    80000a66:	6402                	ld	s0,0(sp)
    80000a68:	0141                	addi	sp,sp,16
    80000a6a:	8082                	ret
    panic("uvmclear");
    80000a6c:	00006517          	auipc	a0,0x6
    80000a70:	74c50513          	addi	a0,a0,1868 # 800071b8 <etext+0x1b8>
    80000a74:	283040ef          	jal	ra,800054f6 <panic>

0000000080000a78 <copyout>:
  while(len > 0){
    80000a78:	c6c1                	beqz	a3,80000b00 <copyout+0x88>
{
    80000a7a:	711d                	addi	sp,sp,-96
    80000a7c:	ec86                	sd	ra,88(sp)
    80000a7e:	e8a2                	sd	s0,80(sp)
    80000a80:	e4a6                	sd	s1,72(sp)
    80000a82:	e0ca                	sd	s2,64(sp)
    80000a84:	fc4e                	sd	s3,56(sp)
    80000a86:	f852                	sd	s4,48(sp)
    80000a88:	f456                	sd	s5,40(sp)
    80000a8a:	f05a                	sd	s6,32(sp)
    80000a8c:	ec5e                	sd	s7,24(sp)
    80000a8e:	e862                	sd	s8,16(sp)
    80000a90:	e466                	sd	s9,8(sp)
    80000a92:	1080                	addi	s0,sp,96
    80000a94:	8b2a                	mv	s6,a0
    80000a96:	8a2e                	mv	s4,a1
    80000a98:	8ab2                	mv	s5,a2
    80000a9a:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(dstva);
    80000a9c:	74fd                	lui	s1,0xfffff
    80000a9e:	8ced                	and	s1,s1,a1
    if (va0 >= MAXVA)
    80000aa0:	57fd                	li	a5,-1
    80000aa2:	83e9                	srli	a5,a5,0x1a
    80000aa4:	0697e063          	bltu	a5,s1,80000b04 <copyout+0x8c>
    80000aa8:	6c05                	lui	s8,0x1
    80000aaa:	8bbe                	mv	s7,a5
    80000aac:	a015                	j	80000ad0 <copyout+0x58>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80000aae:	409a04b3          	sub	s1,s4,s1
    80000ab2:	0009061b          	sext.w	a2,s2
    80000ab6:	85d6                	mv	a1,s5
    80000ab8:	9526                	add	a0,a0,s1
    80000aba:	eeeff0ef          	jal	ra,800001a8 <memmove>
    len -= n;
    80000abe:	412989b3          	sub	s3,s3,s2
    src += n;
    80000ac2:	9aca                	add	s5,s5,s2
  while(len > 0){
    80000ac4:	02098c63          	beqz	s3,80000afc <copyout+0x84>
    if (va0 >= MAXVA)
    80000ac8:	059be063          	bltu	s7,s9,80000b08 <copyout+0x90>
    va0 = PGROUNDDOWN(dstva);
    80000acc:	84e6                	mv	s1,s9
    dstva = va0 + PGSIZE;
    80000ace:	8a66                	mv	s4,s9
    if((pte = walk(pagetable, va0, 0)) == 0) {
    80000ad0:	4601                	li	a2,0
    80000ad2:	85a6                	mv	a1,s1
    80000ad4:	855a                	mv	a0,s6
    80000ad6:	995ff0ef          	jal	ra,8000046a <walk>
    80000ada:	c90d                	beqz	a0,80000b0c <copyout+0x94>
    if((*pte & PTE_W) == 0)
    80000adc:	611c                	ld	a5,0(a0)
    80000ade:	8b91                	andi	a5,a5,4
    80000ae0:	c7a1                	beqz	a5,80000b28 <copyout+0xb0>
    pa0 = walkaddr(pagetable, va0);
    80000ae2:	85a6                	mv	a1,s1
    80000ae4:	855a                	mv	a0,s6
    80000ae6:	a27ff0ef          	jal	ra,8000050c <walkaddr>
    if(pa0 == 0)
    80000aea:	c129                	beqz	a0,80000b2c <copyout+0xb4>
    n = PGSIZE - (dstva - va0);
    80000aec:	01848cb3          	add	s9,s1,s8
    80000af0:	414c8933          	sub	s2,s9,s4
    if(n > len)
    80000af4:	fb29fde3          	bgeu	s3,s2,80000aae <copyout+0x36>
    80000af8:	894e                	mv	s2,s3
    80000afa:	bf55                	j	80000aae <copyout+0x36>
  return 0;
    80000afc:	4501                	li	a0,0
    80000afe:	a801                	j	80000b0e <copyout+0x96>
    80000b00:	4501                	li	a0,0
}
    80000b02:	8082                	ret
      return -1;
    80000b04:	557d                	li	a0,-1
    80000b06:	a021                	j	80000b0e <copyout+0x96>
    80000b08:	557d                	li	a0,-1
    80000b0a:	a011                	j	80000b0e <copyout+0x96>
      return -1;
    80000b0c:	557d                	li	a0,-1
}
    80000b0e:	60e6                	ld	ra,88(sp)
    80000b10:	6446                	ld	s0,80(sp)
    80000b12:	64a6                	ld	s1,72(sp)
    80000b14:	6906                	ld	s2,64(sp)
    80000b16:	79e2                	ld	s3,56(sp)
    80000b18:	7a42                	ld	s4,48(sp)
    80000b1a:	7aa2                	ld	s5,40(sp)
    80000b1c:	7b02                	ld	s6,32(sp)
    80000b1e:	6be2                	ld	s7,24(sp)
    80000b20:	6c42                	ld	s8,16(sp)
    80000b22:	6ca2                	ld	s9,8(sp)
    80000b24:	6125                	addi	sp,sp,96
    80000b26:	8082                	ret
      return -1;
    80000b28:	557d                	li	a0,-1
    80000b2a:	b7d5                	j	80000b0e <copyout+0x96>
      return -1;
    80000b2c:	557d                	li	a0,-1
    80000b2e:	b7c5                	j	80000b0e <copyout+0x96>

0000000080000b30 <copyin>:
  while(len > 0){
    80000b30:	c6a5                	beqz	a3,80000b98 <copyin+0x68>
{
    80000b32:	715d                	addi	sp,sp,-80
    80000b34:	e486                	sd	ra,72(sp)
    80000b36:	e0a2                	sd	s0,64(sp)
    80000b38:	fc26                	sd	s1,56(sp)
    80000b3a:	f84a                	sd	s2,48(sp)
    80000b3c:	f44e                	sd	s3,40(sp)
    80000b3e:	f052                	sd	s4,32(sp)
    80000b40:	ec56                	sd	s5,24(sp)
    80000b42:	e85a                	sd	s6,16(sp)
    80000b44:	e45e                	sd	s7,8(sp)
    80000b46:	e062                	sd	s8,0(sp)
    80000b48:	0880                	addi	s0,sp,80
    80000b4a:	8b2a                	mv	s6,a0
    80000b4c:	8a2e                	mv	s4,a1
    80000b4e:	8c32                	mv	s8,a2
    80000b50:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000b52:	7bfd                	lui	s7,0xfffff
    n = PGSIZE - (srcva - va0);
    80000b54:	6a85                	lui	s5,0x1
    80000b56:	a00d                	j	80000b78 <copyin+0x48>
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80000b58:	018505b3          	add	a1,a0,s8
    80000b5c:	0004861b          	sext.w	a2,s1
    80000b60:	412585b3          	sub	a1,a1,s2
    80000b64:	8552                	mv	a0,s4
    80000b66:	e42ff0ef          	jal	ra,800001a8 <memmove>
    len -= n;
    80000b6a:	409989b3          	sub	s3,s3,s1
    dst += n;
    80000b6e:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    80000b70:	01590c33          	add	s8,s2,s5
  while(len > 0){
    80000b74:	02098063          	beqz	s3,80000b94 <copyin+0x64>
    va0 = PGROUNDDOWN(srcva);
    80000b78:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80000b7c:	85ca                	mv	a1,s2
    80000b7e:	855a                	mv	a0,s6
    80000b80:	98dff0ef          	jal	ra,8000050c <walkaddr>
    if(pa0 == 0)
    80000b84:	cd01                	beqz	a0,80000b9c <copyin+0x6c>
    n = PGSIZE - (srcva - va0);
    80000b86:	418904b3          	sub	s1,s2,s8
    80000b8a:	94d6                	add	s1,s1,s5
    if(n > len)
    80000b8c:	fc99f6e3          	bgeu	s3,s1,80000b58 <copyin+0x28>
    80000b90:	84ce                	mv	s1,s3
    80000b92:	b7d9                	j	80000b58 <copyin+0x28>
  return 0;
    80000b94:	4501                	li	a0,0
    80000b96:	a021                	j	80000b9e <copyin+0x6e>
    80000b98:	4501                	li	a0,0
}
    80000b9a:	8082                	ret
      return -1;
    80000b9c:	557d                	li	a0,-1
}
    80000b9e:	60a6                	ld	ra,72(sp)
    80000ba0:	6406                	ld	s0,64(sp)
    80000ba2:	74e2                	ld	s1,56(sp)
    80000ba4:	7942                	ld	s2,48(sp)
    80000ba6:	79a2                	ld	s3,40(sp)
    80000ba8:	7a02                	ld	s4,32(sp)
    80000baa:	6ae2                	ld	s5,24(sp)
    80000bac:	6b42                	ld	s6,16(sp)
    80000bae:	6ba2                	ld	s7,8(sp)
    80000bb0:	6c02                	ld	s8,0(sp)
    80000bb2:	6161                	addi	sp,sp,80
    80000bb4:	8082                	ret

0000000080000bb6 <copyinstr>:
  while(got_null == 0 && max > 0){
    80000bb6:	c2d5                	beqz	a3,80000c5a <copyinstr+0xa4>
{
    80000bb8:	715d                	addi	sp,sp,-80
    80000bba:	e486                	sd	ra,72(sp)
    80000bbc:	e0a2                	sd	s0,64(sp)
    80000bbe:	fc26                	sd	s1,56(sp)
    80000bc0:	f84a                	sd	s2,48(sp)
    80000bc2:	f44e                	sd	s3,40(sp)
    80000bc4:	f052                	sd	s4,32(sp)
    80000bc6:	ec56                	sd	s5,24(sp)
    80000bc8:	e85a                	sd	s6,16(sp)
    80000bca:	e45e                	sd	s7,8(sp)
    80000bcc:	0880                	addi	s0,sp,80
    80000bce:	8a2a                	mv	s4,a0
    80000bd0:	8b2e                	mv	s6,a1
    80000bd2:	8bb2                	mv	s7,a2
    80000bd4:	84b6                	mv	s1,a3
    va0 = PGROUNDDOWN(srcva);
    80000bd6:	7afd                	lui	s5,0xfffff
    n = PGSIZE - (srcva - va0);
    80000bd8:	6985                	lui	s3,0x1
    80000bda:	a035                	j	80000c06 <copyinstr+0x50>
        *dst = '\0';
    80000bdc:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    80000be0:	4785                	li	a5,1
  if(got_null){
    80000be2:	0017b793          	seqz	a5,a5
    80000be6:	40f00533          	neg	a0,a5
}
    80000bea:	60a6                	ld	ra,72(sp)
    80000bec:	6406                	ld	s0,64(sp)
    80000bee:	74e2                	ld	s1,56(sp)
    80000bf0:	7942                	ld	s2,48(sp)
    80000bf2:	79a2                	ld	s3,40(sp)
    80000bf4:	7a02                	ld	s4,32(sp)
    80000bf6:	6ae2                	ld	s5,24(sp)
    80000bf8:	6b42                	ld	s6,16(sp)
    80000bfa:	6ba2                	ld	s7,8(sp)
    80000bfc:	6161                	addi	sp,sp,80
    80000bfe:	8082                	ret
    srcva = va0 + PGSIZE;
    80000c00:	01390bb3          	add	s7,s2,s3
  while(got_null == 0 && max > 0){
    80000c04:	c4b9                	beqz	s1,80000c52 <copyinstr+0x9c>
    va0 = PGROUNDDOWN(srcva);
    80000c06:	015bf933          	and	s2,s7,s5
    pa0 = walkaddr(pagetable, va0);
    80000c0a:	85ca                	mv	a1,s2
    80000c0c:	8552                	mv	a0,s4
    80000c0e:	8ffff0ef          	jal	ra,8000050c <walkaddr>
    if(pa0 == 0)
    80000c12:	c131                	beqz	a0,80000c56 <copyinstr+0xa0>
    n = PGSIZE - (srcva - va0);
    80000c14:	41790833          	sub	a6,s2,s7
    80000c18:	984e                	add	a6,a6,s3
    if(n > max)
    80000c1a:	0104f363          	bgeu	s1,a6,80000c20 <copyinstr+0x6a>
    80000c1e:	8826                	mv	a6,s1
    char *p = (char *) (pa0 + (srcva - va0));
    80000c20:	955e                	add	a0,a0,s7
    80000c22:	41250533          	sub	a0,a0,s2
    while(n > 0){
    80000c26:	fc080de3          	beqz	a6,80000c00 <copyinstr+0x4a>
    80000c2a:	985a                	add	a6,a6,s6
    80000c2c:	87da                	mv	a5,s6
      if(*p == '\0'){
    80000c2e:	41650633          	sub	a2,a0,s6
    80000c32:	14fd                	addi	s1,s1,-1
    80000c34:	9b26                	add	s6,s6,s1
    80000c36:	00f60733          	add	a4,a2,a5
    80000c3a:	00074703          	lbu	a4,0(a4)
    80000c3e:	df59                	beqz	a4,80000bdc <copyinstr+0x26>
        *dst = *p;
    80000c40:	00e78023          	sb	a4,0(a5)
      --max;
    80000c44:	40fb04b3          	sub	s1,s6,a5
      dst++;
    80000c48:	0785                	addi	a5,a5,1
    while(n > 0){
    80000c4a:	ff0796e3          	bne	a5,a6,80000c36 <copyinstr+0x80>
      dst++;
    80000c4e:	8b42                	mv	s6,a6
    80000c50:	bf45                	j	80000c00 <copyinstr+0x4a>
    80000c52:	4781                	li	a5,0
    80000c54:	b779                	j	80000be2 <copyinstr+0x2c>
      return -1;
    80000c56:	557d                	li	a0,-1
    80000c58:	bf49                	j	80000bea <copyinstr+0x34>
  int got_null = 0;
    80000c5a:	4781                	li	a5,0
  if(got_null){
    80000c5c:	0017b793          	seqz	a5,a5
    80000c60:	40f00533          	neg	a0,a5
}
    80000c64:	8082                	ret

0000000080000c66 <vmprint>:

void
vmprint(pagetable_t pagetable) {
    80000c66:	1101                	addi	sp,sp,-32
    80000c68:	ec06                	sd	ra,24(sp)
    80000c6a:	e822                	sd	s0,16(sp)
    80000c6c:	e426                	sd	s1,8(sp)
    80000c6e:	1000                	addi	s0,sp,32
    80000c70:	84aa                	mv	s1,a0
  printf("page table %p\n", pagetable);
    80000c72:	85aa                	mv	a1,a0
    80000c74:	00006517          	auipc	a0,0x6
    80000c78:	55450513          	addi	a0,a0,1364 # 800071c8 <etext+0x1c8>
    80000c7c:	5c6040ef          	jal	ra,80005242 <printf>
  vmprint_level(pagetable, 0);
    80000c80:	4581                	li	a1,0
    80000c82:	8526                	mv	a0,s1
    80000c84:	f1cff0ef          	jal	ra,800003a0 <vmprint_level>
}
    80000c88:	60e2                	ld	ra,24(sp)
    80000c8a:	6442                	ld	s0,16(sp)
    80000c8c:	64a2                	ld	s1,8(sp)
    80000c8e:	6105                	addi	sp,sp,32
    80000c90:	8082                	ret

0000000080000c92 <pgpte>:



#ifdef LAB_PGTBL
pte_t*
pgpte(pagetable_t pagetable, uint64 va) {
    80000c92:	1141                	addi	sp,sp,-16
    80000c94:	e406                	sd	ra,8(sp)
    80000c96:	e022                	sd	s0,0(sp)
    80000c98:	0800                	addi	s0,sp,16
  return walk(pagetable, va, 0);
    80000c9a:	4601                	li	a2,0
    80000c9c:	fceff0ef          	jal	ra,8000046a <walk>
}
    80000ca0:	60a2                	ld	ra,8(sp)
    80000ca2:	6402                	ld	s0,0(sp)
    80000ca4:	0141                	addi	sp,sp,16
    80000ca6:	8082                	ret

0000000080000ca8 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80000ca8:	7139                	addi	sp,sp,-64
    80000caa:	fc06                	sd	ra,56(sp)
    80000cac:	f822                	sd	s0,48(sp)
    80000cae:	f426                	sd	s1,40(sp)
    80000cb0:	f04a                	sd	s2,32(sp)
    80000cb2:	ec4e                	sd	s3,24(sp)
    80000cb4:	e852                	sd	s4,16(sp)
    80000cb6:	e456                	sd	s5,8(sp)
    80000cb8:	e05a                	sd	s6,0(sp)
    80000cba:	0080                	addi	s0,sp,64
    80000cbc:	89aa                	mv	s3,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80000cbe:	00007497          	auipc	s1,0x7
    80000cc2:	14248493          	addi	s1,s1,322 # 80007e00 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80000cc6:	8b26                	mv	s6,s1
    80000cc8:	00006a97          	auipc	s5,0x6
    80000ccc:	338a8a93          	addi	s5,s5,824 # 80007000 <etext>
    80000cd0:	01000937          	lui	s2,0x1000
    80000cd4:	197d                	addi	s2,s2,-1
    80000cd6:	093a                	slli	s2,s2,0xe
  for(p = proc; p < &proc[NPROC]; p++) {
    80000cd8:	0000da17          	auipc	s4,0xd
    80000cdc:	d28a0a13          	addi	s4,s4,-728 # 8000da00 <tickslock>
    char *pa = kalloc();
    80000ce0:	c1cff0ef          	jal	ra,800000fc <kalloc>
    80000ce4:	862a                	mv	a2,a0
    if(pa == 0)
    80000ce6:	cd1d                	beqz	a0,80000d24 <proc_mapstacks+0x7c>
    uint64 va = KSTACK((int) (p - proc));
    80000ce8:	416485b3          	sub	a1,s1,s6
    80000cec:	8591                	srai	a1,a1,0x4
    80000cee:	000ab783          	ld	a5,0(s5)
    80000cf2:	02f585b3          	mul	a1,a1,a5
    80000cf6:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000cfa:	4719                	li	a4,6
    80000cfc:	6685                	lui	a3,0x1
    80000cfe:	40b905b3          	sub	a1,s2,a1
    80000d02:	854e                	mv	a0,s3
    80000d04:	8f7ff0ef          	jal	ra,800005fa <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d08:	17048493          	addi	s1,s1,368
    80000d0c:	fd449ae3          	bne	s1,s4,80000ce0 <proc_mapstacks+0x38>
  }
}
    80000d10:	70e2                	ld	ra,56(sp)
    80000d12:	7442                	ld	s0,48(sp)
    80000d14:	74a2                	ld	s1,40(sp)
    80000d16:	7902                	ld	s2,32(sp)
    80000d18:	69e2                	ld	s3,24(sp)
    80000d1a:	6a42                	ld	s4,16(sp)
    80000d1c:	6aa2                	ld	s5,8(sp)
    80000d1e:	6b02                	ld	s6,0(sp)
    80000d20:	6121                	addi	sp,sp,64
    80000d22:	8082                	ret
      panic("kalloc");
    80000d24:	00006517          	auipc	a0,0x6
    80000d28:	4b450513          	addi	a0,a0,1204 # 800071d8 <etext+0x1d8>
    80000d2c:	7ca040ef          	jal	ra,800054f6 <panic>

0000000080000d30 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80000d30:	7139                	addi	sp,sp,-64
    80000d32:	fc06                	sd	ra,56(sp)
    80000d34:	f822                	sd	s0,48(sp)
    80000d36:	f426                	sd	s1,40(sp)
    80000d38:	f04a                	sd	s2,32(sp)
    80000d3a:	ec4e                	sd	s3,24(sp)
    80000d3c:	e852                	sd	s4,16(sp)
    80000d3e:	e456                	sd	s5,8(sp)
    80000d40:	e05a                	sd	s6,0(sp)
    80000d42:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80000d44:	00006597          	auipc	a1,0x6
    80000d48:	49c58593          	addi	a1,a1,1180 # 800071e0 <etext+0x1e0>
    80000d4c:	00007517          	auipc	a0,0x7
    80000d50:	c8450513          	addi	a0,a0,-892 # 800079d0 <pid_lock>
    80000d54:	237040ef          	jal	ra,8000578a <initlock>
  initlock(&wait_lock, "wait_lock");
    80000d58:	00006597          	auipc	a1,0x6
    80000d5c:	49058593          	addi	a1,a1,1168 # 800071e8 <etext+0x1e8>
    80000d60:	00007517          	auipc	a0,0x7
    80000d64:	c8850513          	addi	a0,a0,-888 # 800079e8 <wait_lock>
    80000d68:	223040ef          	jal	ra,8000578a <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d6c:	00007497          	auipc	s1,0x7
    80000d70:	09448493          	addi	s1,s1,148 # 80007e00 <proc>
      initlock(&p->lock, "proc");
    80000d74:	00006b17          	auipc	s6,0x6
    80000d78:	484b0b13          	addi	s6,s6,1156 # 800071f8 <etext+0x1f8>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80000d7c:	8aa6                	mv	s5,s1
    80000d7e:	00006a17          	auipc	s4,0x6
    80000d82:	282a0a13          	addi	s4,s4,642 # 80007000 <etext>
    80000d86:	01000937          	lui	s2,0x1000
    80000d8a:	197d                	addi	s2,s2,-1
    80000d8c:	093a                	slli	s2,s2,0xe
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d8e:	0000d997          	auipc	s3,0xd
    80000d92:	c7298993          	addi	s3,s3,-910 # 8000da00 <tickslock>
      initlock(&p->lock, "proc");
    80000d96:	85da                	mv	a1,s6
    80000d98:	8526                	mv	a0,s1
    80000d9a:	1f1040ef          	jal	ra,8000578a <initlock>
      p->state = UNUSED;
    80000d9e:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80000da2:	415487b3          	sub	a5,s1,s5
    80000da6:	8791                	srai	a5,a5,0x4
    80000da8:	000a3703          	ld	a4,0(s4)
    80000dac:	02e787b3          	mul	a5,a5,a4
    80000db0:	00d7979b          	slliw	a5,a5,0xd
    80000db4:	40f907b3          	sub	a5,s2,a5
    80000db8:	e4bc                	sd	a5,72(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80000dba:	17048493          	addi	s1,s1,368
    80000dbe:	fd349ce3          	bne	s1,s3,80000d96 <procinit+0x66>
  }
}
    80000dc2:	70e2                	ld	ra,56(sp)
    80000dc4:	7442                	ld	s0,48(sp)
    80000dc6:	74a2                	ld	s1,40(sp)
    80000dc8:	7902                	ld	s2,32(sp)
    80000dca:	69e2                	ld	s3,24(sp)
    80000dcc:	6a42                	ld	s4,16(sp)
    80000dce:	6aa2                	ld	s5,8(sp)
    80000dd0:	6b02                	ld	s6,0(sp)
    80000dd2:	6121                	addi	sp,sp,64
    80000dd4:	8082                	ret

0000000080000dd6 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80000dd6:	1141                	addi	sp,sp,-16
    80000dd8:	e422                	sd	s0,8(sp)
    80000dda:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80000ddc:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80000dde:	2501                	sext.w	a0,a0
    80000de0:	6422                	ld	s0,8(sp)
    80000de2:	0141                	addi	sp,sp,16
    80000de4:	8082                	ret

0000000080000de6 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80000de6:	1141                	addi	sp,sp,-16
    80000de8:	e422                	sd	s0,8(sp)
    80000dea:	0800                	addi	s0,sp,16
    80000dec:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80000dee:	2781                	sext.w	a5,a5
    80000df0:	079e                	slli	a5,a5,0x7
  return c;
}
    80000df2:	00007517          	auipc	a0,0x7
    80000df6:	c0e50513          	addi	a0,a0,-1010 # 80007a00 <cpus>
    80000dfa:	953e                	add	a0,a0,a5
    80000dfc:	6422                	ld	s0,8(sp)
    80000dfe:	0141                	addi	sp,sp,16
    80000e00:	8082                	ret

0000000080000e02 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80000e02:	1101                	addi	sp,sp,-32
    80000e04:	ec06                	sd	ra,24(sp)
    80000e06:	e822                	sd	s0,16(sp)
    80000e08:	e426                	sd	s1,8(sp)
    80000e0a:	1000                	addi	s0,sp,32
  push_off();
    80000e0c:	1bf040ef          	jal	ra,800057ca <push_off>
    80000e10:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80000e12:	2781                	sext.w	a5,a5
    80000e14:	079e                	slli	a5,a5,0x7
    80000e16:	00007717          	auipc	a4,0x7
    80000e1a:	bba70713          	addi	a4,a4,-1094 # 800079d0 <pid_lock>
    80000e1e:	97ba                	add	a5,a5,a4
    80000e20:	7b84                	ld	s1,48(a5)
  pop_off();
    80000e22:	22d040ef          	jal	ra,8000584e <pop_off>
  return p;
}
    80000e26:	8526                	mv	a0,s1
    80000e28:	60e2                	ld	ra,24(sp)
    80000e2a:	6442                	ld	s0,16(sp)
    80000e2c:	64a2                	ld	s1,8(sp)
    80000e2e:	6105                	addi	sp,sp,32
    80000e30:	8082                	ret

0000000080000e32 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80000e32:	1141                	addi	sp,sp,-16
    80000e34:	e406                	sd	ra,8(sp)
    80000e36:	e022                	sd	s0,0(sp)
    80000e38:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    80000e3a:	fc9ff0ef          	jal	ra,80000e02 <myproc>
    80000e3e:	265040ef          	jal	ra,800058a2 <release>

  if (first) {
    80000e42:	00007797          	auipc	a5,0x7
    80000e46:	aee7a783          	lw	a5,-1298(a5) # 80007930 <first.1>
    80000e4a:	e799                	bnez	a5,80000e58 <forkret+0x26>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    80000e4c:	347000ef          	jal	ra,80001992 <usertrapret>
}
    80000e50:	60a2                	ld	ra,8(sp)
    80000e52:	6402                	ld	s0,0(sp)
    80000e54:	0141                	addi	sp,sp,16
    80000e56:	8082                	ret
    fsinit(ROOTDEV);
    80000e58:	4505                	li	a0,1
    80000e5a:	7de010ef          	jal	ra,80002638 <fsinit>
    first = 0;
    80000e5e:	00007797          	auipc	a5,0x7
    80000e62:	ac07a923          	sw	zero,-1326(a5) # 80007930 <first.1>
    __sync_synchronize();
    80000e66:	0ff0000f          	fence
    80000e6a:	b7cd                	j	80000e4c <forkret+0x1a>

0000000080000e6c <allocpid>:
{
    80000e6c:	1101                	addi	sp,sp,-32
    80000e6e:	ec06                	sd	ra,24(sp)
    80000e70:	e822                	sd	s0,16(sp)
    80000e72:	e426                	sd	s1,8(sp)
    80000e74:	e04a                	sd	s2,0(sp)
    80000e76:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80000e78:	00007917          	auipc	s2,0x7
    80000e7c:	b5890913          	addi	s2,s2,-1192 # 800079d0 <pid_lock>
    80000e80:	854a                	mv	a0,s2
    80000e82:	189040ef          	jal	ra,8000580a <acquire>
  pid = nextpid;
    80000e86:	00007797          	auipc	a5,0x7
    80000e8a:	aae78793          	addi	a5,a5,-1362 # 80007934 <nextpid>
    80000e8e:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80000e90:	0014871b          	addiw	a4,s1,1
    80000e94:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80000e96:	854a                	mv	a0,s2
    80000e98:	20b040ef          	jal	ra,800058a2 <release>
}
    80000e9c:	8526                	mv	a0,s1
    80000e9e:	60e2                	ld	ra,24(sp)
    80000ea0:	6442                	ld	s0,16(sp)
    80000ea2:	64a2                	ld	s1,8(sp)
    80000ea4:	6902                	ld	s2,0(sp)
    80000ea6:	6105                	addi	sp,sp,32
    80000ea8:	8082                	ret

0000000080000eaa <proc_pagetable>:
{
    80000eaa:	1101                	addi	sp,sp,-32
    80000eac:	ec06                	sd	ra,24(sp)
    80000eae:	e822                	sd	s0,16(sp)
    80000eb0:	e426                	sd	s1,8(sp)
    80000eb2:	e04a                	sd	s2,0(sp)
    80000eb4:	1000                	addi	s0,sp,32
    80000eb6:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80000eb8:	8f5ff0ef          	jal	ra,800007ac <uvmcreate>
    80000ebc:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80000ebe:	cd05                	beqz	a0,80000ef6 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80000ec0:	4729                	li	a4,10
    80000ec2:	00005697          	auipc	a3,0x5
    80000ec6:	13e68693          	addi	a3,a3,318 # 80006000 <_trampoline>
    80000eca:	6605                	lui	a2,0x1
    80000ecc:	040005b7          	lui	a1,0x4000
    80000ed0:	15fd                	addi	a1,a1,-1
    80000ed2:	05b2                	slli	a1,a1,0xc
    80000ed4:	e76ff0ef          	jal	ra,8000054a <mappages>
    80000ed8:	02054663          	bltz	a0,80000f04 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80000edc:	4719                	li	a4,6
    80000ede:	06093683          	ld	a3,96(s2)
    80000ee2:	6605                	lui	a2,0x1
    80000ee4:	020005b7          	lui	a1,0x2000
    80000ee8:	15fd                	addi	a1,a1,-1
    80000eea:	05b6                	slli	a1,a1,0xd
    80000eec:	8526                	mv	a0,s1
    80000eee:	e5cff0ef          	jal	ra,8000054a <mappages>
    80000ef2:	00054f63          	bltz	a0,80000f10 <proc_pagetable+0x66>
}
    80000ef6:	8526                	mv	a0,s1
    80000ef8:	60e2                	ld	ra,24(sp)
    80000efa:	6442                	ld	s0,16(sp)
    80000efc:	64a2                	ld	s1,8(sp)
    80000efe:	6902                	ld	s2,0(sp)
    80000f00:	6105                	addi	sp,sp,32
    80000f02:	8082                	ret
    uvmfree(pagetable, 0);
    80000f04:	4581                	li	a1,0
    80000f06:	8526                	mv	a0,s1
    80000f08:	a65ff0ef          	jal	ra,8000096c <uvmfree>
    return 0;
    80000f0c:	4481                	li	s1,0
    80000f0e:	b7e5                	j	80000ef6 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000f10:	4681                	li	a3,0
    80000f12:	4605                	li	a2,1
    80000f14:	040005b7          	lui	a1,0x4000
    80000f18:	15fd                	addi	a1,a1,-1
    80000f1a:	05b2                	slli	a1,a1,0xc
    80000f1c:	8526                	mv	a0,s1
    80000f1e:	fd2ff0ef          	jal	ra,800006f0 <uvmunmap>
    uvmfree(pagetable, 0);
    80000f22:	4581                	li	a1,0
    80000f24:	8526                	mv	a0,s1
    80000f26:	a47ff0ef          	jal	ra,8000096c <uvmfree>
    return 0;
    80000f2a:	4481                	li	s1,0
    80000f2c:	b7e9                	j	80000ef6 <proc_pagetable+0x4c>

0000000080000f2e <proc_freepagetable>:
{
    80000f2e:	7179                	addi	sp,sp,-48
    80000f30:	f406                	sd	ra,40(sp)
    80000f32:	f022                	sd	s0,32(sp)
    80000f34:	ec26                	sd	s1,24(sp)
    80000f36:	e84a                	sd	s2,16(sp)
    80000f38:	e44e                	sd	s3,8(sp)
    80000f3a:	1800                	addi	s0,sp,48
    80000f3c:	84aa                	mv	s1,a0
    80000f3e:	89ae                	mv	s3,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000f40:	4681                	li	a3,0
    80000f42:	4605                	li	a2,1
    80000f44:	04000937          	lui	s2,0x4000
    80000f48:	fff90593          	addi	a1,s2,-1 # 3ffffff <_entry-0x7c000001>
    80000f4c:	05b2                	slli	a1,a1,0xc
    80000f4e:	fa2ff0ef          	jal	ra,800006f0 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80000f52:	4681                	li	a3,0
    80000f54:	4605                	li	a2,1
    80000f56:	020005b7          	lui	a1,0x2000
    80000f5a:	15fd                	addi	a1,a1,-1
    80000f5c:	05b6                	slli	a1,a1,0xd
    80000f5e:	8526                	mv	a0,s1
    80000f60:	f90ff0ef          	jal	ra,800006f0 <uvmunmap>
  pte_t *pte = walk(pagetable, USYSCALL, 0);
    80000f64:	4601                	li	a2,0
    80000f66:	1975                	addi	s2,s2,-3
    80000f68:	00c91593          	slli	a1,s2,0xc
    80000f6c:	8526                	mv	a0,s1
    80000f6e:	cfcff0ef          	jal	ra,8000046a <walk>
  if (pte && (*pte & PTE_V))
    80000f72:	c501                	beqz	a0,80000f7a <proc_freepagetable+0x4c>
    80000f74:	611c                	ld	a5,0(a0)
    80000f76:	8b85                	andi	a5,a5,1
    80000f78:	ef81                	bnez	a5,80000f90 <proc_freepagetable+0x62>
  uvmfree(pagetable, sz);
    80000f7a:	85ce                	mv	a1,s3
    80000f7c:	8526                	mv	a0,s1
    80000f7e:	9efff0ef          	jal	ra,8000096c <uvmfree>
}
    80000f82:	70a2                	ld	ra,40(sp)
    80000f84:	7402                	ld	s0,32(sp)
    80000f86:	64e2                	ld	s1,24(sp)
    80000f88:	6942                	ld	s2,16(sp)
    80000f8a:	69a2                	ld	s3,8(sp)
    80000f8c:	6145                	addi	sp,sp,48
    80000f8e:	8082                	ret
    uvmunmap(pagetable, USYSCALL, 1, 1);  // free only if present
    80000f90:	4685                	li	a3,1
    80000f92:	4605                	li	a2,1
    80000f94:	00c91593          	slli	a1,s2,0xc
    80000f98:	8526                	mv	a0,s1
    80000f9a:	f56ff0ef          	jal	ra,800006f0 <uvmunmap>
    80000f9e:	bff1                	j	80000f7a <proc_freepagetable+0x4c>

0000000080000fa0 <freeproc>:
{
    80000fa0:	1101                	addi	sp,sp,-32
    80000fa2:	ec06                	sd	ra,24(sp)
    80000fa4:	e822                	sd	s0,16(sp)
    80000fa6:	e426                	sd	s1,8(sp)
    80000fa8:	1000                	addi	s0,sp,32
    80000faa:	84aa                	mv	s1,a0
  p->usyscall = 0;
    80000fac:	02053c23          	sd	zero,56(a0)
  if(p->trapframe){
    80000fb0:	7128                	ld	a0,96(a0)
    80000fb2:	c509                	beqz	a0,80000fbc <freeproc+0x1c>
    kfree((void*)p->trapframe);
    80000fb4:	868ff0ef          	jal	ra,8000001c <kfree>
    p->trapframe = 0;
    80000fb8:	0604b023          	sd	zero,96(s1)
  if(p->pagetable){
    80000fbc:	6ca8                	ld	a0,88(s1)
    80000fbe:	c511                	beqz	a0,80000fca <freeproc+0x2a>
    proc_freepagetable(p->pagetable, p->sz);
    80000fc0:	68ac                	ld	a1,80(s1)
    80000fc2:	f6dff0ef          	jal	ra,80000f2e <proc_freepagetable>
    p->pagetable = 0;
    80000fc6:	0404bc23          	sd	zero,88(s1)
  p->sz = 0;
    80000fca:	0404b823          	sd	zero,80(s1)
  p->pid = 0;
    80000fce:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80000fd2:	0404b023          	sd	zero,64(s1)
  p->name[0] = 0;
    80000fd6:	16048023          	sb	zero,352(s1)
  p->chan = 0;
    80000fda:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80000fde:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80000fe2:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80000fe6:	0004ac23          	sw	zero,24(s1)
}
    80000fea:	60e2                	ld	ra,24(sp)
    80000fec:	6442                	ld	s0,16(sp)
    80000fee:	64a2                	ld	s1,8(sp)
    80000ff0:	6105                	addi	sp,sp,32
    80000ff2:	8082                	ret

0000000080000ff4 <allocproc>:
{
    80000ff4:	1101                	addi	sp,sp,-32
    80000ff6:	ec06                	sd	ra,24(sp)
    80000ff8:	e822                	sd	s0,16(sp)
    80000ffa:	e426                	sd	s1,8(sp)
    80000ffc:	e04a                	sd	s2,0(sp)
    80000ffe:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001000:	00007497          	auipc	s1,0x7
    80001004:	e0048493          	addi	s1,s1,-512 # 80007e00 <proc>
    80001008:	0000d917          	auipc	s2,0xd
    8000100c:	9f890913          	addi	s2,s2,-1544 # 8000da00 <tickslock>
    acquire(&p->lock);
    80001010:	8526                	mv	a0,s1
    80001012:	7f8040ef          	jal	ra,8000580a <acquire>
    if(p->state == UNUSED) {
    80001016:	4c9c                	lw	a5,24(s1)
    80001018:	cb91                	beqz	a5,8000102c <allocproc+0x38>
      release(&p->lock);
    8000101a:	8526                	mv	a0,s1
    8000101c:	087040ef          	jal	ra,800058a2 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001020:	17048493          	addi	s1,s1,368
    80001024:	ff2496e3          	bne	s1,s2,80001010 <allocproc+0x1c>
  return 0;
    80001028:	4481                	li	s1,0
    8000102a:	a0a5                	j	80001092 <allocproc+0x9e>
  p->pid = allocpid();
    8000102c:	e41ff0ef          	jal	ra,80000e6c <allocpid>
    80001030:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001032:	4785                	li	a5,1
    80001034:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001036:	8c6ff0ef          	jal	ra,800000fc <kalloc>
    8000103a:	892a                	mv	s2,a0
    8000103c:	f0a8                	sd	a0,96(s1)
    8000103e:	c12d                	beqz	a0,800010a0 <allocproc+0xac>
  p->pagetable = proc_pagetable(p);
    80001040:	8526                	mv	a0,s1
    80001042:	e69ff0ef          	jal	ra,80000eaa <proc_pagetable>
    80001046:	892a                	mv	s2,a0
    80001048:	eca8                	sd	a0,88(s1)
  if(p->pagetable == 0){
    8000104a:	c13d                	beqz	a0,800010b0 <allocproc+0xbc>
  memset(&p->context, 0, sizeof(p->context));
    8000104c:	07000613          	li	a2,112
    80001050:	4581                	li	a1,0
    80001052:	06848513          	addi	a0,s1,104
    80001056:	8f6ff0ef          	jal	ra,8000014c <memset>
  p->context.ra = (uint64)forkret;
    8000105a:	00000797          	auipc	a5,0x0
    8000105e:	dd878793          	addi	a5,a5,-552 # 80000e32 <forkret>
    80001062:	f4bc                	sd	a5,104(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001064:	64bc                	ld	a5,72(s1)
    80001066:	6705                	lui	a4,0x1
    80001068:	97ba                	add	a5,a5,a4
    8000106a:	f8bc                	sd	a5,112(s1)
  p->usyscall = (struct usyscall*)kalloc();
    8000106c:	890ff0ef          	jal	ra,800000fc <kalloc>
    80001070:	892a                	mv	s2,a0
    80001072:	fc88                	sd	a0,56(s1)
  if(p->usyscall == 0){
    80001074:	c531                	beqz	a0,800010c0 <allocproc+0xcc>
  p->usyscall->pid = p->pid;
    80001076:	589c                	lw	a5,48(s1)
    80001078:	c11c                	sw	a5,0(a0)
  if(mappages(p->pagetable, USYSCALL, PGSIZE,
    8000107a:	4749                	li	a4,18
    8000107c:	7c94                	ld	a3,56(s1)
    8000107e:	6605                	lui	a2,0x1
    80001080:	040005b7          	lui	a1,0x4000
    80001084:	15f5                	addi	a1,a1,-3
    80001086:	05b2                	slli	a1,a1,0xc
    80001088:	6ca8                	ld	a0,88(s1)
    8000108a:	cc0ff0ef          	jal	ra,8000054a <mappages>
    8000108e:	04054163          	bltz	a0,800010d0 <allocproc+0xdc>
}
    80001092:	8526                	mv	a0,s1
    80001094:	60e2                	ld	ra,24(sp)
    80001096:	6442                	ld	s0,16(sp)
    80001098:	64a2                	ld	s1,8(sp)
    8000109a:	6902                	ld	s2,0(sp)
    8000109c:	6105                	addi	sp,sp,32
    8000109e:	8082                	ret
    freeproc(p);
    800010a0:	8526                	mv	a0,s1
    800010a2:	effff0ef          	jal	ra,80000fa0 <freeproc>
    release(&p->lock);
    800010a6:	8526                	mv	a0,s1
    800010a8:	7fa040ef          	jal	ra,800058a2 <release>
    return 0;
    800010ac:	84ca                	mv	s1,s2
    800010ae:	b7d5                	j	80001092 <allocproc+0x9e>
    freeproc(p);
    800010b0:	8526                	mv	a0,s1
    800010b2:	eefff0ef          	jal	ra,80000fa0 <freeproc>
    release(&p->lock);
    800010b6:	8526                	mv	a0,s1
    800010b8:	7ea040ef          	jal	ra,800058a2 <release>
    return 0;
    800010bc:	84ca                	mv	s1,s2
    800010be:	bfd1                	j	80001092 <allocproc+0x9e>
    freeproc(p);
    800010c0:	8526                	mv	a0,s1
    800010c2:	edfff0ef          	jal	ra,80000fa0 <freeproc>
    release(&p->lock);
    800010c6:	8526                	mv	a0,s1
    800010c8:	7da040ef          	jal	ra,800058a2 <release>
    return 0;
    800010cc:	84ca                	mv	s1,s2
    800010ce:	b7d1                	j	80001092 <allocproc+0x9e>
    kfree((void*)p->usyscall);
    800010d0:	7c88                	ld	a0,56(s1)
    800010d2:	f4bfe0ef          	jal	ra,8000001c <kfree>
    p->usyscall = 0;
    800010d6:	0204bc23          	sd	zero,56(s1)
    freeproc(p);
    800010da:	8526                	mv	a0,s1
    800010dc:	ec5ff0ef          	jal	ra,80000fa0 <freeproc>
    release(&p->lock);
    800010e0:	8526                	mv	a0,s1
    800010e2:	7c0040ef          	jal	ra,800058a2 <release>
    return 0;
    800010e6:	4481                	li	s1,0
    800010e8:	b76d                	j	80001092 <allocproc+0x9e>

00000000800010ea <userinit>:
{
    800010ea:	1101                	addi	sp,sp,-32
    800010ec:	ec06                	sd	ra,24(sp)
    800010ee:	e822                	sd	s0,16(sp)
    800010f0:	e426                	sd	s1,8(sp)
    800010f2:	1000                	addi	s0,sp,32
  p = allocproc();
    800010f4:	f01ff0ef          	jal	ra,80000ff4 <allocproc>
    800010f8:	84aa                	mv	s1,a0
  initproc = p;
    800010fa:	00007797          	auipc	a5,0x7
    800010fe:	88a7bb23          	sd	a0,-1898(a5) # 80007990 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001102:	03400613          	li	a2,52
    80001106:	00007597          	auipc	a1,0x7
    8000110a:	83a58593          	addi	a1,a1,-1990 # 80007940 <initcode>
    8000110e:	6d28                	ld	a0,88(a0)
    80001110:	ec2ff0ef          	jal	ra,800007d2 <uvmfirst>
  p->sz = PGSIZE;
    80001114:	6785                	lui	a5,0x1
    80001116:	e8bc                	sd	a5,80(s1)
  p->trapframe->epc = 0;      // user program counter
    80001118:	70b8                	ld	a4,96(s1)
    8000111a:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    8000111e:	70b8                	ld	a4,96(s1)
    80001120:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001122:	4641                	li	a2,16
    80001124:	00006597          	auipc	a1,0x6
    80001128:	0dc58593          	addi	a1,a1,220 # 80007200 <etext+0x200>
    8000112c:	16048513          	addi	a0,s1,352
    80001130:	962ff0ef          	jal	ra,80000292 <safestrcpy>
  p->cwd = namei("/");
    80001134:	00006517          	auipc	a0,0x6
    80001138:	0dc50513          	addi	a0,a0,220 # 80007210 <etext+0x210>
    8000113c:	5db010ef          	jal	ra,80002f16 <namei>
    80001140:	14a4bc23          	sd	a0,344(s1)
  p->state = RUNNABLE;
    80001144:	478d                	li	a5,3
    80001146:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001148:	8526                	mv	a0,s1
    8000114a:	758040ef          	jal	ra,800058a2 <release>
}
    8000114e:	60e2                	ld	ra,24(sp)
    80001150:	6442                	ld	s0,16(sp)
    80001152:	64a2                	ld	s1,8(sp)
    80001154:	6105                	addi	sp,sp,32
    80001156:	8082                	ret

0000000080001158 <growproc>:
{
    80001158:	1101                	addi	sp,sp,-32
    8000115a:	ec06                	sd	ra,24(sp)
    8000115c:	e822                	sd	s0,16(sp)
    8000115e:	e426                	sd	s1,8(sp)
    80001160:	e04a                	sd	s2,0(sp)
    80001162:	1000                	addi	s0,sp,32
    80001164:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001166:	c9dff0ef          	jal	ra,80000e02 <myproc>
    8000116a:	84aa                	mv	s1,a0
  sz = p->sz;
    8000116c:	692c                	ld	a1,80(a0)
  if(n > 0){
    8000116e:	01204c63          	bgtz	s2,80001186 <growproc+0x2e>
  } else if(n < 0){
    80001172:	02094463          	bltz	s2,8000119a <growproc+0x42>
  p->sz = sz;
    80001176:	e8ac                	sd	a1,80(s1)
  return 0;
    80001178:	4501                	li	a0,0
}
    8000117a:	60e2                	ld	ra,24(sp)
    8000117c:	6442                	ld	s0,16(sp)
    8000117e:	64a2                	ld	s1,8(sp)
    80001180:	6902                	ld	s2,0(sp)
    80001182:	6105                	addi	sp,sp,32
    80001184:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001186:	4691                	li	a3,4
    80001188:	00b90633          	add	a2,s2,a1
    8000118c:	6d28                	ld	a0,88(a0)
    8000118e:	ee6ff0ef          	jal	ra,80000874 <uvmalloc>
    80001192:	85aa                	mv	a1,a0
    80001194:	f16d                	bnez	a0,80001176 <growproc+0x1e>
      return -1;
    80001196:	557d                	li	a0,-1
    80001198:	b7cd                	j	8000117a <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    8000119a:	00b90633          	add	a2,s2,a1
    8000119e:	6d28                	ld	a0,88(a0)
    800011a0:	e90ff0ef          	jal	ra,80000830 <uvmdealloc>
    800011a4:	85aa                	mv	a1,a0
    800011a6:	bfc1                	j	80001176 <growproc+0x1e>

00000000800011a8 <fork>:
{
    800011a8:	7139                	addi	sp,sp,-64
    800011aa:	fc06                	sd	ra,56(sp)
    800011ac:	f822                	sd	s0,48(sp)
    800011ae:	f426                	sd	s1,40(sp)
    800011b0:	f04a                	sd	s2,32(sp)
    800011b2:	ec4e                	sd	s3,24(sp)
    800011b4:	e852                	sd	s4,16(sp)
    800011b6:	e456                	sd	s5,8(sp)
    800011b8:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    800011ba:	c49ff0ef          	jal	ra,80000e02 <myproc>
    800011be:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    800011c0:	e35ff0ef          	jal	ra,80000ff4 <allocproc>
    800011c4:	0e050b63          	beqz	a0,800012ba <fork+0x112>
    800011c8:	89aa                	mv	s3,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    800011ca:	050ab603          	ld	a2,80(s5)
    800011ce:	6d2c                	ld	a1,88(a0)
    800011d0:	058ab503          	ld	a0,88(s5)
    800011d4:	fc8ff0ef          	jal	ra,8000099c <uvmcopy>
    800011d8:	04054863          	bltz	a0,80001228 <fork+0x80>
  np->sz = p->sz;
    800011dc:	050ab783          	ld	a5,80(s5)
    800011e0:	04f9b823          	sd	a5,80(s3)
  *(np->trapframe) = *(p->trapframe);
    800011e4:	060ab683          	ld	a3,96(s5)
    800011e8:	87b6                	mv	a5,a3
    800011ea:	0609b703          	ld	a4,96(s3)
    800011ee:	12068693          	addi	a3,a3,288
    800011f2:	0007b803          	ld	a6,0(a5) # 1000 <_entry-0x7ffff000>
    800011f6:	6788                	ld	a0,8(a5)
    800011f8:	6b8c                	ld	a1,16(a5)
    800011fa:	6f90                	ld	a2,24(a5)
    800011fc:	01073023          	sd	a6,0(a4)
    80001200:	e708                	sd	a0,8(a4)
    80001202:	eb0c                	sd	a1,16(a4)
    80001204:	ef10                	sd	a2,24(a4)
    80001206:	02078793          	addi	a5,a5,32
    8000120a:	02070713          	addi	a4,a4,32
    8000120e:	fed792e3          	bne	a5,a3,800011f2 <fork+0x4a>
  np->trapframe->a0 = 0;
    80001212:	0609b783          	ld	a5,96(s3)
    80001216:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    8000121a:	0d8a8493          	addi	s1,s5,216
    8000121e:	0d898913          	addi	s2,s3,216
    80001222:	158a8a13          	addi	s4,s5,344
    80001226:	a829                	j	80001240 <fork+0x98>
    freeproc(np);
    80001228:	854e                	mv	a0,s3
    8000122a:	d77ff0ef          	jal	ra,80000fa0 <freeproc>
    release(&np->lock);
    8000122e:	854e                	mv	a0,s3
    80001230:	672040ef          	jal	ra,800058a2 <release>
    return -1;
    80001234:	597d                	li	s2,-1
    80001236:	a885                	j	800012a6 <fork+0xfe>
  for(i = 0; i < NOFILE; i++)
    80001238:	04a1                	addi	s1,s1,8
    8000123a:	0921                	addi	s2,s2,8
    8000123c:	01448963          	beq	s1,s4,8000124e <fork+0xa6>
    if(p->ofile[i])
    80001240:	6088                	ld	a0,0(s1)
    80001242:	d97d                	beqz	a0,80001238 <fork+0x90>
      np->ofile[i] = filedup(p->ofile[i]);
    80001244:	284020ef          	jal	ra,800034c8 <filedup>
    80001248:	00a93023          	sd	a0,0(s2)
    8000124c:	b7f5                	j	80001238 <fork+0x90>
  np->cwd = idup(p->cwd);
    8000124e:	158ab503          	ld	a0,344(s5)
    80001252:	5dc010ef          	jal	ra,8000282e <idup>
    80001256:	14a9bc23          	sd	a0,344(s3)
  safestrcpy(np->name, p->name, sizeof(p->name));
    8000125a:	4641                	li	a2,16
    8000125c:	160a8593          	addi	a1,s5,352
    80001260:	16098513          	addi	a0,s3,352
    80001264:	82eff0ef          	jal	ra,80000292 <safestrcpy>
  pid = np->pid;
    80001268:	0309a903          	lw	s2,48(s3)
  release(&np->lock);
    8000126c:	854e                	mv	a0,s3
    8000126e:	634040ef          	jal	ra,800058a2 <release>
  acquire(&wait_lock);
    80001272:	00006497          	auipc	s1,0x6
    80001276:	77648493          	addi	s1,s1,1910 # 800079e8 <wait_lock>
    8000127a:	8526                	mv	a0,s1
    8000127c:	58e040ef          	jal	ra,8000580a <acquire>
  np->parent = p;
    80001280:	0559b023          	sd	s5,64(s3)
  release(&wait_lock);
    80001284:	8526                	mv	a0,s1
    80001286:	61c040ef          	jal	ra,800058a2 <release>
  acquire(&np->lock);
    8000128a:	854e                	mv	a0,s3
    8000128c:	57e040ef          	jal	ra,8000580a <acquire>
  np->state = RUNNABLE;
    80001290:	478d                	li	a5,3
    80001292:	00f9ac23          	sw	a5,24(s3)
  release(&np->lock);
    80001296:	854e                	mv	a0,s3
    80001298:	60a040ef          	jal	ra,800058a2 <release>
  np->usyscall->pid = np->pid; // child gets its own pid // pgtbl lab
    8000129c:	0389b783          	ld	a5,56(s3)
    800012a0:	0309a703          	lw	a4,48(s3)
    800012a4:	c398                	sw	a4,0(a5)
}
    800012a6:	854a                	mv	a0,s2
    800012a8:	70e2                	ld	ra,56(sp)
    800012aa:	7442                	ld	s0,48(sp)
    800012ac:	74a2                	ld	s1,40(sp)
    800012ae:	7902                	ld	s2,32(sp)
    800012b0:	69e2                	ld	s3,24(sp)
    800012b2:	6a42                	ld	s4,16(sp)
    800012b4:	6aa2                	ld	s5,8(sp)
    800012b6:	6121                	addi	sp,sp,64
    800012b8:	8082                	ret
    return -1;
    800012ba:	597d                	li	s2,-1
    800012bc:	b7ed                	j	800012a6 <fork+0xfe>

00000000800012be <scheduler>:
{
    800012be:	715d                	addi	sp,sp,-80
    800012c0:	e486                	sd	ra,72(sp)
    800012c2:	e0a2                	sd	s0,64(sp)
    800012c4:	fc26                	sd	s1,56(sp)
    800012c6:	f84a                	sd	s2,48(sp)
    800012c8:	f44e                	sd	s3,40(sp)
    800012ca:	f052                	sd	s4,32(sp)
    800012cc:	ec56                	sd	s5,24(sp)
    800012ce:	e85a                	sd	s6,16(sp)
    800012d0:	e45e                	sd	s7,8(sp)
    800012d2:	e062                	sd	s8,0(sp)
    800012d4:	0880                	addi	s0,sp,80
    800012d6:	8792                	mv	a5,tp
  int id = r_tp();
    800012d8:	2781                	sext.w	a5,a5
  c->proc = 0;
    800012da:	00779b13          	slli	s6,a5,0x7
    800012de:	00006717          	auipc	a4,0x6
    800012e2:	6f270713          	addi	a4,a4,1778 # 800079d0 <pid_lock>
    800012e6:	975a                	add	a4,a4,s6
    800012e8:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    800012ec:	00006717          	auipc	a4,0x6
    800012f0:	71c70713          	addi	a4,a4,1820 # 80007a08 <cpus+0x8>
    800012f4:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    800012f6:	4c11                	li	s8,4
        c->proc = p;
    800012f8:	079e                	slli	a5,a5,0x7
    800012fa:	00006a17          	auipc	s4,0x6
    800012fe:	6d6a0a13          	addi	s4,s4,1750 # 800079d0 <pid_lock>
    80001302:	9a3e                	add	s4,s4,a5
        found = 1;
    80001304:	4b85                	li	s7,1
    for(p = proc; p < &proc[NPROC]; p++) {
    80001306:	0000c997          	auipc	s3,0xc
    8000130a:	6fa98993          	addi	s3,s3,1786 # 8000da00 <tickslock>
    8000130e:	a0a9                	j	80001358 <scheduler+0x9a>
      release(&p->lock);
    80001310:	8526                	mv	a0,s1
    80001312:	590040ef          	jal	ra,800058a2 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001316:	17048493          	addi	s1,s1,368
    8000131a:	03348563          	beq	s1,s3,80001344 <scheduler+0x86>
      acquire(&p->lock);
    8000131e:	8526                	mv	a0,s1
    80001320:	4ea040ef          	jal	ra,8000580a <acquire>
      if(p->state == RUNNABLE) {
    80001324:	4c9c                	lw	a5,24(s1)
    80001326:	ff2795e3          	bne	a5,s2,80001310 <scheduler+0x52>
        p->state = RUNNING;
    8000132a:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    8000132e:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001332:	06848593          	addi	a1,s1,104
    80001336:	855a                	mv	a0,s6
    80001338:	5b4000ef          	jal	ra,800018ec <swtch>
        c->proc = 0;
    8000133c:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001340:	8ade                	mv	s5,s7
    80001342:	b7f9                	j	80001310 <scheduler+0x52>
    if(found == 0) {
    80001344:	000a9a63          	bnez	s5,80001358 <scheduler+0x9a>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001348:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000134c:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001350:	10079073          	csrw	sstatus,a5
      asm volatile("wfi");
    80001354:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001358:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000135c:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001360:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001364:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001366:	00007497          	auipc	s1,0x7
    8000136a:	a9a48493          	addi	s1,s1,-1382 # 80007e00 <proc>
      if(p->state == RUNNABLE) {
    8000136e:	490d                	li	s2,3
    80001370:	b77d                	j	8000131e <scheduler+0x60>

0000000080001372 <sched>:
{
    80001372:	7179                	addi	sp,sp,-48
    80001374:	f406                	sd	ra,40(sp)
    80001376:	f022                	sd	s0,32(sp)
    80001378:	ec26                	sd	s1,24(sp)
    8000137a:	e84a                	sd	s2,16(sp)
    8000137c:	e44e                	sd	s3,8(sp)
    8000137e:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001380:	a83ff0ef          	jal	ra,80000e02 <myproc>
    80001384:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001386:	41a040ef          	jal	ra,800057a0 <holding>
    8000138a:	c92d                	beqz	a0,800013fc <sched+0x8a>
  asm volatile("mv %0, tp" : "=r" (x) );
    8000138c:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    8000138e:	2781                	sext.w	a5,a5
    80001390:	079e                	slli	a5,a5,0x7
    80001392:	00006717          	auipc	a4,0x6
    80001396:	63e70713          	addi	a4,a4,1598 # 800079d0 <pid_lock>
    8000139a:	97ba                	add	a5,a5,a4
    8000139c:	0a87a703          	lw	a4,168(a5)
    800013a0:	4785                	li	a5,1
    800013a2:	06f71363          	bne	a4,a5,80001408 <sched+0x96>
  if(p->state == RUNNING)
    800013a6:	4c98                	lw	a4,24(s1)
    800013a8:	4791                	li	a5,4
    800013aa:	06f70563          	beq	a4,a5,80001414 <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800013ae:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800013b2:	8b89                	andi	a5,a5,2
  if(intr_get())
    800013b4:	e7b5                	bnez	a5,80001420 <sched+0xae>
  asm volatile("mv %0, tp" : "=r" (x) );
    800013b6:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    800013b8:	00006917          	auipc	s2,0x6
    800013bc:	61890913          	addi	s2,s2,1560 # 800079d0 <pid_lock>
    800013c0:	2781                	sext.w	a5,a5
    800013c2:	079e                	slli	a5,a5,0x7
    800013c4:	97ca                	add	a5,a5,s2
    800013c6:	0ac7a983          	lw	s3,172(a5)
    800013ca:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    800013cc:	2781                	sext.w	a5,a5
    800013ce:	079e                	slli	a5,a5,0x7
    800013d0:	00006597          	auipc	a1,0x6
    800013d4:	63858593          	addi	a1,a1,1592 # 80007a08 <cpus+0x8>
    800013d8:	95be                	add	a1,a1,a5
    800013da:	06848513          	addi	a0,s1,104
    800013de:	50e000ef          	jal	ra,800018ec <swtch>
    800013e2:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    800013e4:	2781                	sext.w	a5,a5
    800013e6:	079e                	slli	a5,a5,0x7
    800013e8:	97ca                	add	a5,a5,s2
    800013ea:	0b37a623          	sw	s3,172(a5)
}
    800013ee:	70a2                	ld	ra,40(sp)
    800013f0:	7402                	ld	s0,32(sp)
    800013f2:	64e2                	ld	s1,24(sp)
    800013f4:	6942                	ld	s2,16(sp)
    800013f6:	69a2                	ld	s3,8(sp)
    800013f8:	6145                	addi	sp,sp,48
    800013fa:	8082                	ret
    panic("sched p->lock");
    800013fc:	00006517          	auipc	a0,0x6
    80001400:	e1c50513          	addi	a0,a0,-484 # 80007218 <etext+0x218>
    80001404:	0f2040ef          	jal	ra,800054f6 <panic>
    panic("sched locks");
    80001408:	00006517          	auipc	a0,0x6
    8000140c:	e2050513          	addi	a0,a0,-480 # 80007228 <etext+0x228>
    80001410:	0e6040ef          	jal	ra,800054f6 <panic>
    panic("sched running");
    80001414:	00006517          	auipc	a0,0x6
    80001418:	e2450513          	addi	a0,a0,-476 # 80007238 <etext+0x238>
    8000141c:	0da040ef          	jal	ra,800054f6 <panic>
    panic("sched interruptible");
    80001420:	00006517          	auipc	a0,0x6
    80001424:	e2850513          	addi	a0,a0,-472 # 80007248 <etext+0x248>
    80001428:	0ce040ef          	jal	ra,800054f6 <panic>

000000008000142c <yield>:
{
    8000142c:	1101                	addi	sp,sp,-32
    8000142e:	ec06                	sd	ra,24(sp)
    80001430:	e822                	sd	s0,16(sp)
    80001432:	e426                	sd	s1,8(sp)
    80001434:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001436:	9cdff0ef          	jal	ra,80000e02 <myproc>
    8000143a:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000143c:	3ce040ef          	jal	ra,8000580a <acquire>
  p->state = RUNNABLE;
    80001440:	478d                	li	a5,3
    80001442:	cc9c                	sw	a5,24(s1)
  sched();
    80001444:	f2fff0ef          	jal	ra,80001372 <sched>
  release(&p->lock);
    80001448:	8526                	mv	a0,s1
    8000144a:	458040ef          	jal	ra,800058a2 <release>
}
    8000144e:	60e2                	ld	ra,24(sp)
    80001450:	6442                	ld	s0,16(sp)
    80001452:	64a2                	ld	s1,8(sp)
    80001454:	6105                	addi	sp,sp,32
    80001456:	8082                	ret

0000000080001458 <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001458:	7179                	addi	sp,sp,-48
    8000145a:	f406                	sd	ra,40(sp)
    8000145c:	f022                	sd	s0,32(sp)
    8000145e:	ec26                	sd	s1,24(sp)
    80001460:	e84a                	sd	s2,16(sp)
    80001462:	e44e                	sd	s3,8(sp)
    80001464:	1800                	addi	s0,sp,48
    80001466:	89aa                	mv	s3,a0
    80001468:	892e                	mv	s2,a1
  struct proc *p = myproc();
    8000146a:	999ff0ef          	jal	ra,80000e02 <myproc>
    8000146e:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001470:	39a040ef          	jal	ra,8000580a <acquire>
  release(lk);
    80001474:	854a                	mv	a0,s2
    80001476:	42c040ef          	jal	ra,800058a2 <release>

  // Go to sleep.
  p->chan = chan;
    8000147a:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    8000147e:	4789                	li	a5,2
    80001480:	cc9c                	sw	a5,24(s1)

  sched();
    80001482:	ef1ff0ef          	jal	ra,80001372 <sched>

  // Tidy up.
  p->chan = 0;
    80001486:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    8000148a:	8526                	mv	a0,s1
    8000148c:	416040ef          	jal	ra,800058a2 <release>
  acquire(lk);
    80001490:	854a                	mv	a0,s2
    80001492:	378040ef          	jal	ra,8000580a <acquire>
}
    80001496:	70a2                	ld	ra,40(sp)
    80001498:	7402                	ld	s0,32(sp)
    8000149a:	64e2                	ld	s1,24(sp)
    8000149c:	6942                	ld	s2,16(sp)
    8000149e:	69a2                	ld	s3,8(sp)
    800014a0:	6145                	addi	sp,sp,48
    800014a2:	8082                	ret

00000000800014a4 <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    800014a4:	7139                	addi	sp,sp,-64
    800014a6:	fc06                	sd	ra,56(sp)
    800014a8:	f822                	sd	s0,48(sp)
    800014aa:	f426                	sd	s1,40(sp)
    800014ac:	f04a                	sd	s2,32(sp)
    800014ae:	ec4e                	sd	s3,24(sp)
    800014b0:	e852                	sd	s4,16(sp)
    800014b2:	e456                	sd	s5,8(sp)
    800014b4:	0080                	addi	s0,sp,64
    800014b6:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    800014b8:	00007497          	auipc	s1,0x7
    800014bc:	94848493          	addi	s1,s1,-1720 # 80007e00 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    800014c0:	4989                	li	s3,2
        p->state = RUNNABLE;
    800014c2:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    800014c4:	0000c917          	auipc	s2,0xc
    800014c8:	53c90913          	addi	s2,s2,1340 # 8000da00 <tickslock>
    800014cc:	a801                	j	800014dc <wakeup+0x38>
      }
      release(&p->lock);
    800014ce:	8526                	mv	a0,s1
    800014d0:	3d2040ef          	jal	ra,800058a2 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    800014d4:	17048493          	addi	s1,s1,368
    800014d8:	03248263          	beq	s1,s2,800014fc <wakeup+0x58>
    if(p != myproc()){
    800014dc:	927ff0ef          	jal	ra,80000e02 <myproc>
    800014e0:	fea48ae3          	beq	s1,a0,800014d4 <wakeup+0x30>
      acquire(&p->lock);
    800014e4:	8526                	mv	a0,s1
    800014e6:	324040ef          	jal	ra,8000580a <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    800014ea:	4c9c                	lw	a5,24(s1)
    800014ec:	ff3791e3          	bne	a5,s3,800014ce <wakeup+0x2a>
    800014f0:	709c                	ld	a5,32(s1)
    800014f2:	fd479ee3          	bne	a5,s4,800014ce <wakeup+0x2a>
        p->state = RUNNABLE;
    800014f6:	0154ac23          	sw	s5,24(s1)
    800014fa:	bfd1                	j	800014ce <wakeup+0x2a>
    }
  }
}
    800014fc:	70e2                	ld	ra,56(sp)
    800014fe:	7442                	ld	s0,48(sp)
    80001500:	74a2                	ld	s1,40(sp)
    80001502:	7902                	ld	s2,32(sp)
    80001504:	69e2                	ld	s3,24(sp)
    80001506:	6a42                	ld	s4,16(sp)
    80001508:	6aa2                	ld	s5,8(sp)
    8000150a:	6121                	addi	sp,sp,64
    8000150c:	8082                	ret

000000008000150e <reparent>:
{
    8000150e:	7179                	addi	sp,sp,-48
    80001510:	f406                	sd	ra,40(sp)
    80001512:	f022                	sd	s0,32(sp)
    80001514:	ec26                	sd	s1,24(sp)
    80001516:	e84a                	sd	s2,16(sp)
    80001518:	e44e                	sd	s3,8(sp)
    8000151a:	e052                	sd	s4,0(sp)
    8000151c:	1800                	addi	s0,sp,48
    8000151e:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001520:	00007497          	auipc	s1,0x7
    80001524:	8e048493          	addi	s1,s1,-1824 # 80007e00 <proc>
      pp->parent = initproc;
    80001528:	00006a17          	auipc	s4,0x6
    8000152c:	468a0a13          	addi	s4,s4,1128 # 80007990 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001530:	0000c997          	auipc	s3,0xc
    80001534:	4d098993          	addi	s3,s3,1232 # 8000da00 <tickslock>
    80001538:	a029                	j	80001542 <reparent+0x34>
    8000153a:	17048493          	addi	s1,s1,368
    8000153e:	01348b63          	beq	s1,s3,80001554 <reparent+0x46>
    if(pp->parent == p){
    80001542:	60bc                	ld	a5,64(s1)
    80001544:	ff279be3          	bne	a5,s2,8000153a <reparent+0x2c>
      pp->parent = initproc;
    80001548:	000a3503          	ld	a0,0(s4)
    8000154c:	e0a8                	sd	a0,64(s1)
      wakeup(initproc);
    8000154e:	f57ff0ef          	jal	ra,800014a4 <wakeup>
    80001552:	b7e5                	j	8000153a <reparent+0x2c>
}
    80001554:	70a2                	ld	ra,40(sp)
    80001556:	7402                	ld	s0,32(sp)
    80001558:	64e2                	ld	s1,24(sp)
    8000155a:	6942                	ld	s2,16(sp)
    8000155c:	69a2                	ld	s3,8(sp)
    8000155e:	6a02                	ld	s4,0(sp)
    80001560:	6145                	addi	sp,sp,48
    80001562:	8082                	ret

0000000080001564 <exit>:
{
    80001564:	7179                	addi	sp,sp,-48
    80001566:	f406                	sd	ra,40(sp)
    80001568:	f022                	sd	s0,32(sp)
    8000156a:	ec26                	sd	s1,24(sp)
    8000156c:	e84a                	sd	s2,16(sp)
    8000156e:	e44e                	sd	s3,8(sp)
    80001570:	e052                	sd	s4,0(sp)
    80001572:	1800                	addi	s0,sp,48
    80001574:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80001576:	88dff0ef          	jal	ra,80000e02 <myproc>
    8000157a:	89aa                	mv	s3,a0
  if(p == initproc)
    8000157c:	00006797          	auipc	a5,0x6
    80001580:	4147b783          	ld	a5,1044(a5) # 80007990 <initproc>
    80001584:	0d850493          	addi	s1,a0,216
    80001588:	15850913          	addi	s2,a0,344
    8000158c:	00a79f63          	bne	a5,a0,800015aa <exit+0x46>
    panic("init exiting");
    80001590:	00006517          	auipc	a0,0x6
    80001594:	cd050513          	addi	a0,a0,-816 # 80007260 <etext+0x260>
    80001598:	75f030ef          	jal	ra,800054f6 <panic>
      fileclose(f);
    8000159c:	773010ef          	jal	ra,8000350e <fileclose>
      p->ofile[fd] = 0;
    800015a0:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    800015a4:	04a1                	addi	s1,s1,8
    800015a6:	01248563          	beq	s1,s2,800015b0 <exit+0x4c>
    if(p->ofile[fd]){
    800015aa:	6088                	ld	a0,0(s1)
    800015ac:	f965                	bnez	a0,8000159c <exit+0x38>
    800015ae:	bfdd                	j	800015a4 <exit+0x40>
  begin_op();
    800015b0:	343010ef          	jal	ra,800030f2 <begin_op>
  iput(p->cwd);
    800015b4:	1589b503          	ld	a0,344(s3)
    800015b8:	42a010ef          	jal	ra,800029e2 <iput>
  end_op();
    800015bc:	3a7010ef          	jal	ra,80003162 <end_op>
  p->cwd = 0;
    800015c0:	1409bc23          	sd	zero,344(s3)
  acquire(&wait_lock);
    800015c4:	00006497          	auipc	s1,0x6
    800015c8:	42448493          	addi	s1,s1,1060 # 800079e8 <wait_lock>
    800015cc:	8526                	mv	a0,s1
    800015ce:	23c040ef          	jal	ra,8000580a <acquire>
  reparent(p);
    800015d2:	854e                	mv	a0,s3
    800015d4:	f3bff0ef          	jal	ra,8000150e <reparent>
  wakeup(p->parent);
    800015d8:	0409b503          	ld	a0,64(s3)
    800015dc:	ec9ff0ef          	jal	ra,800014a4 <wakeup>
  acquire(&p->lock);
    800015e0:	854e                	mv	a0,s3
    800015e2:	228040ef          	jal	ra,8000580a <acquire>
  p->xstate = status;
    800015e6:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800015ea:	4795                	li	a5,5
    800015ec:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800015f0:	8526                	mv	a0,s1
    800015f2:	2b0040ef          	jal	ra,800058a2 <release>
  sched();
    800015f6:	d7dff0ef          	jal	ra,80001372 <sched>
  panic("zombie exit");
    800015fa:	00006517          	auipc	a0,0x6
    800015fe:	c7650513          	addi	a0,a0,-906 # 80007270 <etext+0x270>
    80001602:	6f5030ef          	jal	ra,800054f6 <panic>

0000000080001606 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    80001606:	7179                	addi	sp,sp,-48
    80001608:	f406                	sd	ra,40(sp)
    8000160a:	f022                	sd	s0,32(sp)
    8000160c:	ec26                	sd	s1,24(sp)
    8000160e:	e84a                	sd	s2,16(sp)
    80001610:	e44e                	sd	s3,8(sp)
    80001612:	1800                	addi	s0,sp,48
    80001614:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80001616:	00006497          	auipc	s1,0x6
    8000161a:	7ea48493          	addi	s1,s1,2026 # 80007e00 <proc>
    8000161e:	0000c997          	auipc	s3,0xc
    80001622:	3e298993          	addi	s3,s3,994 # 8000da00 <tickslock>
    acquire(&p->lock);
    80001626:	8526                	mv	a0,s1
    80001628:	1e2040ef          	jal	ra,8000580a <acquire>
    if(p->pid == pid){
    8000162c:	589c                	lw	a5,48(s1)
    8000162e:	01278b63          	beq	a5,s2,80001644 <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80001632:	8526                	mv	a0,s1
    80001634:	26e040ef          	jal	ra,800058a2 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80001638:	17048493          	addi	s1,s1,368
    8000163c:	ff3495e3          	bne	s1,s3,80001626 <kill+0x20>
  }
  return -1;
    80001640:	557d                	li	a0,-1
    80001642:	a819                	j	80001658 <kill+0x52>
      p->killed = 1;
    80001644:	4785                	li	a5,1
    80001646:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    80001648:	4c98                	lw	a4,24(s1)
    8000164a:	4789                	li	a5,2
    8000164c:	00f70d63          	beq	a4,a5,80001666 <kill+0x60>
      release(&p->lock);
    80001650:	8526                	mv	a0,s1
    80001652:	250040ef          	jal	ra,800058a2 <release>
      return 0;
    80001656:	4501                	li	a0,0
}
    80001658:	70a2                	ld	ra,40(sp)
    8000165a:	7402                	ld	s0,32(sp)
    8000165c:	64e2                	ld	s1,24(sp)
    8000165e:	6942                	ld	s2,16(sp)
    80001660:	69a2                	ld	s3,8(sp)
    80001662:	6145                	addi	sp,sp,48
    80001664:	8082                	ret
        p->state = RUNNABLE;
    80001666:	478d                	li	a5,3
    80001668:	cc9c                	sw	a5,24(s1)
    8000166a:	b7dd                	j	80001650 <kill+0x4a>

000000008000166c <setkilled>:

void
setkilled(struct proc *p)
{
    8000166c:	1101                	addi	sp,sp,-32
    8000166e:	ec06                	sd	ra,24(sp)
    80001670:	e822                	sd	s0,16(sp)
    80001672:	e426                	sd	s1,8(sp)
    80001674:	1000                	addi	s0,sp,32
    80001676:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001678:	192040ef          	jal	ra,8000580a <acquire>
  p->killed = 1;
    8000167c:	4785                	li	a5,1
    8000167e:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80001680:	8526                	mv	a0,s1
    80001682:	220040ef          	jal	ra,800058a2 <release>
}
    80001686:	60e2                	ld	ra,24(sp)
    80001688:	6442                	ld	s0,16(sp)
    8000168a:	64a2                	ld	s1,8(sp)
    8000168c:	6105                	addi	sp,sp,32
    8000168e:	8082                	ret

0000000080001690 <killed>:

int
killed(struct proc *p)
{
    80001690:	1101                	addi	sp,sp,-32
    80001692:	ec06                	sd	ra,24(sp)
    80001694:	e822                	sd	s0,16(sp)
    80001696:	e426                	sd	s1,8(sp)
    80001698:	e04a                	sd	s2,0(sp)
    8000169a:	1000                	addi	s0,sp,32
    8000169c:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    8000169e:	16c040ef          	jal	ra,8000580a <acquire>
  k = p->killed;
    800016a2:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    800016a6:	8526                	mv	a0,s1
    800016a8:	1fa040ef          	jal	ra,800058a2 <release>
  return k;
}
    800016ac:	854a                	mv	a0,s2
    800016ae:	60e2                	ld	ra,24(sp)
    800016b0:	6442                	ld	s0,16(sp)
    800016b2:	64a2                	ld	s1,8(sp)
    800016b4:	6902                	ld	s2,0(sp)
    800016b6:	6105                	addi	sp,sp,32
    800016b8:	8082                	ret

00000000800016ba <wait>:
{
    800016ba:	715d                	addi	sp,sp,-80
    800016bc:	e486                	sd	ra,72(sp)
    800016be:	e0a2                	sd	s0,64(sp)
    800016c0:	fc26                	sd	s1,56(sp)
    800016c2:	f84a                	sd	s2,48(sp)
    800016c4:	f44e                	sd	s3,40(sp)
    800016c6:	f052                	sd	s4,32(sp)
    800016c8:	ec56                	sd	s5,24(sp)
    800016ca:	e85a                	sd	s6,16(sp)
    800016cc:	e45e                	sd	s7,8(sp)
    800016ce:	e062                	sd	s8,0(sp)
    800016d0:	0880                	addi	s0,sp,80
    800016d2:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    800016d4:	f2eff0ef          	jal	ra,80000e02 <myproc>
    800016d8:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800016da:	00006517          	auipc	a0,0x6
    800016de:	30e50513          	addi	a0,a0,782 # 800079e8 <wait_lock>
    800016e2:	128040ef          	jal	ra,8000580a <acquire>
    havekids = 0;
    800016e6:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    800016e8:	4a15                	li	s4,5
        havekids = 1;
    800016ea:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800016ec:	0000c997          	auipc	s3,0xc
    800016f0:	31498993          	addi	s3,s3,788 # 8000da00 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800016f4:	00006c17          	auipc	s8,0x6
    800016f8:	2f4c0c13          	addi	s8,s8,756 # 800079e8 <wait_lock>
    havekids = 0;
    800016fc:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800016fe:	00006497          	auipc	s1,0x6
    80001702:	70248493          	addi	s1,s1,1794 # 80007e00 <proc>
    80001706:	a899                	j	8000175c <wait+0xa2>
          pid = pp->pid;
    80001708:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    8000170c:	000b0c63          	beqz	s6,80001724 <wait+0x6a>
    80001710:	4691                	li	a3,4
    80001712:	02c48613          	addi	a2,s1,44
    80001716:	85da                	mv	a1,s6
    80001718:	05893503          	ld	a0,88(s2)
    8000171c:	b5cff0ef          	jal	ra,80000a78 <copyout>
    80001720:	00054f63          	bltz	a0,8000173e <wait+0x84>
          freeproc(pp);
    80001724:	8526                	mv	a0,s1
    80001726:	87bff0ef          	jal	ra,80000fa0 <freeproc>
          release(&pp->lock);
    8000172a:	8526                	mv	a0,s1
    8000172c:	176040ef          	jal	ra,800058a2 <release>
          release(&wait_lock);
    80001730:	00006517          	auipc	a0,0x6
    80001734:	2b850513          	addi	a0,a0,696 # 800079e8 <wait_lock>
    80001738:	16a040ef          	jal	ra,800058a2 <release>
          return pid;
    8000173c:	a891                	j	80001790 <wait+0xd6>
            release(&pp->lock);
    8000173e:	8526                	mv	a0,s1
    80001740:	162040ef          	jal	ra,800058a2 <release>
            release(&wait_lock);
    80001744:	00006517          	auipc	a0,0x6
    80001748:	2a450513          	addi	a0,a0,676 # 800079e8 <wait_lock>
    8000174c:	156040ef          	jal	ra,800058a2 <release>
            return -1;
    80001750:	59fd                	li	s3,-1
    80001752:	a83d                	j	80001790 <wait+0xd6>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80001754:	17048493          	addi	s1,s1,368
    80001758:	03348063          	beq	s1,s3,80001778 <wait+0xbe>
      if(pp->parent == p){
    8000175c:	60bc                	ld	a5,64(s1)
    8000175e:	ff279be3          	bne	a5,s2,80001754 <wait+0x9a>
        acquire(&pp->lock);
    80001762:	8526                	mv	a0,s1
    80001764:	0a6040ef          	jal	ra,8000580a <acquire>
        if(pp->state == ZOMBIE){
    80001768:	4c9c                	lw	a5,24(s1)
    8000176a:	f9478fe3          	beq	a5,s4,80001708 <wait+0x4e>
        release(&pp->lock);
    8000176e:	8526                	mv	a0,s1
    80001770:	132040ef          	jal	ra,800058a2 <release>
        havekids = 1;
    80001774:	8756                	mv	a4,s5
    80001776:	bff9                	j	80001754 <wait+0x9a>
    if(!havekids || killed(p)){
    80001778:	c709                	beqz	a4,80001782 <wait+0xc8>
    8000177a:	854a                	mv	a0,s2
    8000177c:	f15ff0ef          	jal	ra,80001690 <killed>
    80001780:	c50d                	beqz	a0,800017aa <wait+0xf0>
      release(&wait_lock);
    80001782:	00006517          	auipc	a0,0x6
    80001786:	26650513          	addi	a0,a0,614 # 800079e8 <wait_lock>
    8000178a:	118040ef          	jal	ra,800058a2 <release>
      return -1;
    8000178e:	59fd                	li	s3,-1
}
    80001790:	854e                	mv	a0,s3
    80001792:	60a6                	ld	ra,72(sp)
    80001794:	6406                	ld	s0,64(sp)
    80001796:	74e2                	ld	s1,56(sp)
    80001798:	7942                	ld	s2,48(sp)
    8000179a:	79a2                	ld	s3,40(sp)
    8000179c:	7a02                	ld	s4,32(sp)
    8000179e:	6ae2                	ld	s5,24(sp)
    800017a0:	6b42                	ld	s6,16(sp)
    800017a2:	6ba2                	ld	s7,8(sp)
    800017a4:	6c02                	ld	s8,0(sp)
    800017a6:	6161                	addi	sp,sp,80
    800017a8:	8082                	ret
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800017aa:	85e2                	mv	a1,s8
    800017ac:	854a                	mv	a0,s2
    800017ae:	cabff0ef          	jal	ra,80001458 <sleep>
    havekids = 0;
    800017b2:	b7a9                	j	800016fc <wait+0x42>

00000000800017b4 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    800017b4:	7179                	addi	sp,sp,-48
    800017b6:	f406                	sd	ra,40(sp)
    800017b8:	f022                	sd	s0,32(sp)
    800017ba:	ec26                	sd	s1,24(sp)
    800017bc:	e84a                	sd	s2,16(sp)
    800017be:	e44e                	sd	s3,8(sp)
    800017c0:	e052                	sd	s4,0(sp)
    800017c2:	1800                	addi	s0,sp,48
    800017c4:	84aa                	mv	s1,a0
    800017c6:	892e                	mv	s2,a1
    800017c8:	89b2                	mv	s3,a2
    800017ca:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800017cc:	e36ff0ef          	jal	ra,80000e02 <myproc>
  if(user_dst){
    800017d0:	cc99                	beqz	s1,800017ee <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    800017d2:	86d2                	mv	a3,s4
    800017d4:	864e                	mv	a2,s3
    800017d6:	85ca                	mv	a1,s2
    800017d8:	6d28                	ld	a0,88(a0)
    800017da:	a9eff0ef          	jal	ra,80000a78 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800017de:	70a2                	ld	ra,40(sp)
    800017e0:	7402                	ld	s0,32(sp)
    800017e2:	64e2                	ld	s1,24(sp)
    800017e4:	6942                	ld	s2,16(sp)
    800017e6:	69a2                	ld	s3,8(sp)
    800017e8:	6a02                	ld	s4,0(sp)
    800017ea:	6145                	addi	sp,sp,48
    800017ec:	8082                	ret
    memmove((char *)dst, src, len);
    800017ee:	000a061b          	sext.w	a2,s4
    800017f2:	85ce                	mv	a1,s3
    800017f4:	854a                	mv	a0,s2
    800017f6:	9b3fe0ef          	jal	ra,800001a8 <memmove>
    return 0;
    800017fa:	8526                	mv	a0,s1
    800017fc:	b7cd                	j	800017de <either_copyout+0x2a>

00000000800017fe <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800017fe:	7179                	addi	sp,sp,-48
    80001800:	f406                	sd	ra,40(sp)
    80001802:	f022                	sd	s0,32(sp)
    80001804:	ec26                	sd	s1,24(sp)
    80001806:	e84a                	sd	s2,16(sp)
    80001808:	e44e                	sd	s3,8(sp)
    8000180a:	e052                	sd	s4,0(sp)
    8000180c:	1800                	addi	s0,sp,48
    8000180e:	892a                	mv	s2,a0
    80001810:	84ae                	mv	s1,a1
    80001812:	89b2                	mv	s3,a2
    80001814:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80001816:	decff0ef          	jal	ra,80000e02 <myproc>
  if(user_src){
    8000181a:	cc99                	beqz	s1,80001838 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    8000181c:	86d2                	mv	a3,s4
    8000181e:	864e                	mv	a2,s3
    80001820:	85ca                	mv	a1,s2
    80001822:	6d28                	ld	a0,88(a0)
    80001824:	b0cff0ef          	jal	ra,80000b30 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80001828:	70a2                	ld	ra,40(sp)
    8000182a:	7402                	ld	s0,32(sp)
    8000182c:	64e2                	ld	s1,24(sp)
    8000182e:	6942                	ld	s2,16(sp)
    80001830:	69a2                	ld	s3,8(sp)
    80001832:	6a02                	ld	s4,0(sp)
    80001834:	6145                	addi	sp,sp,48
    80001836:	8082                	ret
    memmove(dst, (char*)src, len);
    80001838:	000a061b          	sext.w	a2,s4
    8000183c:	85ce                	mv	a1,s3
    8000183e:	854a                	mv	a0,s2
    80001840:	969fe0ef          	jal	ra,800001a8 <memmove>
    return 0;
    80001844:	8526                	mv	a0,s1
    80001846:	b7cd                	j	80001828 <either_copyin+0x2a>

0000000080001848 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80001848:	715d                	addi	sp,sp,-80
    8000184a:	e486                	sd	ra,72(sp)
    8000184c:	e0a2                	sd	s0,64(sp)
    8000184e:	fc26                	sd	s1,56(sp)
    80001850:	f84a                	sd	s2,48(sp)
    80001852:	f44e                	sd	s3,40(sp)
    80001854:	f052                	sd	s4,32(sp)
    80001856:	ec56                	sd	s5,24(sp)
    80001858:	e85a                	sd	s6,16(sp)
    8000185a:	e45e                	sd	s7,8(sp)
    8000185c:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    8000185e:	00005517          	auipc	a0,0x5
    80001862:	7ea50513          	addi	a0,a0,2026 # 80007048 <etext+0x48>
    80001866:	1dd030ef          	jal	ra,80005242 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    8000186a:	00006497          	auipc	s1,0x6
    8000186e:	6f648493          	addi	s1,s1,1782 # 80007f60 <proc+0x160>
    80001872:	0000c917          	auipc	s2,0xc
    80001876:	2ee90913          	addi	s2,s2,750 # 8000db60 <bcache+0x148>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000187a:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    8000187c:	00006997          	auipc	s3,0x6
    80001880:	a0498993          	addi	s3,s3,-1532 # 80007280 <etext+0x280>
    printf("%d %s %s", p->pid, state, p->name);
    80001884:	00006a97          	auipc	s5,0x6
    80001888:	a04a8a93          	addi	s5,s5,-1532 # 80007288 <etext+0x288>
    printf("\n");
    8000188c:	00005a17          	auipc	s4,0x5
    80001890:	7bca0a13          	addi	s4,s4,1980 # 80007048 <etext+0x48>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80001894:	00006b97          	auipc	s7,0x6
    80001898:	a34b8b93          	addi	s7,s7,-1484 # 800072c8 <states.0>
    8000189c:	a829                	j	800018b6 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    8000189e:	ed06a583          	lw	a1,-304(a3)
    800018a2:	8556                	mv	a0,s5
    800018a4:	19f030ef          	jal	ra,80005242 <printf>
    printf("\n");
    800018a8:	8552                	mv	a0,s4
    800018aa:	199030ef          	jal	ra,80005242 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800018ae:	17048493          	addi	s1,s1,368
    800018b2:	03248263          	beq	s1,s2,800018d6 <procdump+0x8e>
    if(p->state == UNUSED)
    800018b6:	86a6                	mv	a3,s1
    800018b8:	eb84a783          	lw	a5,-328(s1)
    800018bc:	dbed                	beqz	a5,800018ae <procdump+0x66>
      state = "???";
    800018be:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800018c0:	fcfb6fe3          	bltu	s6,a5,8000189e <procdump+0x56>
    800018c4:	02079713          	slli	a4,a5,0x20
    800018c8:	01d75793          	srli	a5,a4,0x1d
    800018cc:	97de                	add	a5,a5,s7
    800018ce:	6390                	ld	a2,0(a5)
    800018d0:	f679                	bnez	a2,8000189e <procdump+0x56>
      state = "???";
    800018d2:	864e                	mv	a2,s3
    800018d4:	b7e9                	j	8000189e <procdump+0x56>
  }
}
    800018d6:	60a6                	ld	ra,72(sp)
    800018d8:	6406                	ld	s0,64(sp)
    800018da:	74e2                	ld	s1,56(sp)
    800018dc:	7942                	ld	s2,48(sp)
    800018de:	79a2                	ld	s3,40(sp)
    800018e0:	7a02                	ld	s4,32(sp)
    800018e2:	6ae2                	ld	s5,24(sp)
    800018e4:	6b42                	ld	s6,16(sp)
    800018e6:	6ba2                	ld	s7,8(sp)
    800018e8:	6161                	addi	sp,sp,80
    800018ea:	8082                	ret

00000000800018ec <swtch>:
    800018ec:	00153023          	sd	ra,0(a0)
    800018f0:	00253423          	sd	sp,8(a0)
    800018f4:	e900                	sd	s0,16(a0)
    800018f6:	ed04                	sd	s1,24(a0)
    800018f8:	03253023          	sd	s2,32(a0)
    800018fc:	03353423          	sd	s3,40(a0)
    80001900:	03453823          	sd	s4,48(a0)
    80001904:	03553c23          	sd	s5,56(a0)
    80001908:	05653023          	sd	s6,64(a0)
    8000190c:	05753423          	sd	s7,72(a0)
    80001910:	05853823          	sd	s8,80(a0)
    80001914:	05953c23          	sd	s9,88(a0)
    80001918:	07a53023          	sd	s10,96(a0)
    8000191c:	07b53423          	sd	s11,104(a0)
    80001920:	0005b083          	ld	ra,0(a1)
    80001924:	0085b103          	ld	sp,8(a1)
    80001928:	6980                	ld	s0,16(a1)
    8000192a:	6d84                	ld	s1,24(a1)
    8000192c:	0205b903          	ld	s2,32(a1)
    80001930:	0285b983          	ld	s3,40(a1)
    80001934:	0305ba03          	ld	s4,48(a1)
    80001938:	0385ba83          	ld	s5,56(a1)
    8000193c:	0405bb03          	ld	s6,64(a1)
    80001940:	0485bb83          	ld	s7,72(a1)
    80001944:	0505bc03          	ld	s8,80(a1)
    80001948:	0585bc83          	ld	s9,88(a1)
    8000194c:	0605bd03          	ld	s10,96(a1)
    80001950:	0685bd83          	ld	s11,104(a1)
    80001954:	8082                	ret

0000000080001956 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80001956:	1141                	addi	sp,sp,-16
    80001958:	e406                	sd	ra,8(sp)
    8000195a:	e022                	sd	s0,0(sp)
    8000195c:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    8000195e:	00006597          	auipc	a1,0x6
    80001962:	99a58593          	addi	a1,a1,-1638 # 800072f8 <states.0+0x30>
    80001966:	0000c517          	auipc	a0,0xc
    8000196a:	09a50513          	addi	a0,a0,154 # 8000da00 <tickslock>
    8000196e:	61d030ef          	jal	ra,8000578a <initlock>
}
    80001972:	60a2                	ld	ra,8(sp)
    80001974:	6402                	ld	s0,0(sp)
    80001976:	0141                	addi	sp,sp,16
    80001978:	8082                	ret

000000008000197a <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    8000197a:	1141                	addi	sp,sp,-16
    8000197c:	e422                	sd	s0,8(sp)
    8000197e:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001980:	00003797          	auipc	a5,0x3
    80001984:	e6078793          	addi	a5,a5,-416 # 800047e0 <kernelvec>
    80001988:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    8000198c:	6422                	ld	s0,8(sp)
    8000198e:	0141                	addi	sp,sp,16
    80001990:	8082                	ret

0000000080001992 <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    80001992:	1141                	addi	sp,sp,-16
    80001994:	e406                	sd	ra,8(sp)
    80001996:	e022                	sd	s0,0(sp)
    80001998:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    8000199a:	c68ff0ef          	jal	ra,80000e02 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000199e:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800019a2:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800019a4:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    800019a8:	00004617          	auipc	a2,0x4
    800019ac:	65860613          	addi	a2,a2,1624 # 80006000 <_trampoline>
    800019b0:	00004697          	auipc	a3,0x4
    800019b4:	65068693          	addi	a3,a3,1616 # 80006000 <_trampoline>
    800019b8:	8e91                	sub	a3,a3,a2
    800019ba:	040007b7          	lui	a5,0x4000
    800019be:	17fd                	addi	a5,a5,-1
    800019c0:	07b2                	slli	a5,a5,0xc
    800019c2:	96be                	add	a3,a3,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    800019c4:	10569073          	csrw	stvec,a3
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800019c8:	7138                	ld	a4,96(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    800019ca:	180026f3          	csrr	a3,satp
    800019ce:	e314                	sd	a3,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    800019d0:	7138                	ld	a4,96(a0)
    800019d2:	6534                	ld	a3,72(a0)
    800019d4:	6585                	lui	a1,0x1
    800019d6:	96ae                	add	a3,a3,a1
    800019d8:	e714                	sd	a3,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    800019da:	7138                	ld	a4,96(a0)
    800019dc:	00000697          	auipc	a3,0x0
    800019e0:	10c68693          	addi	a3,a3,268 # 80001ae8 <usertrap>
    800019e4:	eb14                	sd	a3,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    800019e6:	7138                	ld	a4,96(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    800019e8:	8692                	mv	a3,tp
    800019ea:	f314                	sd	a3,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800019ec:	100026f3          	csrr	a3,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    800019f0:	eff6f693          	andi	a3,a3,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    800019f4:	0206e693          	ori	a3,a3,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800019f8:	10069073          	csrw	sstatus,a3
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800019fc:	7138                	ld	a4,96(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    800019fe:	6f18                	ld	a4,24(a4)
    80001a00:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    80001a04:	6d28                	ld	a0,88(a0)
    80001a06:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001a08:	00004717          	auipc	a4,0x4
    80001a0c:	69470713          	addi	a4,a4,1684 # 8000609c <userret>
    80001a10:	8f11                	sub	a4,a4,a2
    80001a12:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001a14:	577d                	li	a4,-1
    80001a16:	177e                	slli	a4,a4,0x3f
    80001a18:	8d59                	or	a0,a0,a4
    80001a1a:	9782                	jalr	a5
}
    80001a1c:	60a2                	ld	ra,8(sp)
    80001a1e:	6402                	ld	s0,0(sp)
    80001a20:	0141                	addi	sp,sp,16
    80001a22:	8082                	ret

0000000080001a24 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80001a24:	1101                	addi	sp,sp,-32
    80001a26:	ec06                	sd	ra,24(sp)
    80001a28:	e822                	sd	s0,16(sp)
    80001a2a:	e426                	sd	s1,8(sp)
    80001a2c:	1000                	addi	s0,sp,32
  if(cpuid() == 0){
    80001a2e:	ba8ff0ef          	jal	ra,80000dd6 <cpuid>
    80001a32:	cd19                	beqz	a0,80001a50 <clockintr+0x2c>
  asm volatile("csrr %0, time" : "=r" (x) );
    80001a34:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    80001a38:	000f4737          	lui	a4,0xf4
    80001a3c:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80001a40:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80001a42:	14d79073          	csrw	0x14d,a5
}
    80001a46:	60e2                	ld	ra,24(sp)
    80001a48:	6442                	ld	s0,16(sp)
    80001a4a:	64a2                	ld	s1,8(sp)
    80001a4c:	6105                	addi	sp,sp,32
    80001a4e:	8082                	ret
    acquire(&tickslock);
    80001a50:	0000c497          	auipc	s1,0xc
    80001a54:	fb048493          	addi	s1,s1,-80 # 8000da00 <tickslock>
    80001a58:	8526                	mv	a0,s1
    80001a5a:	5b1030ef          	jal	ra,8000580a <acquire>
    ticks++;
    80001a5e:	00006517          	auipc	a0,0x6
    80001a62:	f3a50513          	addi	a0,a0,-198 # 80007998 <ticks>
    80001a66:	411c                	lw	a5,0(a0)
    80001a68:	2785                	addiw	a5,a5,1
    80001a6a:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    80001a6c:	a39ff0ef          	jal	ra,800014a4 <wakeup>
    release(&tickslock);
    80001a70:	8526                	mv	a0,s1
    80001a72:	631030ef          	jal	ra,800058a2 <release>
    80001a76:	bf7d                	j	80001a34 <clockintr+0x10>

0000000080001a78 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80001a78:	1101                	addi	sp,sp,-32
    80001a7a:	ec06                	sd	ra,24(sp)
    80001a7c:	e822                	sd	s0,16(sp)
    80001a7e:	e426                	sd	s1,8(sp)
    80001a80:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001a82:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80001a86:	57fd                	li	a5,-1
    80001a88:	17fe                	slli	a5,a5,0x3f
    80001a8a:	07a5                	addi	a5,a5,9
    80001a8c:	00f70d63          	beq	a4,a5,80001aa6 <devintr+0x2e>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80001a90:	57fd                	li	a5,-1
    80001a92:	17fe                	slli	a5,a5,0x3f
    80001a94:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80001a96:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80001a98:	04f70463          	beq	a4,a5,80001ae0 <devintr+0x68>
  }
}
    80001a9c:	60e2                	ld	ra,24(sp)
    80001a9e:	6442                	ld	s0,16(sp)
    80001aa0:	64a2                	ld	s1,8(sp)
    80001aa2:	6105                	addi	sp,sp,32
    80001aa4:	8082                	ret
    int irq = plic_claim();
    80001aa6:	5e3020ef          	jal	ra,80004888 <plic_claim>
    80001aaa:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80001aac:	47a9                	li	a5,10
    80001aae:	02f50363          	beq	a0,a5,80001ad4 <devintr+0x5c>
    } else if(irq == VIRTIO0_IRQ){
    80001ab2:	4785                	li	a5,1
    80001ab4:	02f50363          	beq	a0,a5,80001ada <devintr+0x62>
    return 1;
    80001ab8:	4505                	li	a0,1
    } else if(irq){
    80001aba:	d0ed                	beqz	s1,80001a9c <devintr+0x24>
      printf("unexpected interrupt irq=%d\n", irq);
    80001abc:	85a6                	mv	a1,s1
    80001abe:	00006517          	auipc	a0,0x6
    80001ac2:	84250513          	addi	a0,a0,-1982 # 80007300 <states.0+0x38>
    80001ac6:	77c030ef          	jal	ra,80005242 <printf>
      plic_complete(irq);
    80001aca:	8526                	mv	a0,s1
    80001acc:	5dd020ef          	jal	ra,800048a8 <plic_complete>
    return 1;
    80001ad0:	4505                	li	a0,1
    80001ad2:	b7e9                	j	80001a9c <devintr+0x24>
      uartintr();
    80001ad4:	47b030ef          	jal	ra,8000574e <uartintr>
    80001ad8:	bfcd                	j	80001aca <devintr+0x52>
      virtio_disk_intr();
    80001ada:	23e030ef          	jal	ra,80004d18 <virtio_disk_intr>
    80001ade:	b7f5                	j	80001aca <devintr+0x52>
    clockintr();
    80001ae0:	f45ff0ef          	jal	ra,80001a24 <clockintr>
    return 2;
    80001ae4:	4509                	li	a0,2
    80001ae6:	bf5d                	j	80001a9c <devintr+0x24>

0000000080001ae8 <usertrap>:
{
    80001ae8:	1101                	addi	sp,sp,-32
    80001aea:	ec06                	sd	ra,24(sp)
    80001aec:	e822                	sd	s0,16(sp)
    80001aee:	e426                	sd	s1,8(sp)
    80001af0:	e04a                	sd	s2,0(sp)
    80001af2:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001af4:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    80001af8:	1007f793          	andi	a5,a5,256
    80001afc:	ef85                	bnez	a5,80001b34 <usertrap+0x4c>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001afe:	00003797          	auipc	a5,0x3
    80001b02:	ce278793          	addi	a5,a5,-798 # 800047e0 <kernelvec>
    80001b06:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80001b0a:	af8ff0ef          	jal	ra,80000e02 <myproc>
    80001b0e:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80001b10:	713c                	ld	a5,96(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001b12:	14102773          	csrr	a4,sepc
    80001b16:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001b18:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    80001b1c:	47a1                	li	a5,8
    80001b1e:	02f70163          	beq	a4,a5,80001b40 <usertrap+0x58>
  } else if((which_dev = devintr()) != 0){
    80001b22:	f57ff0ef          	jal	ra,80001a78 <devintr>
    80001b26:	892a                	mv	s2,a0
    80001b28:	c135                	beqz	a0,80001b8c <usertrap+0xa4>
  if(killed(p))
    80001b2a:	8526                	mv	a0,s1
    80001b2c:	b65ff0ef          	jal	ra,80001690 <killed>
    80001b30:	cd1d                	beqz	a0,80001b6e <usertrap+0x86>
    80001b32:	a81d                	j	80001b68 <usertrap+0x80>
    panic("usertrap: not from user mode");
    80001b34:	00005517          	auipc	a0,0x5
    80001b38:	7ec50513          	addi	a0,a0,2028 # 80007320 <states.0+0x58>
    80001b3c:	1bb030ef          	jal	ra,800054f6 <panic>
    if(killed(p))
    80001b40:	b51ff0ef          	jal	ra,80001690 <killed>
    80001b44:	e121                	bnez	a0,80001b84 <usertrap+0x9c>
    p->trapframe->epc += 4;
    80001b46:	70b8                	ld	a4,96(s1)
    80001b48:	6f1c                	ld	a5,24(a4)
    80001b4a:	0791                	addi	a5,a5,4
    80001b4c:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001b4e:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001b52:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001b56:	10079073          	csrw	sstatus,a5
    syscall();
    80001b5a:	248000ef          	jal	ra,80001da2 <syscall>
  if(killed(p))
    80001b5e:	8526                	mv	a0,s1
    80001b60:	b31ff0ef          	jal	ra,80001690 <killed>
    80001b64:	c901                	beqz	a0,80001b74 <usertrap+0x8c>
    80001b66:	4901                	li	s2,0
    exit(-1);
    80001b68:	557d                	li	a0,-1
    80001b6a:	9fbff0ef          	jal	ra,80001564 <exit>
  if(which_dev == 2)
    80001b6e:	4789                	li	a5,2
    80001b70:	04f90563          	beq	s2,a5,80001bba <usertrap+0xd2>
  usertrapret();
    80001b74:	e1fff0ef          	jal	ra,80001992 <usertrapret>
}
    80001b78:	60e2                	ld	ra,24(sp)
    80001b7a:	6442                	ld	s0,16(sp)
    80001b7c:	64a2                	ld	s1,8(sp)
    80001b7e:	6902                	ld	s2,0(sp)
    80001b80:	6105                	addi	sp,sp,32
    80001b82:	8082                	ret
      exit(-1);
    80001b84:	557d                	li	a0,-1
    80001b86:	9dfff0ef          	jal	ra,80001564 <exit>
    80001b8a:	bf75                	j	80001b46 <usertrap+0x5e>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001b8c:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80001b90:	5890                	lw	a2,48(s1)
    80001b92:	00005517          	auipc	a0,0x5
    80001b96:	7ae50513          	addi	a0,a0,1966 # 80007340 <states.0+0x78>
    80001b9a:	6a8030ef          	jal	ra,80005242 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001b9e:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001ba2:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80001ba6:	00005517          	auipc	a0,0x5
    80001baa:	7ca50513          	addi	a0,a0,1994 # 80007370 <states.0+0xa8>
    80001bae:	694030ef          	jal	ra,80005242 <printf>
    setkilled(p);
    80001bb2:	8526                	mv	a0,s1
    80001bb4:	ab9ff0ef          	jal	ra,8000166c <setkilled>
    80001bb8:	b75d                	j	80001b5e <usertrap+0x76>
    yield();
    80001bba:	873ff0ef          	jal	ra,8000142c <yield>
    80001bbe:	bf5d                	j	80001b74 <usertrap+0x8c>

0000000080001bc0 <kerneltrap>:
{
    80001bc0:	7179                	addi	sp,sp,-48
    80001bc2:	f406                	sd	ra,40(sp)
    80001bc4:	f022                	sd	s0,32(sp)
    80001bc6:	ec26                	sd	s1,24(sp)
    80001bc8:	e84a                	sd	s2,16(sp)
    80001bca:	e44e                	sd	s3,8(sp)
    80001bcc:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001bce:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001bd2:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001bd6:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    80001bda:	1004f793          	andi	a5,s1,256
    80001bde:	c795                	beqz	a5,80001c0a <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001be0:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001be4:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80001be6:	eb85                	bnez	a5,80001c16 <kerneltrap+0x56>
  if((which_dev = devintr()) == 0){
    80001be8:	e91ff0ef          	jal	ra,80001a78 <devintr>
    80001bec:	c91d                	beqz	a0,80001c22 <kerneltrap+0x62>
  if(which_dev == 2 && myproc() != 0)
    80001bee:	4789                	li	a5,2
    80001bf0:	04f50a63          	beq	a0,a5,80001c44 <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001bf4:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001bf8:	10049073          	csrw	sstatus,s1
}
    80001bfc:	70a2                	ld	ra,40(sp)
    80001bfe:	7402                	ld	s0,32(sp)
    80001c00:	64e2                	ld	s1,24(sp)
    80001c02:	6942                	ld	s2,16(sp)
    80001c04:	69a2                	ld	s3,8(sp)
    80001c06:	6145                	addi	sp,sp,48
    80001c08:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80001c0a:	00005517          	auipc	a0,0x5
    80001c0e:	78e50513          	addi	a0,a0,1934 # 80007398 <states.0+0xd0>
    80001c12:	0e5030ef          	jal	ra,800054f6 <panic>
    panic("kerneltrap: interrupts enabled");
    80001c16:	00005517          	auipc	a0,0x5
    80001c1a:	7aa50513          	addi	a0,a0,1962 # 800073c0 <states.0+0xf8>
    80001c1e:	0d9030ef          	jal	ra,800054f6 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001c22:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001c26:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80001c2a:	85ce                	mv	a1,s3
    80001c2c:	00005517          	auipc	a0,0x5
    80001c30:	7b450513          	addi	a0,a0,1972 # 800073e0 <states.0+0x118>
    80001c34:	60e030ef          	jal	ra,80005242 <printf>
    panic("kerneltrap");
    80001c38:	00005517          	auipc	a0,0x5
    80001c3c:	7d050513          	addi	a0,a0,2000 # 80007408 <states.0+0x140>
    80001c40:	0b7030ef          	jal	ra,800054f6 <panic>
  if(which_dev == 2 && myproc() != 0)
    80001c44:	9beff0ef          	jal	ra,80000e02 <myproc>
    80001c48:	d555                	beqz	a0,80001bf4 <kerneltrap+0x34>
    yield();
    80001c4a:	fe2ff0ef          	jal	ra,8000142c <yield>
    80001c4e:	b75d                	j	80001bf4 <kerneltrap+0x34>

0000000080001c50 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80001c50:	1101                	addi	sp,sp,-32
    80001c52:	ec06                	sd	ra,24(sp)
    80001c54:	e822                	sd	s0,16(sp)
    80001c56:	e426                	sd	s1,8(sp)
    80001c58:	1000                	addi	s0,sp,32
    80001c5a:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001c5c:	9a6ff0ef          	jal	ra,80000e02 <myproc>
  switch (n) {
    80001c60:	4795                	li	a5,5
    80001c62:	0497e163          	bltu	a5,s1,80001ca4 <argraw+0x54>
    80001c66:	048a                	slli	s1,s1,0x2
    80001c68:	00005717          	auipc	a4,0x5
    80001c6c:	7d870713          	addi	a4,a4,2008 # 80007440 <states.0+0x178>
    80001c70:	94ba                	add	s1,s1,a4
    80001c72:	409c                	lw	a5,0(s1)
    80001c74:	97ba                	add	a5,a5,a4
    80001c76:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80001c78:	713c                	ld	a5,96(a0)
    80001c7a:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80001c7c:	60e2                	ld	ra,24(sp)
    80001c7e:	6442                	ld	s0,16(sp)
    80001c80:	64a2                	ld	s1,8(sp)
    80001c82:	6105                	addi	sp,sp,32
    80001c84:	8082                	ret
    return p->trapframe->a1;
    80001c86:	713c                	ld	a5,96(a0)
    80001c88:	7fa8                	ld	a0,120(a5)
    80001c8a:	bfcd                	j	80001c7c <argraw+0x2c>
    return p->trapframe->a2;
    80001c8c:	713c                	ld	a5,96(a0)
    80001c8e:	63c8                	ld	a0,128(a5)
    80001c90:	b7f5                	j	80001c7c <argraw+0x2c>
    return p->trapframe->a3;
    80001c92:	713c                	ld	a5,96(a0)
    80001c94:	67c8                	ld	a0,136(a5)
    80001c96:	b7dd                	j	80001c7c <argraw+0x2c>
    return p->trapframe->a4;
    80001c98:	713c                	ld	a5,96(a0)
    80001c9a:	6bc8                	ld	a0,144(a5)
    80001c9c:	b7c5                	j	80001c7c <argraw+0x2c>
    return p->trapframe->a5;
    80001c9e:	713c                	ld	a5,96(a0)
    80001ca0:	6fc8                	ld	a0,152(a5)
    80001ca2:	bfe9                	j	80001c7c <argraw+0x2c>
  panic("argraw");
    80001ca4:	00005517          	auipc	a0,0x5
    80001ca8:	77450513          	addi	a0,a0,1908 # 80007418 <states.0+0x150>
    80001cac:	04b030ef          	jal	ra,800054f6 <panic>

0000000080001cb0 <fetchaddr>:
{
    80001cb0:	1101                	addi	sp,sp,-32
    80001cb2:	ec06                	sd	ra,24(sp)
    80001cb4:	e822                	sd	s0,16(sp)
    80001cb6:	e426                	sd	s1,8(sp)
    80001cb8:	e04a                	sd	s2,0(sp)
    80001cba:	1000                	addi	s0,sp,32
    80001cbc:	84aa                	mv	s1,a0
    80001cbe:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001cc0:	942ff0ef          	jal	ra,80000e02 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80001cc4:	693c                	ld	a5,80(a0)
    80001cc6:	02f4f663          	bgeu	s1,a5,80001cf2 <fetchaddr+0x42>
    80001cca:	00848713          	addi	a4,s1,8
    80001cce:	02e7e463          	bltu	a5,a4,80001cf6 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80001cd2:	46a1                	li	a3,8
    80001cd4:	8626                	mv	a2,s1
    80001cd6:	85ca                	mv	a1,s2
    80001cd8:	6d28                	ld	a0,88(a0)
    80001cda:	e57fe0ef          	jal	ra,80000b30 <copyin>
    80001cde:	00a03533          	snez	a0,a0
    80001ce2:	40a00533          	neg	a0,a0
}
    80001ce6:	60e2                	ld	ra,24(sp)
    80001ce8:	6442                	ld	s0,16(sp)
    80001cea:	64a2                	ld	s1,8(sp)
    80001cec:	6902                	ld	s2,0(sp)
    80001cee:	6105                	addi	sp,sp,32
    80001cf0:	8082                	ret
    return -1;
    80001cf2:	557d                	li	a0,-1
    80001cf4:	bfcd                	j	80001ce6 <fetchaddr+0x36>
    80001cf6:	557d                	li	a0,-1
    80001cf8:	b7fd                	j	80001ce6 <fetchaddr+0x36>

0000000080001cfa <fetchstr>:
{
    80001cfa:	7179                	addi	sp,sp,-48
    80001cfc:	f406                	sd	ra,40(sp)
    80001cfe:	f022                	sd	s0,32(sp)
    80001d00:	ec26                	sd	s1,24(sp)
    80001d02:	e84a                	sd	s2,16(sp)
    80001d04:	e44e                	sd	s3,8(sp)
    80001d06:	1800                	addi	s0,sp,48
    80001d08:	892a                	mv	s2,a0
    80001d0a:	84ae                	mv	s1,a1
    80001d0c:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    80001d0e:	8f4ff0ef          	jal	ra,80000e02 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80001d12:	86ce                	mv	a3,s3
    80001d14:	864a                	mv	a2,s2
    80001d16:	85a6                	mv	a1,s1
    80001d18:	6d28                	ld	a0,88(a0)
    80001d1a:	e9dfe0ef          	jal	ra,80000bb6 <copyinstr>
    80001d1e:	00054c63          	bltz	a0,80001d36 <fetchstr+0x3c>
  return strlen(buf);
    80001d22:	8526                	mv	a0,s1
    80001d24:	da0fe0ef          	jal	ra,800002c4 <strlen>
}
    80001d28:	70a2                	ld	ra,40(sp)
    80001d2a:	7402                	ld	s0,32(sp)
    80001d2c:	64e2                	ld	s1,24(sp)
    80001d2e:	6942                	ld	s2,16(sp)
    80001d30:	69a2                	ld	s3,8(sp)
    80001d32:	6145                	addi	sp,sp,48
    80001d34:	8082                	ret
    return -1;
    80001d36:	557d                	li	a0,-1
    80001d38:	bfc5                	j	80001d28 <fetchstr+0x2e>

0000000080001d3a <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80001d3a:	1101                	addi	sp,sp,-32
    80001d3c:	ec06                	sd	ra,24(sp)
    80001d3e:	e822                	sd	s0,16(sp)
    80001d40:	e426                	sd	s1,8(sp)
    80001d42:	1000                	addi	s0,sp,32
    80001d44:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001d46:	f0bff0ef          	jal	ra,80001c50 <argraw>
    80001d4a:	c088                	sw	a0,0(s1)
}
    80001d4c:	60e2                	ld	ra,24(sp)
    80001d4e:	6442                	ld	s0,16(sp)
    80001d50:	64a2                	ld	s1,8(sp)
    80001d52:	6105                	addi	sp,sp,32
    80001d54:	8082                	ret

0000000080001d56 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80001d56:	1101                	addi	sp,sp,-32
    80001d58:	ec06                	sd	ra,24(sp)
    80001d5a:	e822                	sd	s0,16(sp)
    80001d5c:	e426                	sd	s1,8(sp)
    80001d5e:	1000                	addi	s0,sp,32
    80001d60:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001d62:	eefff0ef          	jal	ra,80001c50 <argraw>
    80001d66:	e088                	sd	a0,0(s1)
}
    80001d68:	60e2                	ld	ra,24(sp)
    80001d6a:	6442                	ld	s0,16(sp)
    80001d6c:	64a2                	ld	s1,8(sp)
    80001d6e:	6105                	addi	sp,sp,32
    80001d70:	8082                	ret

0000000080001d72 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80001d72:	7179                	addi	sp,sp,-48
    80001d74:	f406                	sd	ra,40(sp)
    80001d76:	f022                	sd	s0,32(sp)
    80001d78:	ec26                	sd	s1,24(sp)
    80001d7a:	e84a                	sd	s2,16(sp)
    80001d7c:	1800                	addi	s0,sp,48
    80001d7e:	84ae                	mv	s1,a1
    80001d80:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80001d82:	fd840593          	addi	a1,s0,-40
    80001d86:	fd1ff0ef          	jal	ra,80001d56 <argaddr>
  return fetchstr(addr, buf, max);
    80001d8a:	864a                	mv	a2,s2
    80001d8c:	85a6                	mv	a1,s1
    80001d8e:	fd843503          	ld	a0,-40(s0)
    80001d92:	f69ff0ef          	jal	ra,80001cfa <fetchstr>
}
    80001d96:	70a2                	ld	ra,40(sp)
    80001d98:	7402                	ld	s0,32(sp)
    80001d9a:	64e2                	ld	s1,24(sp)
    80001d9c:	6942                	ld	s2,16(sp)
    80001d9e:	6145                	addi	sp,sp,48
    80001da0:	8082                	ret

0000000080001da2 <syscall>:



void
syscall(void)
{
    80001da2:	1101                	addi	sp,sp,-32
    80001da4:	ec06                	sd	ra,24(sp)
    80001da6:	e822                	sd	s0,16(sp)
    80001da8:	e426                	sd	s1,8(sp)
    80001daa:	e04a                	sd	s2,0(sp)
    80001dac:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80001dae:	854ff0ef          	jal	ra,80000e02 <myproc>
    80001db2:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80001db4:	06053903          	ld	s2,96(a0)
    80001db8:	0a893783          	ld	a5,168(s2)
    80001dbc:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80001dc0:	37fd                	addiw	a5,a5,-1
    80001dc2:	02200713          	li	a4,34
    80001dc6:	00f76f63          	bltu	a4,a5,80001de4 <syscall+0x42>
    80001dca:	00369713          	slli	a4,a3,0x3
    80001dce:	00005797          	auipc	a5,0x5
    80001dd2:	68a78793          	addi	a5,a5,1674 # 80007458 <syscalls>
    80001dd6:	97ba                	add	a5,a5,a4
    80001dd8:	639c                	ld	a5,0(a5)
    80001dda:	c789                	beqz	a5,80001de4 <syscall+0x42>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80001ddc:	9782                	jalr	a5
    80001dde:	06a93823          	sd	a0,112(s2)
    80001de2:	a829                	j	80001dfc <syscall+0x5a>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80001de4:	16048613          	addi	a2,s1,352
    80001de8:	588c                	lw	a1,48(s1)
    80001dea:	00005517          	auipc	a0,0x5
    80001dee:	63650513          	addi	a0,a0,1590 # 80007420 <states.0+0x158>
    80001df2:	450030ef          	jal	ra,80005242 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80001df6:	70bc                	ld	a5,96(s1)
    80001df8:	577d                	li	a4,-1
    80001dfa:	fbb8                	sd	a4,112(a5)
  }
}
    80001dfc:	60e2                	ld	ra,24(sp)
    80001dfe:	6442                	ld	s0,16(sp)
    80001e00:	64a2                	ld	s1,8(sp)
    80001e02:	6902                	ld	s2,0(sp)
    80001e04:	6105                	addi	sp,sp,32
    80001e06:	8082                	ret

0000000080001e08 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80001e08:	1101                	addi	sp,sp,-32
    80001e0a:	ec06                	sd	ra,24(sp)
    80001e0c:	e822                	sd	s0,16(sp)
    80001e0e:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80001e10:	fec40593          	addi	a1,s0,-20
    80001e14:	4501                	li	a0,0
    80001e16:	f25ff0ef          	jal	ra,80001d3a <argint>
  exit(n);
    80001e1a:	fec42503          	lw	a0,-20(s0)
    80001e1e:	f46ff0ef          	jal	ra,80001564 <exit>
  return 0;  // not reached
}
    80001e22:	4501                	li	a0,0
    80001e24:	60e2                	ld	ra,24(sp)
    80001e26:	6442                	ld	s0,16(sp)
    80001e28:	6105                	addi	sp,sp,32
    80001e2a:	8082                	ret

0000000080001e2c <sys_getpid>:

uint64
sys_getpid(void)
{
    80001e2c:	1141                	addi	sp,sp,-16
    80001e2e:	e406                	sd	ra,8(sp)
    80001e30:	e022                	sd	s0,0(sp)
    80001e32:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80001e34:	fcffe0ef          	jal	ra,80000e02 <myproc>
}
    80001e38:	5908                	lw	a0,48(a0)
    80001e3a:	60a2                	ld	ra,8(sp)
    80001e3c:	6402                	ld	s0,0(sp)
    80001e3e:	0141                	addi	sp,sp,16
    80001e40:	8082                	ret

0000000080001e42 <sys_fork>:

uint64
sys_fork(void)
{
    80001e42:	1141                	addi	sp,sp,-16
    80001e44:	e406                	sd	ra,8(sp)
    80001e46:	e022                	sd	s0,0(sp)
    80001e48:	0800                	addi	s0,sp,16
  return fork();
    80001e4a:	b5eff0ef          	jal	ra,800011a8 <fork>
}
    80001e4e:	60a2                	ld	ra,8(sp)
    80001e50:	6402                	ld	s0,0(sp)
    80001e52:	0141                	addi	sp,sp,16
    80001e54:	8082                	ret

0000000080001e56 <sys_wait>:

uint64
sys_wait(void)
{
    80001e56:	1101                	addi	sp,sp,-32
    80001e58:	ec06                	sd	ra,24(sp)
    80001e5a:	e822                	sd	s0,16(sp)
    80001e5c:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80001e5e:	fe840593          	addi	a1,s0,-24
    80001e62:	4501                	li	a0,0
    80001e64:	ef3ff0ef          	jal	ra,80001d56 <argaddr>
  return wait(p);
    80001e68:	fe843503          	ld	a0,-24(s0)
    80001e6c:	84fff0ef          	jal	ra,800016ba <wait>
}
    80001e70:	60e2                	ld	ra,24(sp)
    80001e72:	6442                	ld	s0,16(sp)
    80001e74:	6105                	addi	sp,sp,32
    80001e76:	8082                	ret

0000000080001e78 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80001e78:	7179                	addi	sp,sp,-48
    80001e7a:	f406                	sd	ra,40(sp)
    80001e7c:	f022                	sd	s0,32(sp)
    80001e7e:	ec26                	sd	s1,24(sp)
    80001e80:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80001e82:	fdc40593          	addi	a1,s0,-36
    80001e86:	4501                	li	a0,0
    80001e88:	eb3ff0ef          	jal	ra,80001d3a <argint>
  addr = myproc()->sz;
    80001e8c:	f77fe0ef          	jal	ra,80000e02 <myproc>
    80001e90:	6924                	ld	s1,80(a0)
  if(growproc(n) < 0)
    80001e92:	fdc42503          	lw	a0,-36(s0)
    80001e96:	ac2ff0ef          	jal	ra,80001158 <growproc>
    80001e9a:	00054863          	bltz	a0,80001eaa <sys_sbrk+0x32>
    return -1;
  return addr;
}
    80001e9e:	8526                	mv	a0,s1
    80001ea0:	70a2                	ld	ra,40(sp)
    80001ea2:	7402                	ld	s0,32(sp)
    80001ea4:	64e2                	ld	s1,24(sp)
    80001ea6:	6145                	addi	sp,sp,48
    80001ea8:	8082                	ret
    return -1;
    80001eaa:	54fd                	li	s1,-1
    80001eac:	bfcd                	j	80001e9e <sys_sbrk+0x26>

0000000080001eae <sys_sleep>:

uint64
sys_sleep(void)
{
    80001eae:	7139                	addi	sp,sp,-64
    80001eb0:	fc06                	sd	ra,56(sp)
    80001eb2:	f822                	sd	s0,48(sp)
    80001eb4:	f426                	sd	s1,40(sp)
    80001eb6:	f04a                	sd	s2,32(sp)
    80001eb8:	ec4e                	sd	s3,24(sp)
    80001eba:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;


  argint(0, &n);
    80001ebc:	fcc40593          	addi	a1,s0,-52
    80001ec0:	4501                	li	a0,0
    80001ec2:	e79ff0ef          	jal	ra,80001d3a <argint>
  if(n < 0)
    80001ec6:	fcc42783          	lw	a5,-52(s0)
    80001eca:	0607c563          	bltz	a5,80001f34 <sys_sleep+0x86>
    n = 0;
  acquire(&tickslock);
    80001ece:	0000c517          	auipc	a0,0xc
    80001ed2:	b3250513          	addi	a0,a0,-1230 # 8000da00 <tickslock>
    80001ed6:	135030ef          	jal	ra,8000580a <acquire>
  ticks0 = ticks;
    80001eda:	00006917          	auipc	s2,0x6
    80001ede:	abe92903          	lw	s2,-1346(s2) # 80007998 <ticks>
  while(ticks - ticks0 < n){
    80001ee2:	fcc42783          	lw	a5,-52(s0)
    80001ee6:	cb8d                	beqz	a5,80001f18 <sys_sleep+0x6a>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80001ee8:	0000c997          	auipc	s3,0xc
    80001eec:	b1898993          	addi	s3,s3,-1256 # 8000da00 <tickslock>
    80001ef0:	00006497          	auipc	s1,0x6
    80001ef4:	aa848493          	addi	s1,s1,-1368 # 80007998 <ticks>
    if(killed(myproc())){
    80001ef8:	f0bfe0ef          	jal	ra,80000e02 <myproc>
    80001efc:	f94ff0ef          	jal	ra,80001690 <killed>
    80001f00:	ed0d                	bnez	a0,80001f3a <sys_sleep+0x8c>
    sleep(&ticks, &tickslock);
    80001f02:	85ce                	mv	a1,s3
    80001f04:	8526                	mv	a0,s1
    80001f06:	d52ff0ef          	jal	ra,80001458 <sleep>
  while(ticks - ticks0 < n){
    80001f0a:	409c                	lw	a5,0(s1)
    80001f0c:	412787bb          	subw	a5,a5,s2
    80001f10:	fcc42703          	lw	a4,-52(s0)
    80001f14:	fee7e2e3          	bltu	a5,a4,80001ef8 <sys_sleep+0x4a>
  }
  release(&tickslock);
    80001f18:	0000c517          	auipc	a0,0xc
    80001f1c:	ae850513          	addi	a0,a0,-1304 # 8000da00 <tickslock>
    80001f20:	183030ef          	jal	ra,800058a2 <release>
  return 0;
    80001f24:	4501                	li	a0,0
}
    80001f26:	70e2                	ld	ra,56(sp)
    80001f28:	7442                	ld	s0,48(sp)
    80001f2a:	74a2                	ld	s1,40(sp)
    80001f2c:	7902                	ld	s2,32(sp)
    80001f2e:	69e2                	ld	s3,24(sp)
    80001f30:	6121                	addi	sp,sp,64
    80001f32:	8082                	ret
    n = 0;
    80001f34:	fc042623          	sw	zero,-52(s0)
    80001f38:	bf59                	j	80001ece <sys_sleep+0x20>
      release(&tickslock);
    80001f3a:	0000c517          	auipc	a0,0xc
    80001f3e:	ac650513          	addi	a0,a0,-1338 # 8000da00 <tickslock>
    80001f42:	161030ef          	jal	ra,800058a2 <release>
      return -1;
    80001f46:	557d                	li	a0,-1
    80001f48:	bff9                	j	80001f26 <sys_sleep+0x78>

0000000080001f4a <sys_pgaccess>:

uint64
sys_pgaccess(void)
{
    80001f4a:	715d                	addi	sp,sp,-80
    80001f4c:	e486                	sd	ra,72(sp)
    80001f4e:	e0a2                	sd	s0,64(sp)
    80001f50:	fc26                	sd	s1,56(sp)
    80001f52:	f84a                	sd	s2,48(sp)
    80001f54:	f44e                	sd	s3,40(sp)
    80001f56:	f052                	sd	s4,32(sp)
    80001f58:	0880                	addi	s0,sp,80
  uint64 va;     // base address
  int len;       // number of pages
  uint64 dst;    // user buffer address

  argaddr(0, &va);
    80001f5a:	fc840593          	addi	a1,s0,-56
    80001f5e:	4501                	li	a0,0
    80001f60:	df7ff0ef          	jal	ra,80001d56 <argaddr>
  argint(1, &len);
    80001f64:	fc440593          	addi	a1,s0,-60
    80001f68:	4505                	li	a0,1
    80001f6a:	dd1ff0ef          	jal	ra,80001d3a <argint>
  argaddr(2, &dst);
    80001f6e:	fb840593          	addi	a1,s0,-72
    80001f72:	4509                	li	a0,2
    80001f74:	de3ff0ef          	jal	ra,80001d56 <argaddr>

  if(len > 32)
    80001f78:	fc442783          	lw	a5,-60(s0)
    80001f7c:	02000713          	li	a4,32
    return -1;
    80001f80:	557d                	li	a0,-1
  if(len > 32)
    80001f82:	06f74f63          	blt	a4,a5,80002000 <sys_pgaccess+0xb6>

  uint64 result = 0;
    80001f86:	fa043823          	sd	zero,-80(s0)
  for(int i = 0; i < len; i++) {
    80001f8a:	06f05063          	blez	a5,80001fea <sys_pgaccess+0xa0>
    80001f8e:	4481                	li	s1,0
    pte_t *pte = walk(myproc()->pagetable, va + i*PGSIZE, 0);
    if(pte && (*pte & PTE_V) && (*pte & PTE_U)) {
    80001f90:	4945                	li	s2,17
      if(*pte & PTE_A) {
        result |= (1ULL << i);
    80001f92:	4985                	li	s3,1
    80001f94:	a801                	j	80001fa4 <sys_pgaccess+0x5a>
  for(int i = 0; i < len; i++) {
    80001f96:	0485                	addi	s1,s1,1
    80001f98:	fc442703          	lw	a4,-60(s0)
    80001f9c:	0004879b          	sext.w	a5,s1
    80001fa0:	04e7d563          	bge	a5,a4,80001fea <sys_pgaccess+0xa0>
    80001fa4:	00048a1b          	sext.w	s4,s1
    pte_t *pte = walk(myproc()->pagetable, va + i*PGSIZE, 0);
    80001fa8:	e5bfe0ef          	jal	ra,80000e02 <myproc>
    80001fac:	00c49793          	slli	a5,s1,0xc
    80001fb0:	4601                	li	a2,0
    80001fb2:	fc843583          	ld	a1,-56(s0)
    80001fb6:	95be                	add	a1,a1,a5
    80001fb8:	6d28                	ld	a0,88(a0)
    80001fba:	cb0fe0ef          	jal	ra,8000046a <walk>
    if(pte && (*pte & PTE_V) && (*pte & PTE_U)) {
    80001fbe:	dd61                	beqz	a0,80001f96 <sys_pgaccess+0x4c>
    80001fc0:	611c                	ld	a5,0(a0)
    80001fc2:	0117f713          	andi	a4,a5,17
    80001fc6:	fd2718e3          	bne	a4,s2,80001f96 <sys_pgaccess+0x4c>
      if(*pte & PTE_A) {
    80001fca:	0407f793          	andi	a5,a5,64
    80001fce:	d7e1                	beqz	a5,80001f96 <sys_pgaccess+0x4c>
        result |= (1ULL << i);
    80001fd0:	01499a33          	sll	s4,s3,s4
    80001fd4:	fb043783          	ld	a5,-80(s0)
    80001fd8:	0147ea33          	or	s4,a5,s4
    80001fdc:	fb443823          	sd	s4,-80(s0)
        *pte = (*pte & ~PTE_A);  // clear after reporting
    80001fe0:	611c                	ld	a5,0(a0)
    80001fe2:	fbf7f793          	andi	a5,a5,-65
    80001fe6:	e11c                	sd	a5,0(a0)
    80001fe8:	b77d                	j	80001f96 <sys_pgaccess+0x4c>
      }
    }
  }

  if(copyout(myproc()->pagetable, dst, (char *)&result, sizeof(result)) < 0)
    80001fea:	e19fe0ef          	jal	ra,80000e02 <myproc>
    80001fee:	46a1                	li	a3,8
    80001ff0:	fb040613          	addi	a2,s0,-80
    80001ff4:	fb843583          	ld	a1,-72(s0)
    80001ff8:	6d28                	ld	a0,88(a0)
    80001ffa:	a7ffe0ef          	jal	ra,80000a78 <copyout>
    80001ffe:	957d                	srai	a0,a0,0x3f
    return -1;

  return 0;
}
    80002000:	60a6                	ld	ra,72(sp)
    80002002:	6406                	ld	s0,64(sp)
    80002004:	74e2                	ld	s1,56(sp)
    80002006:	7942                	ld	s2,48(sp)
    80002008:	79a2                	ld	s3,40(sp)
    8000200a:	7a02                	ld	s4,32(sp)
    8000200c:	6161                	addi	sp,sp,80
    8000200e:	8082                	ret

0000000080002010 <sys_pgpte>:


#ifdef LAB_PGTBL
int
sys_pgpte(void)
{
    80002010:	7179                	addi	sp,sp,-48
    80002012:	f406                	sd	ra,40(sp)
    80002014:	f022                	sd	s0,32(sp)
    80002016:	ec26                	sd	s1,24(sp)
    80002018:	1800                	addi	s0,sp,48
  uint64 va;
  struct proc *p;  

  p = myproc();
    8000201a:	de9fe0ef          	jal	ra,80000e02 <myproc>
    8000201e:	84aa                	mv	s1,a0
  argaddr(0, &va);
    80002020:	fd840593          	addi	a1,s0,-40
    80002024:	4501                	li	a0,0
    80002026:	d31ff0ef          	jal	ra,80001d56 <argaddr>
  pte_t *pte = pgpte(p->pagetable, va);
    8000202a:	fd843583          	ld	a1,-40(s0)
    8000202e:	6ca8                	ld	a0,88(s1)
    80002030:	c63fe0ef          	jal	ra,80000c92 <pgpte>
    80002034:	87aa                	mv	a5,a0
  if(pte != 0) {
      return (uint64) *pte;
  }
  return 0;
    80002036:	4501                	li	a0,0
  if(pte != 0) {
    80002038:	c391                	beqz	a5,8000203c <sys_pgpte+0x2c>
      return (uint64) *pte;
    8000203a:	4388                	lw	a0,0(a5)
}
    8000203c:	70a2                	ld	ra,40(sp)
    8000203e:	7402                	ld	s0,32(sp)
    80002040:	64e2                	ld	s1,24(sp)
    80002042:	6145                	addi	sp,sp,48
    80002044:	8082                	ret

0000000080002046 <sys_kpgtbl>:
#endif

#ifdef LAB_PGTBL
int
sys_kpgtbl(void)
{
    80002046:	1141                	addi	sp,sp,-16
    80002048:	e406                	sd	ra,8(sp)
    8000204a:	e022                	sd	s0,0(sp)
    8000204c:	0800                	addi	s0,sp,16
  struct proc *p;  

  p = myproc();
    8000204e:	db5fe0ef          	jal	ra,80000e02 <myproc>
  vmprint(p->pagetable);
    80002052:	6d28                	ld	a0,88(a0)
    80002054:	c13fe0ef          	jal	ra,80000c66 <vmprint>
  return 0;
}
    80002058:	4501                	li	a0,0
    8000205a:	60a2                	ld	ra,8(sp)
    8000205c:	6402                	ld	s0,0(sp)
    8000205e:	0141                	addi	sp,sp,16
    80002060:	8082                	ret

0000000080002062 <sys_kill>:
#endif


uint64
sys_kill(void)
{
    80002062:	1101                	addi	sp,sp,-32
    80002064:	ec06                	sd	ra,24(sp)
    80002066:	e822                	sd	s0,16(sp)
    80002068:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    8000206a:	fec40593          	addi	a1,s0,-20
    8000206e:	4501                	li	a0,0
    80002070:	ccbff0ef          	jal	ra,80001d3a <argint>
  return kill(pid);
    80002074:	fec42503          	lw	a0,-20(s0)
    80002078:	d8eff0ef          	jal	ra,80001606 <kill>
}
    8000207c:	60e2                	ld	ra,24(sp)
    8000207e:	6442                	ld	s0,16(sp)
    80002080:	6105                	addi	sp,sp,32
    80002082:	8082                	ret

0000000080002084 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002084:	1101                	addi	sp,sp,-32
    80002086:	ec06                	sd	ra,24(sp)
    80002088:	e822                	sd	s0,16(sp)
    8000208a:	e426                	sd	s1,8(sp)
    8000208c:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    8000208e:	0000c517          	auipc	a0,0xc
    80002092:	97250513          	addi	a0,a0,-1678 # 8000da00 <tickslock>
    80002096:	774030ef          	jal	ra,8000580a <acquire>
  xticks = ticks;
    8000209a:	00006497          	auipc	s1,0x6
    8000209e:	8fe4a483          	lw	s1,-1794(s1) # 80007998 <ticks>
  release(&tickslock);
    800020a2:	0000c517          	auipc	a0,0xc
    800020a6:	95e50513          	addi	a0,a0,-1698 # 8000da00 <tickslock>
    800020aa:	7f8030ef          	jal	ra,800058a2 <release>
  return xticks;
}
    800020ae:	02049513          	slli	a0,s1,0x20
    800020b2:	9101                	srli	a0,a0,0x20
    800020b4:	60e2                	ld	ra,24(sp)
    800020b6:	6442                	ld	s0,16(sp)
    800020b8:	64a2                	ld	s1,8(sp)
    800020ba:	6105                	addi	sp,sp,32
    800020bc:	8082                	ret

00000000800020be <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    800020be:	7179                	addi	sp,sp,-48
    800020c0:	f406                	sd	ra,40(sp)
    800020c2:	f022                	sd	s0,32(sp)
    800020c4:	ec26                	sd	s1,24(sp)
    800020c6:	e84a                	sd	s2,16(sp)
    800020c8:	e44e                	sd	s3,8(sp)
    800020ca:	e052                	sd	s4,0(sp)
    800020cc:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    800020ce:	00005597          	auipc	a1,0x5
    800020d2:	4aa58593          	addi	a1,a1,1194 # 80007578 <syscalls+0x120>
    800020d6:	0000c517          	auipc	a0,0xc
    800020da:	94250513          	addi	a0,a0,-1726 # 8000da18 <bcache>
    800020de:	6ac030ef          	jal	ra,8000578a <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    800020e2:	00014797          	auipc	a5,0x14
    800020e6:	93678793          	addi	a5,a5,-1738 # 80015a18 <bcache+0x8000>
    800020ea:	00014717          	auipc	a4,0x14
    800020ee:	b9670713          	addi	a4,a4,-1130 # 80015c80 <bcache+0x8268>
    800020f2:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    800020f6:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    800020fa:	0000c497          	auipc	s1,0xc
    800020fe:	93648493          	addi	s1,s1,-1738 # 8000da30 <bcache+0x18>
    b->next = bcache.head.next;
    80002102:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002104:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002106:	00005a17          	auipc	s4,0x5
    8000210a:	47aa0a13          	addi	s4,s4,1146 # 80007580 <syscalls+0x128>
    b->next = bcache.head.next;
    8000210e:	2b893783          	ld	a5,696(s2)
    80002112:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002114:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002118:	85d2                	mv	a1,s4
    8000211a:	01048513          	addi	a0,s1,16
    8000211e:	22a010ef          	jal	ra,80003348 <initsleeplock>
    bcache.head.next->prev = b;
    80002122:	2b893783          	ld	a5,696(s2)
    80002126:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002128:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    8000212c:	45848493          	addi	s1,s1,1112
    80002130:	fd349fe3          	bne	s1,s3,8000210e <binit+0x50>
  }
}
    80002134:	70a2                	ld	ra,40(sp)
    80002136:	7402                	ld	s0,32(sp)
    80002138:	64e2                	ld	s1,24(sp)
    8000213a:	6942                	ld	s2,16(sp)
    8000213c:	69a2                	ld	s3,8(sp)
    8000213e:	6a02                	ld	s4,0(sp)
    80002140:	6145                	addi	sp,sp,48
    80002142:	8082                	ret

0000000080002144 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002144:	7179                	addi	sp,sp,-48
    80002146:	f406                	sd	ra,40(sp)
    80002148:	f022                	sd	s0,32(sp)
    8000214a:	ec26                	sd	s1,24(sp)
    8000214c:	e84a                	sd	s2,16(sp)
    8000214e:	e44e                	sd	s3,8(sp)
    80002150:	1800                	addi	s0,sp,48
    80002152:	892a                	mv	s2,a0
    80002154:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002156:	0000c517          	auipc	a0,0xc
    8000215a:	8c250513          	addi	a0,a0,-1854 # 8000da18 <bcache>
    8000215e:	6ac030ef          	jal	ra,8000580a <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002162:	00014497          	auipc	s1,0x14
    80002166:	b6e4b483          	ld	s1,-1170(s1) # 80015cd0 <bcache+0x82b8>
    8000216a:	00014797          	auipc	a5,0x14
    8000216e:	b1678793          	addi	a5,a5,-1258 # 80015c80 <bcache+0x8268>
    80002172:	02f48b63          	beq	s1,a5,800021a8 <bread+0x64>
    80002176:	873e                	mv	a4,a5
    80002178:	a021                	j	80002180 <bread+0x3c>
    8000217a:	68a4                	ld	s1,80(s1)
    8000217c:	02e48663          	beq	s1,a4,800021a8 <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002180:	449c                	lw	a5,8(s1)
    80002182:	ff279ce3          	bne	a5,s2,8000217a <bread+0x36>
    80002186:	44dc                	lw	a5,12(s1)
    80002188:	ff3799e3          	bne	a5,s3,8000217a <bread+0x36>
      b->refcnt++;
    8000218c:	40bc                	lw	a5,64(s1)
    8000218e:	2785                	addiw	a5,a5,1
    80002190:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002192:	0000c517          	auipc	a0,0xc
    80002196:	88650513          	addi	a0,a0,-1914 # 8000da18 <bcache>
    8000219a:	708030ef          	jal	ra,800058a2 <release>
      acquiresleep(&b->lock);
    8000219e:	01048513          	addi	a0,s1,16
    800021a2:	1dc010ef          	jal	ra,8000337e <acquiresleep>
      return b;
    800021a6:	a889                	j	800021f8 <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    800021a8:	00014497          	auipc	s1,0x14
    800021ac:	b204b483          	ld	s1,-1248(s1) # 80015cc8 <bcache+0x82b0>
    800021b0:	00014797          	auipc	a5,0x14
    800021b4:	ad078793          	addi	a5,a5,-1328 # 80015c80 <bcache+0x8268>
    800021b8:	00f48863          	beq	s1,a5,800021c8 <bread+0x84>
    800021bc:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    800021be:	40bc                	lw	a5,64(s1)
    800021c0:	cb91                	beqz	a5,800021d4 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    800021c2:	64a4                	ld	s1,72(s1)
    800021c4:	fee49de3          	bne	s1,a4,800021be <bread+0x7a>
  panic("bget: no buffers");
    800021c8:	00005517          	auipc	a0,0x5
    800021cc:	3c050513          	addi	a0,a0,960 # 80007588 <syscalls+0x130>
    800021d0:	326030ef          	jal	ra,800054f6 <panic>
      b->dev = dev;
    800021d4:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    800021d8:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    800021dc:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    800021e0:	4785                	li	a5,1
    800021e2:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    800021e4:	0000c517          	auipc	a0,0xc
    800021e8:	83450513          	addi	a0,a0,-1996 # 8000da18 <bcache>
    800021ec:	6b6030ef          	jal	ra,800058a2 <release>
      acquiresleep(&b->lock);
    800021f0:	01048513          	addi	a0,s1,16
    800021f4:	18a010ef          	jal	ra,8000337e <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    800021f8:	409c                	lw	a5,0(s1)
    800021fa:	cb89                	beqz	a5,8000220c <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    800021fc:	8526                	mv	a0,s1
    800021fe:	70a2                	ld	ra,40(sp)
    80002200:	7402                	ld	s0,32(sp)
    80002202:	64e2                	ld	s1,24(sp)
    80002204:	6942                	ld	s2,16(sp)
    80002206:	69a2                	ld	s3,8(sp)
    80002208:	6145                	addi	sp,sp,48
    8000220a:	8082                	ret
    virtio_disk_rw(b, 0);
    8000220c:	4581                	li	a1,0
    8000220e:	8526                	mv	a0,s1
    80002210:	0ed020ef          	jal	ra,80004afc <virtio_disk_rw>
    b->valid = 1;
    80002214:	4785                	li	a5,1
    80002216:	c09c                	sw	a5,0(s1)
  return b;
    80002218:	b7d5                	j	800021fc <bread+0xb8>

000000008000221a <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    8000221a:	1101                	addi	sp,sp,-32
    8000221c:	ec06                	sd	ra,24(sp)
    8000221e:	e822                	sd	s0,16(sp)
    80002220:	e426                	sd	s1,8(sp)
    80002222:	1000                	addi	s0,sp,32
    80002224:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002226:	0541                	addi	a0,a0,16
    80002228:	1d4010ef          	jal	ra,800033fc <holdingsleep>
    8000222c:	c911                	beqz	a0,80002240 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    8000222e:	4585                	li	a1,1
    80002230:	8526                	mv	a0,s1
    80002232:	0cb020ef          	jal	ra,80004afc <virtio_disk_rw>
}
    80002236:	60e2                	ld	ra,24(sp)
    80002238:	6442                	ld	s0,16(sp)
    8000223a:	64a2                	ld	s1,8(sp)
    8000223c:	6105                	addi	sp,sp,32
    8000223e:	8082                	ret
    panic("bwrite");
    80002240:	00005517          	auipc	a0,0x5
    80002244:	36050513          	addi	a0,a0,864 # 800075a0 <syscalls+0x148>
    80002248:	2ae030ef          	jal	ra,800054f6 <panic>

000000008000224c <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    8000224c:	1101                	addi	sp,sp,-32
    8000224e:	ec06                	sd	ra,24(sp)
    80002250:	e822                	sd	s0,16(sp)
    80002252:	e426                	sd	s1,8(sp)
    80002254:	e04a                	sd	s2,0(sp)
    80002256:	1000                	addi	s0,sp,32
    80002258:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    8000225a:	01050913          	addi	s2,a0,16
    8000225e:	854a                	mv	a0,s2
    80002260:	19c010ef          	jal	ra,800033fc <holdingsleep>
    80002264:	c13d                	beqz	a0,800022ca <brelse+0x7e>
    panic("brelse");

  releasesleep(&b->lock);
    80002266:	854a                	mv	a0,s2
    80002268:	15c010ef          	jal	ra,800033c4 <releasesleep>

  acquire(&bcache.lock);
    8000226c:	0000b517          	auipc	a0,0xb
    80002270:	7ac50513          	addi	a0,a0,1964 # 8000da18 <bcache>
    80002274:	596030ef          	jal	ra,8000580a <acquire>
  b->refcnt--;
    80002278:	40bc                	lw	a5,64(s1)
    8000227a:	37fd                	addiw	a5,a5,-1
    8000227c:	0007871b          	sext.w	a4,a5
    80002280:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002282:	eb05                	bnez	a4,800022b2 <brelse+0x66>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002284:	68bc                	ld	a5,80(s1)
    80002286:	64b8                	ld	a4,72(s1)
    80002288:	e7b8                	sd	a4,72(a5)
    b->prev->next = b->next;
    8000228a:	64bc                	ld	a5,72(s1)
    8000228c:	68b8                	ld	a4,80(s1)
    8000228e:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002290:	00013797          	auipc	a5,0x13
    80002294:	78878793          	addi	a5,a5,1928 # 80015a18 <bcache+0x8000>
    80002298:	2b87b703          	ld	a4,696(a5)
    8000229c:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    8000229e:	00014717          	auipc	a4,0x14
    800022a2:	9e270713          	addi	a4,a4,-1566 # 80015c80 <bcache+0x8268>
    800022a6:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    800022a8:	2b87b703          	ld	a4,696(a5)
    800022ac:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    800022ae:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    800022b2:	0000b517          	auipc	a0,0xb
    800022b6:	76650513          	addi	a0,a0,1894 # 8000da18 <bcache>
    800022ba:	5e8030ef          	jal	ra,800058a2 <release>
}
    800022be:	60e2                	ld	ra,24(sp)
    800022c0:	6442                	ld	s0,16(sp)
    800022c2:	64a2                	ld	s1,8(sp)
    800022c4:	6902                	ld	s2,0(sp)
    800022c6:	6105                	addi	sp,sp,32
    800022c8:	8082                	ret
    panic("brelse");
    800022ca:	00005517          	auipc	a0,0x5
    800022ce:	2de50513          	addi	a0,a0,734 # 800075a8 <syscalls+0x150>
    800022d2:	224030ef          	jal	ra,800054f6 <panic>

00000000800022d6 <bpin>:

void
bpin(struct buf *b) {
    800022d6:	1101                	addi	sp,sp,-32
    800022d8:	ec06                	sd	ra,24(sp)
    800022da:	e822                	sd	s0,16(sp)
    800022dc:	e426                	sd	s1,8(sp)
    800022de:	1000                	addi	s0,sp,32
    800022e0:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    800022e2:	0000b517          	auipc	a0,0xb
    800022e6:	73650513          	addi	a0,a0,1846 # 8000da18 <bcache>
    800022ea:	520030ef          	jal	ra,8000580a <acquire>
  b->refcnt++;
    800022ee:	40bc                	lw	a5,64(s1)
    800022f0:	2785                	addiw	a5,a5,1
    800022f2:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    800022f4:	0000b517          	auipc	a0,0xb
    800022f8:	72450513          	addi	a0,a0,1828 # 8000da18 <bcache>
    800022fc:	5a6030ef          	jal	ra,800058a2 <release>
}
    80002300:	60e2                	ld	ra,24(sp)
    80002302:	6442                	ld	s0,16(sp)
    80002304:	64a2                	ld	s1,8(sp)
    80002306:	6105                	addi	sp,sp,32
    80002308:	8082                	ret

000000008000230a <bunpin>:

void
bunpin(struct buf *b) {
    8000230a:	1101                	addi	sp,sp,-32
    8000230c:	ec06                	sd	ra,24(sp)
    8000230e:	e822                	sd	s0,16(sp)
    80002310:	e426                	sd	s1,8(sp)
    80002312:	1000                	addi	s0,sp,32
    80002314:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002316:	0000b517          	auipc	a0,0xb
    8000231a:	70250513          	addi	a0,a0,1794 # 8000da18 <bcache>
    8000231e:	4ec030ef          	jal	ra,8000580a <acquire>
  b->refcnt--;
    80002322:	40bc                	lw	a5,64(s1)
    80002324:	37fd                	addiw	a5,a5,-1
    80002326:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002328:	0000b517          	auipc	a0,0xb
    8000232c:	6f050513          	addi	a0,a0,1776 # 8000da18 <bcache>
    80002330:	572030ef          	jal	ra,800058a2 <release>
}
    80002334:	60e2                	ld	ra,24(sp)
    80002336:	6442                	ld	s0,16(sp)
    80002338:	64a2                	ld	s1,8(sp)
    8000233a:	6105                	addi	sp,sp,32
    8000233c:	8082                	ret

000000008000233e <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    8000233e:	1101                	addi	sp,sp,-32
    80002340:	ec06                	sd	ra,24(sp)
    80002342:	e822                	sd	s0,16(sp)
    80002344:	e426                	sd	s1,8(sp)
    80002346:	e04a                	sd	s2,0(sp)
    80002348:	1000                	addi	s0,sp,32
    8000234a:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    8000234c:	00d5d59b          	srliw	a1,a1,0xd
    80002350:	00014797          	auipc	a5,0x14
    80002354:	da47a783          	lw	a5,-604(a5) # 800160f4 <sb+0x1c>
    80002358:	9dbd                	addw	a1,a1,a5
    8000235a:	debff0ef          	jal	ra,80002144 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    8000235e:	0074f713          	andi	a4,s1,7
    80002362:	4785                	li	a5,1
    80002364:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    80002368:	14ce                	slli	s1,s1,0x33
    8000236a:	90d9                	srli	s1,s1,0x36
    8000236c:	00950733          	add	a4,a0,s1
    80002370:	05874703          	lbu	a4,88(a4)
    80002374:	00e7f6b3          	and	a3,a5,a4
    80002378:	c29d                	beqz	a3,8000239e <bfree+0x60>
    8000237a:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    8000237c:	94aa                	add	s1,s1,a0
    8000237e:	fff7c793          	not	a5,a5
    80002382:	8ff9                	and	a5,a5,a4
    80002384:	04f48c23          	sb	a5,88(s1)
  log_write(bp);
    80002388:	6ef000ef          	jal	ra,80003276 <log_write>
  brelse(bp);
    8000238c:	854a                	mv	a0,s2
    8000238e:	ebfff0ef          	jal	ra,8000224c <brelse>
}
    80002392:	60e2                	ld	ra,24(sp)
    80002394:	6442                	ld	s0,16(sp)
    80002396:	64a2                	ld	s1,8(sp)
    80002398:	6902                	ld	s2,0(sp)
    8000239a:	6105                	addi	sp,sp,32
    8000239c:	8082                	ret
    panic("freeing free block");
    8000239e:	00005517          	auipc	a0,0x5
    800023a2:	21250513          	addi	a0,a0,530 # 800075b0 <syscalls+0x158>
    800023a6:	150030ef          	jal	ra,800054f6 <panic>

00000000800023aa <balloc>:
{
    800023aa:	711d                	addi	sp,sp,-96
    800023ac:	ec86                	sd	ra,88(sp)
    800023ae:	e8a2                	sd	s0,80(sp)
    800023b0:	e4a6                	sd	s1,72(sp)
    800023b2:	e0ca                	sd	s2,64(sp)
    800023b4:	fc4e                	sd	s3,56(sp)
    800023b6:	f852                	sd	s4,48(sp)
    800023b8:	f456                	sd	s5,40(sp)
    800023ba:	f05a                	sd	s6,32(sp)
    800023bc:	ec5e                	sd	s7,24(sp)
    800023be:	e862                	sd	s8,16(sp)
    800023c0:	e466                	sd	s9,8(sp)
    800023c2:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    800023c4:	00014797          	auipc	a5,0x14
    800023c8:	d187a783          	lw	a5,-744(a5) # 800160dc <sb+0x4>
    800023cc:	0e078163          	beqz	a5,800024ae <balloc+0x104>
    800023d0:	8baa                	mv	s7,a0
    800023d2:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    800023d4:	00014b17          	auipc	s6,0x14
    800023d8:	d04b0b13          	addi	s6,s6,-764 # 800160d8 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800023dc:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    800023de:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800023e0:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    800023e2:	6c89                	lui	s9,0x2
    800023e4:	a0b5                	j	80002450 <balloc+0xa6>
        bp->data[bi/8] |= m;  // Mark block in use.
    800023e6:	974a                	add	a4,a4,s2
    800023e8:	8fd5                	or	a5,a5,a3
    800023ea:	04f70c23          	sb	a5,88(a4)
        log_write(bp);
    800023ee:	854a                	mv	a0,s2
    800023f0:	687000ef          	jal	ra,80003276 <log_write>
        brelse(bp);
    800023f4:	854a                	mv	a0,s2
    800023f6:	e57ff0ef          	jal	ra,8000224c <brelse>
  bp = bread(dev, bno);
    800023fa:	85a6                	mv	a1,s1
    800023fc:	855e                	mv	a0,s7
    800023fe:	d47ff0ef          	jal	ra,80002144 <bread>
    80002402:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002404:	40000613          	li	a2,1024
    80002408:	4581                	li	a1,0
    8000240a:	05850513          	addi	a0,a0,88
    8000240e:	d3ffd0ef          	jal	ra,8000014c <memset>
  log_write(bp);
    80002412:	854a                	mv	a0,s2
    80002414:	663000ef          	jal	ra,80003276 <log_write>
  brelse(bp);
    80002418:	854a                	mv	a0,s2
    8000241a:	e33ff0ef          	jal	ra,8000224c <brelse>
}
    8000241e:	8526                	mv	a0,s1
    80002420:	60e6                	ld	ra,88(sp)
    80002422:	6446                	ld	s0,80(sp)
    80002424:	64a6                	ld	s1,72(sp)
    80002426:	6906                	ld	s2,64(sp)
    80002428:	79e2                	ld	s3,56(sp)
    8000242a:	7a42                	ld	s4,48(sp)
    8000242c:	7aa2                	ld	s5,40(sp)
    8000242e:	7b02                	ld	s6,32(sp)
    80002430:	6be2                	ld	s7,24(sp)
    80002432:	6c42                	ld	s8,16(sp)
    80002434:	6ca2                	ld	s9,8(sp)
    80002436:	6125                	addi	sp,sp,96
    80002438:	8082                	ret
    brelse(bp);
    8000243a:	854a                	mv	a0,s2
    8000243c:	e11ff0ef          	jal	ra,8000224c <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002440:	015c87bb          	addw	a5,s9,s5
    80002444:	00078a9b          	sext.w	s5,a5
    80002448:	004b2703          	lw	a4,4(s6)
    8000244c:	06eaf163          	bgeu	s5,a4,800024ae <balloc+0x104>
    bp = bread(dev, BBLOCK(b, sb));
    80002450:	41fad79b          	sraiw	a5,s5,0x1f
    80002454:	0137d79b          	srliw	a5,a5,0x13
    80002458:	015787bb          	addw	a5,a5,s5
    8000245c:	40d7d79b          	sraiw	a5,a5,0xd
    80002460:	01cb2583          	lw	a1,28(s6)
    80002464:	9dbd                	addw	a1,a1,a5
    80002466:	855e                	mv	a0,s7
    80002468:	cddff0ef          	jal	ra,80002144 <bread>
    8000246c:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000246e:	004b2503          	lw	a0,4(s6)
    80002472:	000a849b          	sext.w	s1,s5
    80002476:	8662                	mv	a2,s8
    80002478:	fca4f1e3          	bgeu	s1,a0,8000243a <balloc+0x90>
      m = 1 << (bi % 8);
    8000247c:	41f6579b          	sraiw	a5,a2,0x1f
    80002480:	01d7d69b          	srliw	a3,a5,0x1d
    80002484:	00c6873b          	addw	a4,a3,a2
    80002488:	00777793          	andi	a5,a4,7
    8000248c:	9f95                	subw	a5,a5,a3
    8000248e:	00f997bb          	sllw	a5,s3,a5
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80002492:	4037571b          	sraiw	a4,a4,0x3
    80002496:	00e906b3          	add	a3,s2,a4
    8000249a:	0586c683          	lbu	a3,88(a3)
    8000249e:	00d7f5b3          	and	a1,a5,a3
    800024a2:	d1b1                	beqz	a1,800023e6 <balloc+0x3c>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800024a4:	2605                	addiw	a2,a2,1
    800024a6:	2485                	addiw	s1,s1,1
    800024a8:	fd4618e3          	bne	a2,s4,80002478 <balloc+0xce>
    800024ac:	b779                	j	8000243a <balloc+0x90>
  printf("balloc: out of blocks\n");
    800024ae:	00005517          	auipc	a0,0x5
    800024b2:	11a50513          	addi	a0,a0,282 # 800075c8 <syscalls+0x170>
    800024b6:	58d020ef          	jal	ra,80005242 <printf>
  return 0;
    800024ba:	4481                	li	s1,0
    800024bc:	b78d                	j	8000241e <balloc+0x74>

00000000800024be <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    800024be:	7179                	addi	sp,sp,-48
    800024c0:	f406                	sd	ra,40(sp)
    800024c2:	f022                	sd	s0,32(sp)
    800024c4:	ec26                	sd	s1,24(sp)
    800024c6:	e84a                	sd	s2,16(sp)
    800024c8:	e44e                	sd	s3,8(sp)
    800024ca:	e052                	sd	s4,0(sp)
    800024cc:	1800                	addi	s0,sp,48
    800024ce:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    800024d0:	47ad                	li	a5,11
    800024d2:	02b7e663          	bltu	a5,a1,800024fe <bmap+0x40>
    if((addr = ip->addrs[bn]) == 0){
    800024d6:	02059793          	slli	a5,a1,0x20
    800024da:	01e7d593          	srli	a1,a5,0x1e
    800024de:	00b504b3          	add	s1,a0,a1
    800024e2:	0504a903          	lw	s2,80(s1)
    800024e6:	06091663          	bnez	s2,80002552 <bmap+0x94>
      addr = balloc(ip->dev);
    800024ea:	4108                	lw	a0,0(a0)
    800024ec:	ebfff0ef          	jal	ra,800023aa <balloc>
    800024f0:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    800024f4:	04090f63          	beqz	s2,80002552 <bmap+0x94>
        return 0;
      ip->addrs[bn] = addr;
    800024f8:	0524a823          	sw	s2,80(s1)
    800024fc:	a899                	j	80002552 <bmap+0x94>
    }
    return addr;
  }
  bn -= NDIRECT;
    800024fe:	ff45849b          	addiw	s1,a1,-12
    80002502:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    80002506:	0ff00793          	li	a5,255
    8000250a:	06e7eb63          	bltu	a5,a4,80002580 <bmap+0xc2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    8000250e:	08052903          	lw	s2,128(a0)
    80002512:	00091b63          	bnez	s2,80002528 <bmap+0x6a>
      addr = balloc(ip->dev);
    80002516:	4108                	lw	a0,0(a0)
    80002518:	e93ff0ef          	jal	ra,800023aa <balloc>
    8000251c:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80002520:	02090963          	beqz	s2,80002552 <bmap+0x94>
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002524:	0929a023          	sw	s2,128(s3)
    }
    bp = bread(ip->dev, addr);
    80002528:	85ca                	mv	a1,s2
    8000252a:	0009a503          	lw	a0,0(s3)
    8000252e:	c17ff0ef          	jal	ra,80002144 <bread>
    80002532:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80002534:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80002538:	02049713          	slli	a4,s1,0x20
    8000253c:	01e75593          	srli	a1,a4,0x1e
    80002540:	00b784b3          	add	s1,a5,a1
    80002544:	0004a903          	lw	s2,0(s1)
    80002548:	00090e63          	beqz	s2,80002564 <bmap+0xa6>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000254c:	8552                	mv	a0,s4
    8000254e:	cffff0ef          	jal	ra,8000224c <brelse>
    return addr;
  }

  panic("bmap: out of range");
}
    80002552:	854a                	mv	a0,s2
    80002554:	70a2                	ld	ra,40(sp)
    80002556:	7402                	ld	s0,32(sp)
    80002558:	64e2                	ld	s1,24(sp)
    8000255a:	6942                	ld	s2,16(sp)
    8000255c:	69a2                	ld	s3,8(sp)
    8000255e:	6a02                	ld	s4,0(sp)
    80002560:	6145                	addi	sp,sp,48
    80002562:	8082                	ret
      addr = balloc(ip->dev);
    80002564:	0009a503          	lw	a0,0(s3)
    80002568:	e43ff0ef          	jal	ra,800023aa <balloc>
    8000256c:	0005091b          	sext.w	s2,a0
      if(addr){
    80002570:	fc090ee3          	beqz	s2,8000254c <bmap+0x8e>
        a[bn] = addr;
    80002574:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    80002578:	8552                	mv	a0,s4
    8000257a:	4fd000ef          	jal	ra,80003276 <log_write>
    8000257e:	b7f9                	j	8000254c <bmap+0x8e>
  panic("bmap: out of range");
    80002580:	00005517          	auipc	a0,0x5
    80002584:	06050513          	addi	a0,a0,96 # 800075e0 <syscalls+0x188>
    80002588:	76f020ef          	jal	ra,800054f6 <panic>

000000008000258c <iget>:
{
    8000258c:	7179                	addi	sp,sp,-48
    8000258e:	f406                	sd	ra,40(sp)
    80002590:	f022                	sd	s0,32(sp)
    80002592:	ec26                	sd	s1,24(sp)
    80002594:	e84a                	sd	s2,16(sp)
    80002596:	e44e                	sd	s3,8(sp)
    80002598:	e052                	sd	s4,0(sp)
    8000259a:	1800                	addi	s0,sp,48
    8000259c:	89aa                	mv	s3,a0
    8000259e:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    800025a0:	00014517          	auipc	a0,0x14
    800025a4:	b5850513          	addi	a0,a0,-1192 # 800160f8 <itable>
    800025a8:	262030ef          	jal	ra,8000580a <acquire>
  empty = 0;
    800025ac:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800025ae:	00014497          	auipc	s1,0x14
    800025b2:	b6248493          	addi	s1,s1,-1182 # 80016110 <itable+0x18>
    800025b6:	00015697          	auipc	a3,0x15
    800025ba:	5ea68693          	addi	a3,a3,1514 # 80017ba0 <log>
    800025be:	a039                	j	800025cc <iget+0x40>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800025c0:	02090963          	beqz	s2,800025f2 <iget+0x66>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800025c4:	08848493          	addi	s1,s1,136
    800025c8:	02d48863          	beq	s1,a3,800025f8 <iget+0x6c>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800025cc:	449c                	lw	a5,8(s1)
    800025ce:	fef059e3          	blez	a5,800025c0 <iget+0x34>
    800025d2:	4098                	lw	a4,0(s1)
    800025d4:	ff3716e3          	bne	a4,s3,800025c0 <iget+0x34>
    800025d8:	40d8                	lw	a4,4(s1)
    800025da:	ff4713e3          	bne	a4,s4,800025c0 <iget+0x34>
      ip->ref++;
    800025de:	2785                	addiw	a5,a5,1
    800025e0:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800025e2:	00014517          	auipc	a0,0x14
    800025e6:	b1650513          	addi	a0,a0,-1258 # 800160f8 <itable>
    800025ea:	2b8030ef          	jal	ra,800058a2 <release>
      return ip;
    800025ee:	8926                	mv	s2,s1
    800025f0:	a02d                	j	8000261a <iget+0x8e>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800025f2:	fbe9                	bnez	a5,800025c4 <iget+0x38>
    800025f4:	8926                	mv	s2,s1
    800025f6:	b7f9                	j	800025c4 <iget+0x38>
  if(empty == 0)
    800025f8:	02090a63          	beqz	s2,8000262c <iget+0xa0>
  ip->dev = dev;
    800025fc:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80002600:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80002604:	4785                	li	a5,1
    80002606:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    8000260a:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    8000260e:	00014517          	auipc	a0,0x14
    80002612:	aea50513          	addi	a0,a0,-1302 # 800160f8 <itable>
    80002616:	28c030ef          	jal	ra,800058a2 <release>
}
    8000261a:	854a                	mv	a0,s2
    8000261c:	70a2                	ld	ra,40(sp)
    8000261e:	7402                	ld	s0,32(sp)
    80002620:	64e2                	ld	s1,24(sp)
    80002622:	6942                	ld	s2,16(sp)
    80002624:	69a2                	ld	s3,8(sp)
    80002626:	6a02                	ld	s4,0(sp)
    80002628:	6145                	addi	sp,sp,48
    8000262a:	8082                	ret
    panic("iget: no inodes");
    8000262c:	00005517          	auipc	a0,0x5
    80002630:	fcc50513          	addi	a0,a0,-52 # 800075f8 <syscalls+0x1a0>
    80002634:	6c3020ef          	jal	ra,800054f6 <panic>

0000000080002638 <fsinit>:
fsinit(int dev) {
    80002638:	7179                	addi	sp,sp,-48
    8000263a:	f406                	sd	ra,40(sp)
    8000263c:	f022                	sd	s0,32(sp)
    8000263e:	ec26                	sd	s1,24(sp)
    80002640:	e84a                	sd	s2,16(sp)
    80002642:	e44e                	sd	s3,8(sp)
    80002644:	1800                	addi	s0,sp,48
    80002646:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80002648:	4585                	li	a1,1
    8000264a:	afbff0ef          	jal	ra,80002144 <bread>
    8000264e:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80002650:	00014997          	auipc	s3,0x14
    80002654:	a8898993          	addi	s3,s3,-1400 # 800160d8 <sb>
    80002658:	02000613          	li	a2,32
    8000265c:	05850593          	addi	a1,a0,88
    80002660:	854e                	mv	a0,s3
    80002662:	b47fd0ef          	jal	ra,800001a8 <memmove>
  brelse(bp);
    80002666:	8526                	mv	a0,s1
    80002668:	be5ff0ef          	jal	ra,8000224c <brelse>
  if(sb.magic != FSMAGIC)
    8000266c:	0009a703          	lw	a4,0(s3)
    80002670:	102037b7          	lui	a5,0x10203
    80002674:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80002678:	02f71063          	bne	a4,a5,80002698 <fsinit+0x60>
  initlog(dev, &sb);
    8000267c:	00014597          	auipc	a1,0x14
    80002680:	a5c58593          	addi	a1,a1,-1444 # 800160d8 <sb>
    80002684:	854a                	mv	a0,s2
    80002686:	1db000ef          	jal	ra,80003060 <initlog>
}
    8000268a:	70a2                	ld	ra,40(sp)
    8000268c:	7402                	ld	s0,32(sp)
    8000268e:	64e2                	ld	s1,24(sp)
    80002690:	6942                	ld	s2,16(sp)
    80002692:	69a2                	ld	s3,8(sp)
    80002694:	6145                	addi	sp,sp,48
    80002696:	8082                	ret
    panic("invalid file system");
    80002698:	00005517          	auipc	a0,0x5
    8000269c:	f7050513          	addi	a0,a0,-144 # 80007608 <syscalls+0x1b0>
    800026a0:	657020ef          	jal	ra,800054f6 <panic>

00000000800026a4 <iinit>:
{
    800026a4:	7179                	addi	sp,sp,-48
    800026a6:	f406                	sd	ra,40(sp)
    800026a8:	f022                	sd	s0,32(sp)
    800026aa:	ec26                	sd	s1,24(sp)
    800026ac:	e84a                	sd	s2,16(sp)
    800026ae:	e44e                	sd	s3,8(sp)
    800026b0:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800026b2:	00005597          	auipc	a1,0x5
    800026b6:	f6e58593          	addi	a1,a1,-146 # 80007620 <syscalls+0x1c8>
    800026ba:	00014517          	auipc	a0,0x14
    800026be:	a3e50513          	addi	a0,a0,-1474 # 800160f8 <itable>
    800026c2:	0c8030ef          	jal	ra,8000578a <initlock>
  for(i = 0; i < NINODE; i++) {
    800026c6:	00014497          	auipc	s1,0x14
    800026ca:	a5a48493          	addi	s1,s1,-1446 # 80016120 <itable+0x28>
    800026ce:	00015997          	auipc	s3,0x15
    800026d2:	4e298993          	addi	s3,s3,1250 # 80017bb0 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800026d6:	00005917          	auipc	s2,0x5
    800026da:	f5290913          	addi	s2,s2,-174 # 80007628 <syscalls+0x1d0>
    800026de:	85ca                	mv	a1,s2
    800026e0:	8526                	mv	a0,s1
    800026e2:	467000ef          	jal	ra,80003348 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    800026e6:	08848493          	addi	s1,s1,136
    800026ea:	ff349ae3          	bne	s1,s3,800026de <iinit+0x3a>
}
    800026ee:	70a2                	ld	ra,40(sp)
    800026f0:	7402                	ld	s0,32(sp)
    800026f2:	64e2                	ld	s1,24(sp)
    800026f4:	6942                	ld	s2,16(sp)
    800026f6:	69a2                	ld	s3,8(sp)
    800026f8:	6145                	addi	sp,sp,48
    800026fa:	8082                	ret

00000000800026fc <ialloc>:
{
    800026fc:	715d                	addi	sp,sp,-80
    800026fe:	e486                	sd	ra,72(sp)
    80002700:	e0a2                	sd	s0,64(sp)
    80002702:	fc26                	sd	s1,56(sp)
    80002704:	f84a                	sd	s2,48(sp)
    80002706:	f44e                	sd	s3,40(sp)
    80002708:	f052                	sd	s4,32(sp)
    8000270a:	ec56                	sd	s5,24(sp)
    8000270c:	e85a                	sd	s6,16(sp)
    8000270e:	e45e                	sd	s7,8(sp)
    80002710:	0880                	addi	s0,sp,80
  for(inum = 1; inum < sb.ninodes; inum++){
    80002712:	00014717          	auipc	a4,0x14
    80002716:	9d272703          	lw	a4,-1582(a4) # 800160e4 <sb+0xc>
    8000271a:	4785                	li	a5,1
    8000271c:	04e7f663          	bgeu	a5,a4,80002768 <ialloc+0x6c>
    80002720:	8aaa                	mv	s5,a0
    80002722:	8bae                	mv	s7,a1
    80002724:	4485                	li	s1,1
    bp = bread(dev, IBLOCK(inum, sb));
    80002726:	00014a17          	auipc	s4,0x14
    8000272a:	9b2a0a13          	addi	s4,s4,-1614 # 800160d8 <sb>
    8000272e:	00048b1b          	sext.w	s6,s1
    80002732:	0044d793          	srli	a5,s1,0x4
    80002736:	018a2583          	lw	a1,24(s4)
    8000273a:	9dbd                	addw	a1,a1,a5
    8000273c:	8556                	mv	a0,s5
    8000273e:	a07ff0ef          	jal	ra,80002144 <bread>
    80002742:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    80002744:	05850993          	addi	s3,a0,88
    80002748:	00f4f793          	andi	a5,s1,15
    8000274c:	079a                	slli	a5,a5,0x6
    8000274e:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80002750:	00099783          	lh	a5,0(s3)
    80002754:	cf85                	beqz	a5,8000278c <ialloc+0x90>
    brelse(bp);
    80002756:	af7ff0ef          	jal	ra,8000224c <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    8000275a:	0485                	addi	s1,s1,1
    8000275c:	00ca2703          	lw	a4,12(s4)
    80002760:	0004879b          	sext.w	a5,s1
    80002764:	fce7e5e3          	bltu	a5,a4,8000272e <ialloc+0x32>
  printf("ialloc: no inodes\n");
    80002768:	00005517          	auipc	a0,0x5
    8000276c:	ec850513          	addi	a0,a0,-312 # 80007630 <syscalls+0x1d8>
    80002770:	2d3020ef          	jal	ra,80005242 <printf>
  return 0;
    80002774:	4501                	li	a0,0
}
    80002776:	60a6                	ld	ra,72(sp)
    80002778:	6406                	ld	s0,64(sp)
    8000277a:	74e2                	ld	s1,56(sp)
    8000277c:	7942                	ld	s2,48(sp)
    8000277e:	79a2                	ld	s3,40(sp)
    80002780:	7a02                	ld	s4,32(sp)
    80002782:	6ae2                	ld	s5,24(sp)
    80002784:	6b42                	ld	s6,16(sp)
    80002786:	6ba2                	ld	s7,8(sp)
    80002788:	6161                	addi	sp,sp,80
    8000278a:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    8000278c:	04000613          	li	a2,64
    80002790:	4581                	li	a1,0
    80002792:	854e                	mv	a0,s3
    80002794:	9b9fd0ef          	jal	ra,8000014c <memset>
      dip->type = type;
    80002798:	01799023          	sh	s7,0(s3)
      log_write(bp);   // mark it allocated on the disk
    8000279c:	854a                	mv	a0,s2
    8000279e:	2d9000ef          	jal	ra,80003276 <log_write>
      brelse(bp);
    800027a2:	854a                	mv	a0,s2
    800027a4:	aa9ff0ef          	jal	ra,8000224c <brelse>
      return iget(dev, inum);
    800027a8:	85da                	mv	a1,s6
    800027aa:	8556                	mv	a0,s5
    800027ac:	de1ff0ef          	jal	ra,8000258c <iget>
    800027b0:	b7d9                	j	80002776 <ialloc+0x7a>

00000000800027b2 <iupdate>:
{
    800027b2:	1101                	addi	sp,sp,-32
    800027b4:	ec06                	sd	ra,24(sp)
    800027b6:	e822                	sd	s0,16(sp)
    800027b8:	e426                	sd	s1,8(sp)
    800027ba:	e04a                	sd	s2,0(sp)
    800027bc:	1000                	addi	s0,sp,32
    800027be:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800027c0:	415c                	lw	a5,4(a0)
    800027c2:	0047d79b          	srliw	a5,a5,0x4
    800027c6:	00014597          	auipc	a1,0x14
    800027ca:	92a5a583          	lw	a1,-1750(a1) # 800160f0 <sb+0x18>
    800027ce:	9dbd                	addw	a1,a1,a5
    800027d0:	4108                	lw	a0,0(a0)
    800027d2:	973ff0ef          	jal	ra,80002144 <bread>
    800027d6:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    800027d8:	05850793          	addi	a5,a0,88
    800027dc:	40c8                	lw	a0,4(s1)
    800027de:	893d                	andi	a0,a0,15
    800027e0:	051a                	slli	a0,a0,0x6
    800027e2:	953e                	add	a0,a0,a5
  dip->type = ip->type;
    800027e4:	04449703          	lh	a4,68(s1)
    800027e8:	00e51023          	sh	a4,0(a0)
  dip->major = ip->major;
    800027ec:	04649703          	lh	a4,70(s1)
    800027f0:	00e51123          	sh	a4,2(a0)
  dip->minor = ip->minor;
    800027f4:	04849703          	lh	a4,72(s1)
    800027f8:	00e51223          	sh	a4,4(a0)
  dip->nlink = ip->nlink;
    800027fc:	04a49703          	lh	a4,74(s1)
    80002800:	00e51323          	sh	a4,6(a0)
  dip->size = ip->size;
    80002804:	44f8                	lw	a4,76(s1)
    80002806:	c518                	sw	a4,8(a0)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80002808:	03400613          	li	a2,52
    8000280c:	05048593          	addi	a1,s1,80
    80002810:	0531                	addi	a0,a0,12
    80002812:	997fd0ef          	jal	ra,800001a8 <memmove>
  log_write(bp);
    80002816:	854a                	mv	a0,s2
    80002818:	25f000ef          	jal	ra,80003276 <log_write>
  brelse(bp);
    8000281c:	854a                	mv	a0,s2
    8000281e:	a2fff0ef          	jal	ra,8000224c <brelse>
}
    80002822:	60e2                	ld	ra,24(sp)
    80002824:	6442                	ld	s0,16(sp)
    80002826:	64a2                	ld	s1,8(sp)
    80002828:	6902                	ld	s2,0(sp)
    8000282a:	6105                	addi	sp,sp,32
    8000282c:	8082                	ret

000000008000282e <idup>:
{
    8000282e:	1101                	addi	sp,sp,-32
    80002830:	ec06                	sd	ra,24(sp)
    80002832:	e822                	sd	s0,16(sp)
    80002834:	e426                	sd	s1,8(sp)
    80002836:	1000                	addi	s0,sp,32
    80002838:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000283a:	00014517          	auipc	a0,0x14
    8000283e:	8be50513          	addi	a0,a0,-1858 # 800160f8 <itable>
    80002842:	7c9020ef          	jal	ra,8000580a <acquire>
  ip->ref++;
    80002846:	449c                	lw	a5,8(s1)
    80002848:	2785                	addiw	a5,a5,1
    8000284a:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000284c:	00014517          	auipc	a0,0x14
    80002850:	8ac50513          	addi	a0,a0,-1876 # 800160f8 <itable>
    80002854:	04e030ef          	jal	ra,800058a2 <release>
}
    80002858:	8526                	mv	a0,s1
    8000285a:	60e2                	ld	ra,24(sp)
    8000285c:	6442                	ld	s0,16(sp)
    8000285e:	64a2                	ld	s1,8(sp)
    80002860:	6105                	addi	sp,sp,32
    80002862:	8082                	ret

0000000080002864 <ilock>:
{
    80002864:	1101                	addi	sp,sp,-32
    80002866:	ec06                	sd	ra,24(sp)
    80002868:	e822                	sd	s0,16(sp)
    8000286a:	e426                	sd	s1,8(sp)
    8000286c:	e04a                	sd	s2,0(sp)
    8000286e:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80002870:	c105                	beqz	a0,80002890 <ilock+0x2c>
    80002872:	84aa                	mv	s1,a0
    80002874:	451c                	lw	a5,8(a0)
    80002876:	00f05d63          	blez	a5,80002890 <ilock+0x2c>
  acquiresleep(&ip->lock);
    8000287a:	0541                	addi	a0,a0,16
    8000287c:	303000ef          	jal	ra,8000337e <acquiresleep>
  if(ip->valid == 0){
    80002880:	40bc                	lw	a5,64(s1)
    80002882:	cf89                	beqz	a5,8000289c <ilock+0x38>
}
    80002884:	60e2                	ld	ra,24(sp)
    80002886:	6442                	ld	s0,16(sp)
    80002888:	64a2                	ld	s1,8(sp)
    8000288a:	6902                	ld	s2,0(sp)
    8000288c:	6105                	addi	sp,sp,32
    8000288e:	8082                	ret
    panic("ilock");
    80002890:	00005517          	auipc	a0,0x5
    80002894:	db850513          	addi	a0,a0,-584 # 80007648 <syscalls+0x1f0>
    80002898:	45f020ef          	jal	ra,800054f6 <panic>
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    8000289c:	40dc                	lw	a5,4(s1)
    8000289e:	0047d79b          	srliw	a5,a5,0x4
    800028a2:	00014597          	auipc	a1,0x14
    800028a6:	84e5a583          	lw	a1,-1970(a1) # 800160f0 <sb+0x18>
    800028aa:	9dbd                	addw	a1,a1,a5
    800028ac:	4088                	lw	a0,0(s1)
    800028ae:	897ff0ef          	jal	ra,80002144 <bread>
    800028b2:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    800028b4:	05850593          	addi	a1,a0,88
    800028b8:	40dc                	lw	a5,4(s1)
    800028ba:	8bbd                	andi	a5,a5,15
    800028bc:	079a                	slli	a5,a5,0x6
    800028be:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800028c0:	00059783          	lh	a5,0(a1)
    800028c4:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800028c8:	00259783          	lh	a5,2(a1)
    800028cc:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800028d0:	00459783          	lh	a5,4(a1)
    800028d4:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800028d8:	00659783          	lh	a5,6(a1)
    800028dc:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800028e0:	459c                	lw	a5,8(a1)
    800028e2:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800028e4:	03400613          	li	a2,52
    800028e8:	05b1                	addi	a1,a1,12
    800028ea:	05048513          	addi	a0,s1,80
    800028ee:	8bbfd0ef          	jal	ra,800001a8 <memmove>
    brelse(bp);
    800028f2:	854a                	mv	a0,s2
    800028f4:	959ff0ef          	jal	ra,8000224c <brelse>
    ip->valid = 1;
    800028f8:	4785                	li	a5,1
    800028fa:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    800028fc:	04449783          	lh	a5,68(s1)
    80002900:	f3d1                	bnez	a5,80002884 <ilock+0x20>
      panic("ilock: no type");
    80002902:	00005517          	auipc	a0,0x5
    80002906:	d4e50513          	addi	a0,a0,-690 # 80007650 <syscalls+0x1f8>
    8000290a:	3ed020ef          	jal	ra,800054f6 <panic>

000000008000290e <iunlock>:
{
    8000290e:	1101                	addi	sp,sp,-32
    80002910:	ec06                	sd	ra,24(sp)
    80002912:	e822                	sd	s0,16(sp)
    80002914:	e426                	sd	s1,8(sp)
    80002916:	e04a                	sd	s2,0(sp)
    80002918:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    8000291a:	c505                	beqz	a0,80002942 <iunlock+0x34>
    8000291c:	84aa                	mv	s1,a0
    8000291e:	01050913          	addi	s2,a0,16
    80002922:	854a                	mv	a0,s2
    80002924:	2d9000ef          	jal	ra,800033fc <holdingsleep>
    80002928:	cd09                	beqz	a0,80002942 <iunlock+0x34>
    8000292a:	449c                	lw	a5,8(s1)
    8000292c:	00f05b63          	blez	a5,80002942 <iunlock+0x34>
  releasesleep(&ip->lock);
    80002930:	854a                	mv	a0,s2
    80002932:	293000ef          	jal	ra,800033c4 <releasesleep>
}
    80002936:	60e2                	ld	ra,24(sp)
    80002938:	6442                	ld	s0,16(sp)
    8000293a:	64a2                	ld	s1,8(sp)
    8000293c:	6902                	ld	s2,0(sp)
    8000293e:	6105                	addi	sp,sp,32
    80002940:	8082                	ret
    panic("iunlock");
    80002942:	00005517          	auipc	a0,0x5
    80002946:	d1e50513          	addi	a0,a0,-738 # 80007660 <syscalls+0x208>
    8000294a:	3ad020ef          	jal	ra,800054f6 <panic>

000000008000294e <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    8000294e:	7179                	addi	sp,sp,-48
    80002950:	f406                	sd	ra,40(sp)
    80002952:	f022                	sd	s0,32(sp)
    80002954:	ec26                	sd	s1,24(sp)
    80002956:	e84a                	sd	s2,16(sp)
    80002958:	e44e                	sd	s3,8(sp)
    8000295a:	e052                	sd	s4,0(sp)
    8000295c:	1800                	addi	s0,sp,48
    8000295e:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80002960:	05050493          	addi	s1,a0,80
    80002964:	08050913          	addi	s2,a0,128
    80002968:	a021                	j	80002970 <itrunc+0x22>
    8000296a:	0491                	addi	s1,s1,4
    8000296c:	01248b63          	beq	s1,s2,80002982 <itrunc+0x34>
    if(ip->addrs[i]){
    80002970:	408c                	lw	a1,0(s1)
    80002972:	dde5                	beqz	a1,8000296a <itrunc+0x1c>
      bfree(ip->dev, ip->addrs[i]);
    80002974:	0009a503          	lw	a0,0(s3)
    80002978:	9c7ff0ef          	jal	ra,8000233e <bfree>
      ip->addrs[i] = 0;
    8000297c:	0004a023          	sw	zero,0(s1)
    80002980:	b7ed                	j	8000296a <itrunc+0x1c>
    }
  }

  if(ip->addrs[NDIRECT]){
    80002982:	0809a583          	lw	a1,128(s3)
    80002986:	ed91                	bnez	a1,800029a2 <itrunc+0x54>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    80002988:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    8000298c:	854e                	mv	a0,s3
    8000298e:	e25ff0ef          	jal	ra,800027b2 <iupdate>
}
    80002992:	70a2                	ld	ra,40(sp)
    80002994:	7402                	ld	s0,32(sp)
    80002996:	64e2                	ld	s1,24(sp)
    80002998:	6942                	ld	s2,16(sp)
    8000299a:	69a2                	ld	s3,8(sp)
    8000299c:	6a02                	ld	s4,0(sp)
    8000299e:	6145                	addi	sp,sp,48
    800029a0:	8082                	ret
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800029a2:	0009a503          	lw	a0,0(s3)
    800029a6:	f9eff0ef          	jal	ra,80002144 <bread>
    800029aa:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    800029ac:	05850493          	addi	s1,a0,88
    800029b0:	45850913          	addi	s2,a0,1112
    800029b4:	a021                	j	800029bc <itrunc+0x6e>
    800029b6:	0491                	addi	s1,s1,4
    800029b8:	01248963          	beq	s1,s2,800029ca <itrunc+0x7c>
      if(a[j])
    800029bc:	408c                	lw	a1,0(s1)
    800029be:	dde5                	beqz	a1,800029b6 <itrunc+0x68>
        bfree(ip->dev, a[j]);
    800029c0:	0009a503          	lw	a0,0(s3)
    800029c4:	97bff0ef          	jal	ra,8000233e <bfree>
    800029c8:	b7fd                	j	800029b6 <itrunc+0x68>
    brelse(bp);
    800029ca:	8552                	mv	a0,s4
    800029cc:	881ff0ef          	jal	ra,8000224c <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800029d0:	0809a583          	lw	a1,128(s3)
    800029d4:	0009a503          	lw	a0,0(s3)
    800029d8:	967ff0ef          	jal	ra,8000233e <bfree>
    ip->addrs[NDIRECT] = 0;
    800029dc:	0809a023          	sw	zero,128(s3)
    800029e0:	b765                	j	80002988 <itrunc+0x3a>

00000000800029e2 <iput>:
{
    800029e2:	1101                	addi	sp,sp,-32
    800029e4:	ec06                	sd	ra,24(sp)
    800029e6:	e822                	sd	s0,16(sp)
    800029e8:	e426                	sd	s1,8(sp)
    800029ea:	e04a                	sd	s2,0(sp)
    800029ec:	1000                	addi	s0,sp,32
    800029ee:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800029f0:	00013517          	auipc	a0,0x13
    800029f4:	70850513          	addi	a0,a0,1800 # 800160f8 <itable>
    800029f8:	613020ef          	jal	ra,8000580a <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800029fc:	4498                	lw	a4,8(s1)
    800029fe:	4785                	li	a5,1
    80002a00:	02f70163          	beq	a4,a5,80002a22 <iput+0x40>
  ip->ref--;
    80002a04:	449c                	lw	a5,8(s1)
    80002a06:	37fd                	addiw	a5,a5,-1
    80002a08:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80002a0a:	00013517          	auipc	a0,0x13
    80002a0e:	6ee50513          	addi	a0,a0,1774 # 800160f8 <itable>
    80002a12:	691020ef          	jal	ra,800058a2 <release>
}
    80002a16:	60e2                	ld	ra,24(sp)
    80002a18:	6442                	ld	s0,16(sp)
    80002a1a:	64a2                	ld	s1,8(sp)
    80002a1c:	6902                	ld	s2,0(sp)
    80002a1e:	6105                	addi	sp,sp,32
    80002a20:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002a22:	40bc                	lw	a5,64(s1)
    80002a24:	d3e5                	beqz	a5,80002a04 <iput+0x22>
    80002a26:	04a49783          	lh	a5,74(s1)
    80002a2a:	ffe9                	bnez	a5,80002a04 <iput+0x22>
    acquiresleep(&ip->lock);
    80002a2c:	01048913          	addi	s2,s1,16
    80002a30:	854a                	mv	a0,s2
    80002a32:	14d000ef          	jal	ra,8000337e <acquiresleep>
    release(&itable.lock);
    80002a36:	00013517          	auipc	a0,0x13
    80002a3a:	6c250513          	addi	a0,a0,1730 # 800160f8 <itable>
    80002a3e:	665020ef          	jal	ra,800058a2 <release>
    itrunc(ip);
    80002a42:	8526                	mv	a0,s1
    80002a44:	f0bff0ef          	jal	ra,8000294e <itrunc>
    ip->type = 0;
    80002a48:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80002a4c:	8526                	mv	a0,s1
    80002a4e:	d65ff0ef          	jal	ra,800027b2 <iupdate>
    ip->valid = 0;
    80002a52:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80002a56:	854a                	mv	a0,s2
    80002a58:	16d000ef          	jal	ra,800033c4 <releasesleep>
    acquire(&itable.lock);
    80002a5c:	00013517          	auipc	a0,0x13
    80002a60:	69c50513          	addi	a0,a0,1692 # 800160f8 <itable>
    80002a64:	5a7020ef          	jal	ra,8000580a <acquire>
    80002a68:	bf71                	j	80002a04 <iput+0x22>

0000000080002a6a <iunlockput>:
{
    80002a6a:	1101                	addi	sp,sp,-32
    80002a6c:	ec06                	sd	ra,24(sp)
    80002a6e:	e822                	sd	s0,16(sp)
    80002a70:	e426                	sd	s1,8(sp)
    80002a72:	1000                	addi	s0,sp,32
    80002a74:	84aa                	mv	s1,a0
  iunlock(ip);
    80002a76:	e99ff0ef          	jal	ra,8000290e <iunlock>
  iput(ip);
    80002a7a:	8526                	mv	a0,s1
    80002a7c:	f67ff0ef          	jal	ra,800029e2 <iput>
}
    80002a80:	60e2                	ld	ra,24(sp)
    80002a82:	6442                	ld	s0,16(sp)
    80002a84:	64a2                	ld	s1,8(sp)
    80002a86:	6105                	addi	sp,sp,32
    80002a88:	8082                	ret

0000000080002a8a <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80002a8a:	1141                	addi	sp,sp,-16
    80002a8c:	e422                	sd	s0,8(sp)
    80002a8e:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80002a90:	411c                	lw	a5,0(a0)
    80002a92:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80002a94:	415c                	lw	a5,4(a0)
    80002a96:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80002a98:	04451783          	lh	a5,68(a0)
    80002a9c:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80002aa0:	04a51783          	lh	a5,74(a0)
    80002aa4:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80002aa8:	04c56783          	lwu	a5,76(a0)
    80002aac:	e99c                	sd	a5,16(a1)
}
    80002aae:	6422                	ld	s0,8(sp)
    80002ab0:	0141                	addi	sp,sp,16
    80002ab2:	8082                	ret

0000000080002ab4 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002ab4:	457c                	lw	a5,76(a0)
    80002ab6:	0cd7ef63          	bltu	a5,a3,80002b94 <readi+0xe0>
{
    80002aba:	7159                	addi	sp,sp,-112
    80002abc:	f486                	sd	ra,104(sp)
    80002abe:	f0a2                	sd	s0,96(sp)
    80002ac0:	eca6                	sd	s1,88(sp)
    80002ac2:	e8ca                	sd	s2,80(sp)
    80002ac4:	e4ce                	sd	s3,72(sp)
    80002ac6:	e0d2                	sd	s4,64(sp)
    80002ac8:	fc56                	sd	s5,56(sp)
    80002aca:	f85a                	sd	s6,48(sp)
    80002acc:	f45e                	sd	s7,40(sp)
    80002ace:	f062                	sd	s8,32(sp)
    80002ad0:	ec66                	sd	s9,24(sp)
    80002ad2:	e86a                	sd	s10,16(sp)
    80002ad4:	e46e                	sd	s11,8(sp)
    80002ad6:	1880                	addi	s0,sp,112
    80002ad8:	8b2a                	mv	s6,a0
    80002ada:	8bae                	mv	s7,a1
    80002adc:	8a32                	mv	s4,a2
    80002ade:	84b6                	mv	s1,a3
    80002ae0:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80002ae2:	9f35                	addw	a4,a4,a3
    return 0;
    80002ae4:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80002ae6:	08d76663          	bltu	a4,a3,80002b72 <readi+0xbe>
  if(off + n > ip->size)
    80002aea:	00e7f463          	bgeu	a5,a4,80002af2 <readi+0x3e>
    n = ip->size - off;
    80002aee:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002af2:	080a8f63          	beqz	s5,80002b90 <readi+0xdc>
    80002af6:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002af8:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80002afc:	5c7d                	li	s8,-1
    80002afe:	a80d                	j	80002b30 <readi+0x7c>
    80002b00:	020d1d93          	slli	s11,s10,0x20
    80002b04:	020ddd93          	srli	s11,s11,0x20
    80002b08:	05890793          	addi	a5,s2,88
    80002b0c:	86ee                	mv	a3,s11
    80002b0e:	963e                	add	a2,a2,a5
    80002b10:	85d2                	mv	a1,s4
    80002b12:	855e                	mv	a0,s7
    80002b14:	ca1fe0ef          	jal	ra,800017b4 <either_copyout>
    80002b18:	05850763          	beq	a0,s8,80002b66 <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80002b1c:	854a                	mv	a0,s2
    80002b1e:	f2eff0ef          	jal	ra,8000224c <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002b22:	013d09bb          	addw	s3,s10,s3
    80002b26:	009d04bb          	addw	s1,s10,s1
    80002b2a:	9a6e                	add	s4,s4,s11
    80002b2c:	0559f163          	bgeu	s3,s5,80002b6e <readi+0xba>
    uint addr = bmap(ip, off/BSIZE);
    80002b30:	00a4d59b          	srliw	a1,s1,0xa
    80002b34:	855a                	mv	a0,s6
    80002b36:	989ff0ef          	jal	ra,800024be <bmap>
    80002b3a:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80002b3e:	c985                	beqz	a1,80002b6e <readi+0xba>
    bp = bread(ip->dev, addr);
    80002b40:	000b2503          	lw	a0,0(s6)
    80002b44:	e00ff0ef          	jal	ra,80002144 <bread>
    80002b48:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002b4a:	3ff4f613          	andi	a2,s1,1023
    80002b4e:	40cc87bb          	subw	a5,s9,a2
    80002b52:	413a873b          	subw	a4,s5,s3
    80002b56:	8d3e                	mv	s10,a5
    80002b58:	2781                	sext.w	a5,a5
    80002b5a:	0007069b          	sext.w	a3,a4
    80002b5e:	faf6f1e3          	bgeu	a3,a5,80002b00 <readi+0x4c>
    80002b62:	8d3a                	mv	s10,a4
    80002b64:	bf71                	j	80002b00 <readi+0x4c>
      brelse(bp);
    80002b66:	854a                	mv	a0,s2
    80002b68:	ee4ff0ef          	jal	ra,8000224c <brelse>
      tot = -1;
    80002b6c:	59fd                	li	s3,-1
  }
  return tot;
    80002b6e:	0009851b          	sext.w	a0,s3
}
    80002b72:	70a6                	ld	ra,104(sp)
    80002b74:	7406                	ld	s0,96(sp)
    80002b76:	64e6                	ld	s1,88(sp)
    80002b78:	6946                	ld	s2,80(sp)
    80002b7a:	69a6                	ld	s3,72(sp)
    80002b7c:	6a06                	ld	s4,64(sp)
    80002b7e:	7ae2                	ld	s5,56(sp)
    80002b80:	7b42                	ld	s6,48(sp)
    80002b82:	7ba2                	ld	s7,40(sp)
    80002b84:	7c02                	ld	s8,32(sp)
    80002b86:	6ce2                	ld	s9,24(sp)
    80002b88:	6d42                	ld	s10,16(sp)
    80002b8a:	6da2                	ld	s11,8(sp)
    80002b8c:	6165                	addi	sp,sp,112
    80002b8e:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002b90:	89d6                	mv	s3,s5
    80002b92:	bff1                	j	80002b6e <readi+0xba>
    return 0;
    80002b94:	4501                	li	a0,0
}
    80002b96:	8082                	ret

0000000080002b98 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002b98:	457c                	lw	a5,76(a0)
    80002b9a:	0ed7ea63          	bltu	a5,a3,80002c8e <writei+0xf6>
{
    80002b9e:	7159                	addi	sp,sp,-112
    80002ba0:	f486                	sd	ra,104(sp)
    80002ba2:	f0a2                	sd	s0,96(sp)
    80002ba4:	eca6                	sd	s1,88(sp)
    80002ba6:	e8ca                	sd	s2,80(sp)
    80002ba8:	e4ce                	sd	s3,72(sp)
    80002baa:	e0d2                	sd	s4,64(sp)
    80002bac:	fc56                	sd	s5,56(sp)
    80002bae:	f85a                	sd	s6,48(sp)
    80002bb0:	f45e                	sd	s7,40(sp)
    80002bb2:	f062                	sd	s8,32(sp)
    80002bb4:	ec66                	sd	s9,24(sp)
    80002bb6:	e86a                	sd	s10,16(sp)
    80002bb8:	e46e                	sd	s11,8(sp)
    80002bba:	1880                	addi	s0,sp,112
    80002bbc:	8aaa                	mv	s5,a0
    80002bbe:	8bae                	mv	s7,a1
    80002bc0:	8a32                	mv	s4,a2
    80002bc2:	8936                	mv	s2,a3
    80002bc4:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80002bc6:	00e687bb          	addw	a5,a3,a4
    80002bca:	0cd7e463          	bltu	a5,a3,80002c92 <writei+0xfa>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80002bce:	00043737          	lui	a4,0x43
    80002bd2:	0cf76263          	bltu	a4,a5,80002c96 <writei+0xfe>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002bd6:	0a0b0a63          	beqz	s6,80002c8a <writei+0xf2>
    80002bda:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002bdc:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80002be0:	5c7d                	li	s8,-1
    80002be2:	a825                	j	80002c1a <writei+0x82>
    80002be4:	020d1d93          	slli	s11,s10,0x20
    80002be8:	020ddd93          	srli	s11,s11,0x20
    80002bec:	05848793          	addi	a5,s1,88
    80002bf0:	86ee                	mv	a3,s11
    80002bf2:	8652                	mv	a2,s4
    80002bf4:	85de                	mv	a1,s7
    80002bf6:	953e                	add	a0,a0,a5
    80002bf8:	c07fe0ef          	jal	ra,800017fe <either_copyin>
    80002bfc:	05850a63          	beq	a0,s8,80002c50 <writei+0xb8>
      brelse(bp);
      break;
    }
    log_write(bp);
    80002c00:	8526                	mv	a0,s1
    80002c02:	674000ef          	jal	ra,80003276 <log_write>
    brelse(bp);
    80002c06:	8526                	mv	a0,s1
    80002c08:	e44ff0ef          	jal	ra,8000224c <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002c0c:	013d09bb          	addw	s3,s10,s3
    80002c10:	012d093b          	addw	s2,s10,s2
    80002c14:	9a6e                	add	s4,s4,s11
    80002c16:	0569f063          	bgeu	s3,s6,80002c56 <writei+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80002c1a:	00a9559b          	srliw	a1,s2,0xa
    80002c1e:	8556                	mv	a0,s5
    80002c20:	89fff0ef          	jal	ra,800024be <bmap>
    80002c24:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80002c28:	c59d                	beqz	a1,80002c56 <writei+0xbe>
    bp = bread(ip->dev, addr);
    80002c2a:	000aa503          	lw	a0,0(s5)
    80002c2e:	d16ff0ef          	jal	ra,80002144 <bread>
    80002c32:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002c34:	3ff97513          	andi	a0,s2,1023
    80002c38:	40ac87bb          	subw	a5,s9,a0
    80002c3c:	413b073b          	subw	a4,s6,s3
    80002c40:	8d3e                	mv	s10,a5
    80002c42:	2781                	sext.w	a5,a5
    80002c44:	0007069b          	sext.w	a3,a4
    80002c48:	f8f6fee3          	bgeu	a3,a5,80002be4 <writei+0x4c>
    80002c4c:	8d3a                	mv	s10,a4
    80002c4e:	bf59                	j	80002be4 <writei+0x4c>
      brelse(bp);
    80002c50:	8526                	mv	a0,s1
    80002c52:	dfaff0ef          	jal	ra,8000224c <brelse>
  }

  if(off > ip->size)
    80002c56:	04caa783          	lw	a5,76(s5)
    80002c5a:	0127f463          	bgeu	a5,s2,80002c62 <writei+0xca>
    ip->size = off;
    80002c5e:	052aa623          	sw	s2,76(s5)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80002c62:	8556                	mv	a0,s5
    80002c64:	b4fff0ef          	jal	ra,800027b2 <iupdate>

  return tot;
    80002c68:	0009851b          	sext.w	a0,s3
}
    80002c6c:	70a6                	ld	ra,104(sp)
    80002c6e:	7406                	ld	s0,96(sp)
    80002c70:	64e6                	ld	s1,88(sp)
    80002c72:	6946                	ld	s2,80(sp)
    80002c74:	69a6                	ld	s3,72(sp)
    80002c76:	6a06                	ld	s4,64(sp)
    80002c78:	7ae2                	ld	s5,56(sp)
    80002c7a:	7b42                	ld	s6,48(sp)
    80002c7c:	7ba2                	ld	s7,40(sp)
    80002c7e:	7c02                	ld	s8,32(sp)
    80002c80:	6ce2                	ld	s9,24(sp)
    80002c82:	6d42                	ld	s10,16(sp)
    80002c84:	6da2                	ld	s11,8(sp)
    80002c86:	6165                	addi	sp,sp,112
    80002c88:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002c8a:	89da                	mv	s3,s6
    80002c8c:	bfd9                	j	80002c62 <writei+0xca>
    return -1;
    80002c8e:	557d                	li	a0,-1
}
    80002c90:	8082                	ret
    return -1;
    80002c92:	557d                	li	a0,-1
    80002c94:	bfe1                	j	80002c6c <writei+0xd4>
    return -1;
    80002c96:	557d                	li	a0,-1
    80002c98:	bfd1                	j	80002c6c <writei+0xd4>

0000000080002c9a <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80002c9a:	1141                	addi	sp,sp,-16
    80002c9c:	e406                	sd	ra,8(sp)
    80002c9e:	e022                	sd	s0,0(sp)
    80002ca0:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80002ca2:	4639                	li	a2,14
    80002ca4:	d74fd0ef          	jal	ra,80000218 <strncmp>
}
    80002ca8:	60a2                	ld	ra,8(sp)
    80002caa:	6402                	ld	s0,0(sp)
    80002cac:	0141                	addi	sp,sp,16
    80002cae:	8082                	ret

0000000080002cb0 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80002cb0:	7139                	addi	sp,sp,-64
    80002cb2:	fc06                	sd	ra,56(sp)
    80002cb4:	f822                	sd	s0,48(sp)
    80002cb6:	f426                	sd	s1,40(sp)
    80002cb8:	f04a                	sd	s2,32(sp)
    80002cba:	ec4e                	sd	s3,24(sp)
    80002cbc:	e852                	sd	s4,16(sp)
    80002cbe:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80002cc0:	04451703          	lh	a4,68(a0)
    80002cc4:	4785                	li	a5,1
    80002cc6:	00f71a63          	bne	a4,a5,80002cda <dirlookup+0x2a>
    80002cca:	892a                	mv	s2,a0
    80002ccc:	89ae                	mv	s3,a1
    80002cce:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80002cd0:	457c                	lw	a5,76(a0)
    80002cd2:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80002cd4:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002cd6:	e39d                	bnez	a5,80002cfc <dirlookup+0x4c>
    80002cd8:	a095                	j	80002d3c <dirlookup+0x8c>
    panic("dirlookup not DIR");
    80002cda:	00005517          	auipc	a0,0x5
    80002cde:	98e50513          	addi	a0,a0,-1650 # 80007668 <syscalls+0x210>
    80002ce2:	015020ef          	jal	ra,800054f6 <panic>
      panic("dirlookup read");
    80002ce6:	00005517          	auipc	a0,0x5
    80002cea:	99a50513          	addi	a0,a0,-1638 # 80007680 <syscalls+0x228>
    80002cee:	009020ef          	jal	ra,800054f6 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002cf2:	24c1                	addiw	s1,s1,16
    80002cf4:	04c92783          	lw	a5,76(s2)
    80002cf8:	04f4f163          	bgeu	s1,a5,80002d3a <dirlookup+0x8a>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002cfc:	4741                	li	a4,16
    80002cfe:	86a6                	mv	a3,s1
    80002d00:	fc040613          	addi	a2,s0,-64
    80002d04:	4581                	li	a1,0
    80002d06:	854a                	mv	a0,s2
    80002d08:	dadff0ef          	jal	ra,80002ab4 <readi>
    80002d0c:	47c1                	li	a5,16
    80002d0e:	fcf51ce3          	bne	a0,a5,80002ce6 <dirlookup+0x36>
    if(de.inum == 0)
    80002d12:	fc045783          	lhu	a5,-64(s0)
    80002d16:	dff1                	beqz	a5,80002cf2 <dirlookup+0x42>
    if(namecmp(name, de.name) == 0){
    80002d18:	fc240593          	addi	a1,s0,-62
    80002d1c:	854e                	mv	a0,s3
    80002d1e:	f7dff0ef          	jal	ra,80002c9a <namecmp>
    80002d22:	f961                	bnez	a0,80002cf2 <dirlookup+0x42>
      if(poff)
    80002d24:	000a0463          	beqz	s4,80002d2c <dirlookup+0x7c>
        *poff = off;
    80002d28:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80002d2c:	fc045583          	lhu	a1,-64(s0)
    80002d30:	00092503          	lw	a0,0(s2)
    80002d34:	859ff0ef          	jal	ra,8000258c <iget>
    80002d38:	a011                	j	80002d3c <dirlookup+0x8c>
  return 0;
    80002d3a:	4501                	li	a0,0
}
    80002d3c:	70e2                	ld	ra,56(sp)
    80002d3e:	7442                	ld	s0,48(sp)
    80002d40:	74a2                	ld	s1,40(sp)
    80002d42:	7902                	ld	s2,32(sp)
    80002d44:	69e2                	ld	s3,24(sp)
    80002d46:	6a42                	ld	s4,16(sp)
    80002d48:	6121                	addi	sp,sp,64
    80002d4a:	8082                	ret

0000000080002d4c <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80002d4c:	711d                	addi	sp,sp,-96
    80002d4e:	ec86                	sd	ra,88(sp)
    80002d50:	e8a2                	sd	s0,80(sp)
    80002d52:	e4a6                	sd	s1,72(sp)
    80002d54:	e0ca                	sd	s2,64(sp)
    80002d56:	fc4e                	sd	s3,56(sp)
    80002d58:	f852                	sd	s4,48(sp)
    80002d5a:	f456                	sd	s5,40(sp)
    80002d5c:	f05a                	sd	s6,32(sp)
    80002d5e:	ec5e                	sd	s7,24(sp)
    80002d60:	e862                	sd	s8,16(sp)
    80002d62:	e466                	sd	s9,8(sp)
    80002d64:	1080                	addi	s0,sp,96
    80002d66:	84aa                	mv	s1,a0
    80002d68:	8aae                	mv	s5,a1
    80002d6a:	8a32                	mv	s4,a2
  struct inode *ip, *next;

  if(*path == '/')
    80002d6c:	00054703          	lbu	a4,0(a0)
    80002d70:	02f00793          	li	a5,47
    80002d74:	00f70f63          	beq	a4,a5,80002d92 <namex+0x46>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80002d78:	88afe0ef          	jal	ra,80000e02 <myproc>
    80002d7c:	15853503          	ld	a0,344(a0)
    80002d80:	aafff0ef          	jal	ra,8000282e <idup>
    80002d84:	89aa                	mv	s3,a0
  while(*path == '/')
    80002d86:	02f00913          	li	s2,47
  len = path - s;
    80002d8a:	4b01                	li	s6,0
  if(len >= DIRSIZ)
    80002d8c:	4c35                	li	s8,13

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80002d8e:	4b85                	li	s7,1
    80002d90:	a861                	j	80002e28 <namex+0xdc>
    ip = iget(ROOTDEV, ROOTINO);
    80002d92:	4585                	li	a1,1
    80002d94:	4505                	li	a0,1
    80002d96:	ff6ff0ef          	jal	ra,8000258c <iget>
    80002d9a:	89aa                	mv	s3,a0
    80002d9c:	b7ed                	j	80002d86 <namex+0x3a>
      iunlockput(ip);
    80002d9e:	854e                	mv	a0,s3
    80002da0:	ccbff0ef          	jal	ra,80002a6a <iunlockput>
      return 0;
    80002da4:	4981                	li	s3,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80002da6:	854e                	mv	a0,s3
    80002da8:	60e6                	ld	ra,88(sp)
    80002daa:	6446                	ld	s0,80(sp)
    80002dac:	64a6                	ld	s1,72(sp)
    80002dae:	6906                	ld	s2,64(sp)
    80002db0:	79e2                	ld	s3,56(sp)
    80002db2:	7a42                	ld	s4,48(sp)
    80002db4:	7aa2                	ld	s5,40(sp)
    80002db6:	7b02                	ld	s6,32(sp)
    80002db8:	6be2                	ld	s7,24(sp)
    80002dba:	6c42                	ld	s8,16(sp)
    80002dbc:	6ca2                	ld	s9,8(sp)
    80002dbe:	6125                	addi	sp,sp,96
    80002dc0:	8082                	ret
      iunlock(ip);
    80002dc2:	854e                	mv	a0,s3
    80002dc4:	b4bff0ef          	jal	ra,8000290e <iunlock>
      return ip;
    80002dc8:	bff9                	j	80002da6 <namex+0x5a>
      iunlockput(ip);
    80002dca:	854e                	mv	a0,s3
    80002dcc:	c9fff0ef          	jal	ra,80002a6a <iunlockput>
      return 0;
    80002dd0:	89e6                	mv	s3,s9
    80002dd2:	bfd1                	j	80002da6 <namex+0x5a>
  len = path - s;
    80002dd4:	40b48633          	sub	a2,s1,a1
    80002dd8:	00060c9b          	sext.w	s9,a2
  if(len >= DIRSIZ)
    80002ddc:	079c5c63          	bge	s8,s9,80002e54 <namex+0x108>
    memmove(name, s, DIRSIZ);
    80002de0:	4639                	li	a2,14
    80002de2:	8552                	mv	a0,s4
    80002de4:	bc4fd0ef          	jal	ra,800001a8 <memmove>
  while(*path == '/')
    80002de8:	0004c783          	lbu	a5,0(s1)
    80002dec:	01279763          	bne	a5,s2,80002dfa <namex+0xae>
    path++;
    80002df0:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002df2:	0004c783          	lbu	a5,0(s1)
    80002df6:	ff278de3          	beq	a5,s2,80002df0 <namex+0xa4>
    ilock(ip);
    80002dfa:	854e                	mv	a0,s3
    80002dfc:	a69ff0ef          	jal	ra,80002864 <ilock>
    if(ip->type != T_DIR){
    80002e00:	04499783          	lh	a5,68(s3)
    80002e04:	f9779de3          	bne	a5,s7,80002d9e <namex+0x52>
    if(nameiparent && *path == '\0'){
    80002e08:	000a8563          	beqz	s5,80002e12 <namex+0xc6>
    80002e0c:	0004c783          	lbu	a5,0(s1)
    80002e10:	dbcd                	beqz	a5,80002dc2 <namex+0x76>
    if((next = dirlookup(ip, name, 0)) == 0){
    80002e12:	865a                	mv	a2,s6
    80002e14:	85d2                	mv	a1,s4
    80002e16:	854e                	mv	a0,s3
    80002e18:	e99ff0ef          	jal	ra,80002cb0 <dirlookup>
    80002e1c:	8caa                	mv	s9,a0
    80002e1e:	d555                	beqz	a0,80002dca <namex+0x7e>
    iunlockput(ip);
    80002e20:	854e                	mv	a0,s3
    80002e22:	c49ff0ef          	jal	ra,80002a6a <iunlockput>
    ip = next;
    80002e26:	89e6                	mv	s3,s9
  while(*path == '/')
    80002e28:	0004c783          	lbu	a5,0(s1)
    80002e2c:	05279363          	bne	a5,s2,80002e72 <namex+0x126>
    path++;
    80002e30:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002e32:	0004c783          	lbu	a5,0(s1)
    80002e36:	ff278de3          	beq	a5,s2,80002e30 <namex+0xe4>
  if(*path == 0)
    80002e3a:	c78d                	beqz	a5,80002e64 <namex+0x118>
    path++;
    80002e3c:	85a6                	mv	a1,s1
  len = path - s;
    80002e3e:	8cda                	mv	s9,s6
    80002e40:	865a                	mv	a2,s6
  while(*path != '/' && *path != 0)
    80002e42:	01278963          	beq	a5,s2,80002e54 <namex+0x108>
    80002e46:	d7d9                	beqz	a5,80002dd4 <namex+0x88>
    path++;
    80002e48:	0485                	addi	s1,s1,1
  while(*path != '/' && *path != 0)
    80002e4a:	0004c783          	lbu	a5,0(s1)
    80002e4e:	ff279ce3          	bne	a5,s2,80002e46 <namex+0xfa>
    80002e52:	b749                	j	80002dd4 <namex+0x88>
    memmove(name, s, len);
    80002e54:	2601                	sext.w	a2,a2
    80002e56:	8552                	mv	a0,s4
    80002e58:	b50fd0ef          	jal	ra,800001a8 <memmove>
    name[len] = 0;
    80002e5c:	9cd2                	add	s9,s9,s4
    80002e5e:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80002e62:	b759                	j	80002de8 <namex+0x9c>
  if(nameiparent){
    80002e64:	f40a81e3          	beqz	s5,80002da6 <namex+0x5a>
    iput(ip);
    80002e68:	854e                	mv	a0,s3
    80002e6a:	b79ff0ef          	jal	ra,800029e2 <iput>
    return 0;
    80002e6e:	4981                	li	s3,0
    80002e70:	bf1d                	j	80002da6 <namex+0x5a>
  if(*path == 0)
    80002e72:	dbed                	beqz	a5,80002e64 <namex+0x118>
  while(*path != '/' && *path != 0)
    80002e74:	0004c783          	lbu	a5,0(s1)
    80002e78:	85a6                	mv	a1,s1
    80002e7a:	b7f1                	j	80002e46 <namex+0xfa>

0000000080002e7c <dirlink>:
{
    80002e7c:	7139                	addi	sp,sp,-64
    80002e7e:	fc06                	sd	ra,56(sp)
    80002e80:	f822                	sd	s0,48(sp)
    80002e82:	f426                	sd	s1,40(sp)
    80002e84:	f04a                	sd	s2,32(sp)
    80002e86:	ec4e                	sd	s3,24(sp)
    80002e88:	e852                	sd	s4,16(sp)
    80002e8a:	0080                	addi	s0,sp,64
    80002e8c:	892a                	mv	s2,a0
    80002e8e:	8a2e                	mv	s4,a1
    80002e90:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80002e92:	4601                	li	a2,0
    80002e94:	e1dff0ef          	jal	ra,80002cb0 <dirlookup>
    80002e98:	e52d                	bnez	a0,80002f02 <dirlink+0x86>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002e9a:	04c92483          	lw	s1,76(s2)
    80002e9e:	c48d                	beqz	s1,80002ec8 <dirlink+0x4c>
    80002ea0:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002ea2:	4741                	li	a4,16
    80002ea4:	86a6                	mv	a3,s1
    80002ea6:	fc040613          	addi	a2,s0,-64
    80002eaa:	4581                	li	a1,0
    80002eac:	854a                	mv	a0,s2
    80002eae:	c07ff0ef          	jal	ra,80002ab4 <readi>
    80002eb2:	47c1                	li	a5,16
    80002eb4:	04f51b63          	bne	a0,a5,80002f0a <dirlink+0x8e>
    if(de.inum == 0)
    80002eb8:	fc045783          	lhu	a5,-64(s0)
    80002ebc:	c791                	beqz	a5,80002ec8 <dirlink+0x4c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002ebe:	24c1                	addiw	s1,s1,16
    80002ec0:	04c92783          	lw	a5,76(s2)
    80002ec4:	fcf4efe3          	bltu	s1,a5,80002ea2 <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    80002ec8:	4639                	li	a2,14
    80002eca:	85d2                	mv	a1,s4
    80002ecc:	fc240513          	addi	a0,s0,-62
    80002ed0:	b84fd0ef          	jal	ra,80000254 <strncpy>
  de.inum = inum;
    80002ed4:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002ed8:	4741                	li	a4,16
    80002eda:	86a6                	mv	a3,s1
    80002edc:	fc040613          	addi	a2,s0,-64
    80002ee0:	4581                	li	a1,0
    80002ee2:	854a                	mv	a0,s2
    80002ee4:	cb5ff0ef          	jal	ra,80002b98 <writei>
    80002ee8:	1541                	addi	a0,a0,-16
    80002eea:	00a03533          	snez	a0,a0
    80002eee:	40a00533          	neg	a0,a0
}
    80002ef2:	70e2                	ld	ra,56(sp)
    80002ef4:	7442                	ld	s0,48(sp)
    80002ef6:	74a2                	ld	s1,40(sp)
    80002ef8:	7902                	ld	s2,32(sp)
    80002efa:	69e2                	ld	s3,24(sp)
    80002efc:	6a42                	ld	s4,16(sp)
    80002efe:	6121                	addi	sp,sp,64
    80002f00:	8082                	ret
    iput(ip);
    80002f02:	ae1ff0ef          	jal	ra,800029e2 <iput>
    return -1;
    80002f06:	557d                	li	a0,-1
    80002f08:	b7ed                	j	80002ef2 <dirlink+0x76>
      panic("dirlink read");
    80002f0a:	00004517          	auipc	a0,0x4
    80002f0e:	78650513          	addi	a0,a0,1926 # 80007690 <syscalls+0x238>
    80002f12:	5e4020ef          	jal	ra,800054f6 <panic>

0000000080002f16 <namei>:

struct inode*
namei(char *path)
{
    80002f16:	1101                	addi	sp,sp,-32
    80002f18:	ec06                	sd	ra,24(sp)
    80002f1a:	e822                	sd	s0,16(sp)
    80002f1c:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80002f1e:	fe040613          	addi	a2,s0,-32
    80002f22:	4581                	li	a1,0
    80002f24:	e29ff0ef          	jal	ra,80002d4c <namex>
}
    80002f28:	60e2                	ld	ra,24(sp)
    80002f2a:	6442                	ld	s0,16(sp)
    80002f2c:	6105                	addi	sp,sp,32
    80002f2e:	8082                	ret

0000000080002f30 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80002f30:	1141                	addi	sp,sp,-16
    80002f32:	e406                	sd	ra,8(sp)
    80002f34:	e022                	sd	s0,0(sp)
    80002f36:	0800                	addi	s0,sp,16
    80002f38:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80002f3a:	4585                	li	a1,1
    80002f3c:	e11ff0ef          	jal	ra,80002d4c <namex>
}
    80002f40:	60a2                	ld	ra,8(sp)
    80002f42:	6402                	ld	s0,0(sp)
    80002f44:	0141                	addi	sp,sp,16
    80002f46:	8082                	ret

0000000080002f48 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80002f48:	1101                	addi	sp,sp,-32
    80002f4a:	ec06                	sd	ra,24(sp)
    80002f4c:	e822                	sd	s0,16(sp)
    80002f4e:	e426                	sd	s1,8(sp)
    80002f50:	e04a                	sd	s2,0(sp)
    80002f52:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80002f54:	00015917          	auipc	s2,0x15
    80002f58:	c4c90913          	addi	s2,s2,-948 # 80017ba0 <log>
    80002f5c:	01892583          	lw	a1,24(s2)
    80002f60:	02892503          	lw	a0,40(s2)
    80002f64:	9e0ff0ef          	jal	ra,80002144 <bread>
    80002f68:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80002f6a:	02c92683          	lw	a3,44(s2)
    80002f6e:	cd34                	sw	a3,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80002f70:	02d05863          	blez	a3,80002fa0 <write_head+0x58>
    80002f74:	00015797          	auipc	a5,0x15
    80002f78:	c5c78793          	addi	a5,a5,-932 # 80017bd0 <log+0x30>
    80002f7c:	05c50713          	addi	a4,a0,92
    80002f80:	36fd                	addiw	a3,a3,-1
    80002f82:	02069613          	slli	a2,a3,0x20
    80002f86:	01e65693          	srli	a3,a2,0x1e
    80002f8a:	00015617          	auipc	a2,0x15
    80002f8e:	c4a60613          	addi	a2,a2,-950 # 80017bd4 <log+0x34>
    80002f92:	96b2                	add	a3,a3,a2
    hb->block[i] = log.lh.block[i];
    80002f94:	4390                	lw	a2,0(a5)
    80002f96:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80002f98:	0791                	addi	a5,a5,4
    80002f9a:	0711                	addi	a4,a4,4
    80002f9c:	fed79ce3          	bne	a5,a3,80002f94 <write_head+0x4c>
  }
  bwrite(buf);
    80002fa0:	8526                	mv	a0,s1
    80002fa2:	a78ff0ef          	jal	ra,8000221a <bwrite>
  brelse(buf);
    80002fa6:	8526                	mv	a0,s1
    80002fa8:	aa4ff0ef          	jal	ra,8000224c <brelse>
}
    80002fac:	60e2                	ld	ra,24(sp)
    80002fae:	6442                	ld	s0,16(sp)
    80002fb0:	64a2                	ld	s1,8(sp)
    80002fb2:	6902                	ld	s2,0(sp)
    80002fb4:	6105                	addi	sp,sp,32
    80002fb6:	8082                	ret

0000000080002fb8 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80002fb8:	00015797          	auipc	a5,0x15
    80002fbc:	c147a783          	lw	a5,-1004(a5) # 80017bcc <log+0x2c>
    80002fc0:	08f05f63          	blez	a5,8000305e <install_trans+0xa6>
{
    80002fc4:	7139                	addi	sp,sp,-64
    80002fc6:	fc06                	sd	ra,56(sp)
    80002fc8:	f822                	sd	s0,48(sp)
    80002fca:	f426                	sd	s1,40(sp)
    80002fcc:	f04a                	sd	s2,32(sp)
    80002fce:	ec4e                	sd	s3,24(sp)
    80002fd0:	e852                	sd	s4,16(sp)
    80002fd2:	e456                	sd	s5,8(sp)
    80002fd4:	e05a                	sd	s6,0(sp)
    80002fd6:	0080                	addi	s0,sp,64
    80002fd8:	8b2a                	mv	s6,a0
    80002fda:	00015a97          	auipc	s5,0x15
    80002fde:	bf6a8a93          	addi	s5,s5,-1034 # 80017bd0 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80002fe2:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80002fe4:	00015997          	auipc	s3,0x15
    80002fe8:	bbc98993          	addi	s3,s3,-1092 # 80017ba0 <log>
    80002fec:	a829                	j	80003006 <install_trans+0x4e>
    brelse(lbuf);
    80002fee:	854a                	mv	a0,s2
    80002ff0:	a5cff0ef          	jal	ra,8000224c <brelse>
    brelse(dbuf);
    80002ff4:	8526                	mv	a0,s1
    80002ff6:	a56ff0ef          	jal	ra,8000224c <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80002ffa:	2a05                	addiw	s4,s4,1
    80002ffc:	0a91                	addi	s5,s5,4
    80002ffe:	02c9a783          	lw	a5,44(s3)
    80003002:	04fa5463          	bge	s4,a5,8000304a <install_trans+0x92>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003006:	0189a583          	lw	a1,24(s3)
    8000300a:	014585bb          	addw	a1,a1,s4
    8000300e:	2585                	addiw	a1,a1,1
    80003010:	0289a503          	lw	a0,40(s3)
    80003014:	930ff0ef          	jal	ra,80002144 <bread>
    80003018:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    8000301a:	000aa583          	lw	a1,0(s5)
    8000301e:	0289a503          	lw	a0,40(s3)
    80003022:	922ff0ef          	jal	ra,80002144 <bread>
    80003026:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003028:	40000613          	li	a2,1024
    8000302c:	05890593          	addi	a1,s2,88
    80003030:	05850513          	addi	a0,a0,88
    80003034:	974fd0ef          	jal	ra,800001a8 <memmove>
    bwrite(dbuf);  // write dst to disk
    80003038:	8526                	mv	a0,s1
    8000303a:	9e0ff0ef          	jal	ra,8000221a <bwrite>
    if(recovering == 0)
    8000303e:	fa0b18e3          	bnez	s6,80002fee <install_trans+0x36>
      bunpin(dbuf);
    80003042:	8526                	mv	a0,s1
    80003044:	ac6ff0ef          	jal	ra,8000230a <bunpin>
    80003048:	b75d                	j	80002fee <install_trans+0x36>
}
    8000304a:	70e2                	ld	ra,56(sp)
    8000304c:	7442                	ld	s0,48(sp)
    8000304e:	74a2                	ld	s1,40(sp)
    80003050:	7902                	ld	s2,32(sp)
    80003052:	69e2                	ld	s3,24(sp)
    80003054:	6a42                	ld	s4,16(sp)
    80003056:	6aa2                	ld	s5,8(sp)
    80003058:	6b02                	ld	s6,0(sp)
    8000305a:	6121                	addi	sp,sp,64
    8000305c:	8082                	ret
    8000305e:	8082                	ret

0000000080003060 <initlog>:
{
    80003060:	7179                	addi	sp,sp,-48
    80003062:	f406                	sd	ra,40(sp)
    80003064:	f022                	sd	s0,32(sp)
    80003066:	ec26                	sd	s1,24(sp)
    80003068:	e84a                	sd	s2,16(sp)
    8000306a:	e44e                	sd	s3,8(sp)
    8000306c:	1800                	addi	s0,sp,48
    8000306e:	892a                	mv	s2,a0
    80003070:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003072:	00015497          	auipc	s1,0x15
    80003076:	b2e48493          	addi	s1,s1,-1234 # 80017ba0 <log>
    8000307a:	00004597          	auipc	a1,0x4
    8000307e:	62658593          	addi	a1,a1,1574 # 800076a0 <syscalls+0x248>
    80003082:	8526                	mv	a0,s1
    80003084:	706020ef          	jal	ra,8000578a <initlock>
  log.start = sb->logstart;
    80003088:	0149a583          	lw	a1,20(s3)
    8000308c:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    8000308e:	0109a783          	lw	a5,16(s3)
    80003092:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    80003094:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003098:	854a                	mv	a0,s2
    8000309a:	8aaff0ef          	jal	ra,80002144 <bread>
  log.lh.n = lh->n;
    8000309e:	4d34                	lw	a3,88(a0)
    800030a0:	d4d4                	sw	a3,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    800030a2:	02d05663          	blez	a3,800030ce <initlog+0x6e>
    800030a6:	05c50793          	addi	a5,a0,92
    800030aa:	00015717          	auipc	a4,0x15
    800030ae:	b2670713          	addi	a4,a4,-1242 # 80017bd0 <log+0x30>
    800030b2:	36fd                	addiw	a3,a3,-1
    800030b4:	02069613          	slli	a2,a3,0x20
    800030b8:	01e65693          	srli	a3,a2,0x1e
    800030bc:	06050613          	addi	a2,a0,96
    800030c0:	96b2                	add	a3,a3,a2
    log.lh.block[i] = lh->block[i];
    800030c2:	4390                	lw	a2,0(a5)
    800030c4:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    800030c6:	0791                	addi	a5,a5,4
    800030c8:	0711                	addi	a4,a4,4
    800030ca:	fed79ce3          	bne	a5,a3,800030c2 <initlog+0x62>
  brelse(buf);
    800030ce:	97eff0ef          	jal	ra,8000224c <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    800030d2:	4505                	li	a0,1
    800030d4:	ee5ff0ef          	jal	ra,80002fb8 <install_trans>
  log.lh.n = 0;
    800030d8:	00015797          	auipc	a5,0x15
    800030dc:	ae07aa23          	sw	zero,-1292(a5) # 80017bcc <log+0x2c>
  write_head(); // clear the log
    800030e0:	e69ff0ef          	jal	ra,80002f48 <write_head>
}
    800030e4:	70a2                	ld	ra,40(sp)
    800030e6:	7402                	ld	s0,32(sp)
    800030e8:	64e2                	ld	s1,24(sp)
    800030ea:	6942                	ld	s2,16(sp)
    800030ec:	69a2                	ld	s3,8(sp)
    800030ee:	6145                	addi	sp,sp,48
    800030f0:	8082                	ret

00000000800030f2 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    800030f2:	1101                	addi	sp,sp,-32
    800030f4:	ec06                	sd	ra,24(sp)
    800030f6:	e822                	sd	s0,16(sp)
    800030f8:	e426                	sd	s1,8(sp)
    800030fa:	e04a                	sd	s2,0(sp)
    800030fc:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    800030fe:	00015517          	auipc	a0,0x15
    80003102:	aa250513          	addi	a0,a0,-1374 # 80017ba0 <log>
    80003106:	704020ef          	jal	ra,8000580a <acquire>
  while(1){
    if(log.committing){
    8000310a:	00015497          	auipc	s1,0x15
    8000310e:	a9648493          	addi	s1,s1,-1386 # 80017ba0 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003112:	4979                	li	s2,30
    80003114:	a029                	j	8000311e <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003116:	85a6                	mv	a1,s1
    80003118:	8526                	mv	a0,s1
    8000311a:	b3efe0ef          	jal	ra,80001458 <sleep>
    if(log.committing){
    8000311e:	50dc                	lw	a5,36(s1)
    80003120:	fbfd                	bnez	a5,80003116 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003122:	509c                	lw	a5,32(s1)
    80003124:	0017871b          	addiw	a4,a5,1
    80003128:	0007069b          	sext.w	a3,a4
    8000312c:	0027179b          	slliw	a5,a4,0x2
    80003130:	9fb9                	addw	a5,a5,a4
    80003132:	0017979b          	slliw	a5,a5,0x1
    80003136:	54d8                	lw	a4,44(s1)
    80003138:	9fb9                	addw	a5,a5,a4
    8000313a:	00f95763          	bge	s2,a5,80003148 <begin_op+0x56>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    8000313e:	85a6                	mv	a1,s1
    80003140:	8526                	mv	a0,s1
    80003142:	b16fe0ef          	jal	ra,80001458 <sleep>
    80003146:	bfe1                	j	8000311e <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003148:	00015517          	auipc	a0,0x15
    8000314c:	a5850513          	addi	a0,a0,-1448 # 80017ba0 <log>
    80003150:	d114                	sw	a3,32(a0)
      release(&log.lock);
    80003152:	750020ef          	jal	ra,800058a2 <release>
      break;
    }
  }
}
    80003156:	60e2                	ld	ra,24(sp)
    80003158:	6442                	ld	s0,16(sp)
    8000315a:	64a2                	ld	s1,8(sp)
    8000315c:	6902                	ld	s2,0(sp)
    8000315e:	6105                	addi	sp,sp,32
    80003160:	8082                	ret

0000000080003162 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003162:	7139                	addi	sp,sp,-64
    80003164:	fc06                	sd	ra,56(sp)
    80003166:	f822                	sd	s0,48(sp)
    80003168:	f426                	sd	s1,40(sp)
    8000316a:	f04a                	sd	s2,32(sp)
    8000316c:	ec4e                	sd	s3,24(sp)
    8000316e:	e852                	sd	s4,16(sp)
    80003170:	e456                	sd	s5,8(sp)
    80003172:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003174:	00015497          	auipc	s1,0x15
    80003178:	a2c48493          	addi	s1,s1,-1492 # 80017ba0 <log>
    8000317c:	8526                	mv	a0,s1
    8000317e:	68c020ef          	jal	ra,8000580a <acquire>
  log.outstanding -= 1;
    80003182:	509c                	lw	a5,32(s1)
    80003184:	37fd                	addiw	a5,a5,-1
    80003186:	0007891b          	sext.w	s2,a5
    8000318a:	d09c                	sw	a5,32(s1)
  if(log.committing)
    8000318c:	50dc                	lw	a5,36(s1)
    8000318e:	ef9d                	bnez	a5,800031cc <end_op+0x6a>
    panic("log.committing");
  if(log.outstanding == 0){
    80003190:	04091463          	bnez	s2,800031d8 <end_op+0x76>
    do_commit = 1;
    log.committing = 1;
    80003194:	00015497          	auipc	s1,0x15
    80003198:	a0c48493          	addi	s1,s1,-1524 # 80017ba0 <log>
    8000319c:	4785                	li	a5,1
    8000319e:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    800031a0:	8526                	mv	a0,s1
    800031a2:	700020ef          	jal	ra,800058a2 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    800031a6:	54dc                	lw	a5,44(s1)
    800031a8:	04f04b63          	bgtz	a5,800031fe <end_op+0x9c>
    acquire(&log.lock);
    800031ac:	00015497          	auipc	s1,0x15
    800031b0:	9f448493          	addi	s1,s1,-1548 # 80017ba0 <log>
    800031b4:	8526                	mv	a0,s1
    800031b6:	654020ef          	jal	ra,8000580a <acquire>
    log.committing = 0;
    800031ba:	0204a223          	sw	zero,36(s1)
    wakeup(&log);
    800031be:	8526                	mv	a0,s1
    800031c0:	ae4fe0ef          	jal	ra,800014a4 <wakeup>
    release(&log.lock);
    800031c4:	8526                	mv	a0,s1
    800031c6:	6dc020ef          	jal	ra,800058a2 <release>
}
    800031ca:	a00d                	j	800031ec <end_op+0x8a>
    panic("log.committing");
    800031cc:	00004517          	auipc	a0,0x4
    800031d0:	4dc50513          	addi	a0,a0,1244 # 800076a8 <syscalls+0x250>
    800031d4:	322020ef          	jal	ra,800054f6 <panic>
    wakeup(&log);
    800031d8:	00015497          	auipc	s1,0x15
    800031dc:	9c848493          	addi	s1,s1,-1592 # 80017ba0 <log>
    800031e0:	8526                	mv	a0,s1
    800031e2:	ac2fe0ef          	jal	ra,800014a4 <wakeup>
  release(&log.lock);
    800031e6:	8526                	mv	a0,s1
    800031e8:	6ba020ef          	jal	ra,800058a2 <release>
}
    800031ec:	70e2                	ld	ra,56(sp)
    800031ee:	7442                	ld	s0,48(sp)
    800031f0:	74a2                	ld	s1,40(sp)
    800031f2:	7902                	ld	s2,32(sp)
    800031f4:	69e2                	ld	s3,24(sp)
    800031f6:	6a42                	ld	s4,16(sp)
    800031f8:	6aa2                	ld	s5,8(sp)
    800031fa:	6121                	addi	sp,sp,64
    800031fc:	8082                	ret
  for (tail = 0; tail < log.lh.n; tail++) {
    800031fe:	00015a97          	auipc	s5,0x15
    80003202:	9d2a8a93          	addi	s5,s5,-1582 # 80017bd0 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003206:	00015a17          	auipc	s4,0x15
    8000320a:	99aa0a13          	addi	s4,s4,-1638 # 80017ba0 <log>
    8000320e:	018a2583          	lw	a1,24(s4)
    80003212:	012585bb          	addw	a1,a1,s2
    80003216:	2585                	addiw	a1,a1,1
    80003218:	028a2503          	lw	a0,40(s4)
    8000321c:	f29fe0ef          	jal	ra,80002144 <bread>
    80003220:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003222:	000aa583          	lw	a1,0(s5)
    80003226:	028a2503          	lw	a0,40(s4)
    8000322a:	f1bfe0ef          	jal	ra,80002144 <bread>
    8000322e:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003230:	40000613          	li	a2,1024
    80003234:	05850593          	addi	a1,a0,88
    80003238:	05848513          	addi	a0,s1,88
    8000323c:	f6dfc0ef          	jal	ra,800001a8 <memmove>
    bwrite(to);  // write the log
    80003240:	8526                	mv	a0,s1
    80003242:	fd9fe0ef          	jal	ra,8000221a <bwrite>
    brelse(from);
    80003246:	854e                	mv	a0,s3
    80003248:	804ff0ef          	jal	ra,8000224c <brelse>
    brelse(to);
    8000324c:	8526                	mv	a0,s1
    8000324e:	ffffe0ef          	jal	ra,8000224c <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003252:	2905                	addiw	s2,s2,1
    80003254:	0a91                	addi	s5,s5,4
    80003256:	02ca2783          	lw	a5,44(s4)
    8000325a:	faf94ae3          	blt	s2,a5,8000320e <end_op+0xac>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    8000325e:	cebff0ef          	jal	ra,80002f48 <write_head>
    install_trans(0); // Now install writes to home locations
    80003262:	4501                	li	a0,0
    80003264:	d55ff0ef          	jal	ra,80002fb8 <install_trans>
    log.lh.n = 0;
    80003268:	00015797          	auipc	a5,0x15
    8000326c:	9607a223          	sw	zero,-1692(a5) # 80017bcc <log+0x2c>
    write_head();    // Erase the transaction from the log
    80003270:	cd9ff0ef          	jal	ra,80002f48 <write_head>
    80003274:	bf25                	j	800031ac <end_op+0x4a>

0000000080003276 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003276:	1101                	addi	sp,sp,-32
    80003278:	ec06                	sd	ra,24(sp)
    8000327a:	e822                	sd	s0,16(sp)
    8000327c:	e426                	sd	s1,8(sp)
    8000327e:	e04a                	sd	s2,0(sp)
    80003280:	1000                	addi	s0,sp,32
    80003282:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003284:	00015917          	auipc	s2,0x15
    80003288:	91c90913          	addi	s2,s2,-1764 # 80017ba0 <log>
    8000328c:	854a                	mv	a0,s2
    8000328e:	57c020ef          	jal	ra,8000580a <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    80003292:	02c92603          	lw	a2,44(s2)
    80003296:	47f5                	li	a5,29
    80003298:	06c7c363          	blt	a5,a2,800032fe <log_write+0x88>
    8000329c:	00015797          	auipc	a5,0x15
    800032a0:	9207a783          	lw	a5,-1760(a5) # 80017bbc <log+0x1c>
    800032a4:	37fd                	addiw	a5,a5,-1
    800032a6:	04f65c63          	bge	a2,a5,800032fe <log_write+0x88>
    panic("too big a transaction");
  if (log.outstanding < 1)
    800032aa:	00015797          	auipc	a5,0x15
    800032ae:	9167a783          	lw	a5,-1770(a5) # 80017bc0 <log+0x20>
    800032b2:	04f05c63          	blez	a5,8000330a <log_write+0x94>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    800032b6:	4781                	li	a5,0
    800032b8:	04c05f63          	blez	a2,80003316 <log_write+0xa0>
    if (log.lh.block[i] == b->blockno)   // log absorption
    800032bc:	44cc                	lw	a1,12(s1)
    800032be:	00015717          	auipc	a4,0x15
    800032c2:	91270713          	addi	a4,a4,-1774 # 80017bd0 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    800032c6:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    800032c8:	4314                	lw	a3,0(a4)
    800032ca:	04b68663          	beq	a3,a1,80003316 <log_write+0xa0>
  for (i = 0; i < log.lh.n; i++) {
    800032ce:	2785                	addiw	a5,a5,1
    800032d0:	0711                	addi	a4,a4,4
    800032d2:	fef61be3          	bne	a2,a5,800032c8 <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    800032d6:	0621                	addi	a2,a2,8
    800032d8:	060a                	slli	a2,a2,0x2
    800032da:	00015797          	auipc	a5,0x15
    800032de:	8c678793          	addi	a5,a5,-1850 # 80017ba0 <log>
    800032e2:	963e                	add	a2,a2,a5
    800032e4:	44dc                	lw	a5,12(s1)
    800032e6:	ca1c                	sw	a5,16(a2)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    800032e8:	8526                	mv	a0,s1
    800032ea:	fedfe0ef          	jal	ra,800022d6 <bpin>
    log.lh.n++;
    800032ee:	00015717          	auipc	a4,0x15
    800032f2:	8b270713          	addi	a4,a4,-1870 # 80017ba0 <log>
    800032f6:	575c                	lw	a5,44(a4)
    800032f8:	2785                	addiw	a5,a5,1
    800032fa:	d75c                	sw	a5,44(a4)
    800032fc:	a815                	j	80003330 <log_write+0xba>
    panic("too big a transaction");
    800032fe:	00004517          	auipc	a0,0x4
    80003302:	3ba50513          	addi	a0,a0,954 # 800076b8 <syscalls+0x260>
    80003306:	1f0020ef          	jal	ra,800054f6 <panic>
    panic("log_write outside of trans");
    8000330a:	00004517          	auipc	a0,0x4
    8000330e:	3c650513          	addi	a0,a0,966 # 800076d0 <syscalls+0x278>
    80003312:	1e4020ef          	jal	ra,800054f6 <panic>
  log.lh.block[i] = b->blockno;
    80003316:	00878713          	addi	a4,a5,8
    8000331a:	00271693          	slli	a3,a4,0x2
    8000331e:	00015717          	auipc	a4,0x15
    80003322:	88270713          	addi	a4,a4,-1918 # 80017ba0 <log>
    80003326:	9736                	add	a4,a4,a3
    80003328:	44d4                	lw	a3,12(s1)
    8000332a:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    8000332c:	faf60ee3          	beq	a2,a5,800032e8 <log_write+0x72>
  }
  release(&log.lock);
    80003330:	00015517          	auipc	a0,0x15
    80003334:	87050513          	addi	a0,a0,-1936 # 80017ba0 <log>
    80003338:	56a020ef          	jal	ra,800058a2 <release>
}
    8000333c:	60e2                	ld	ra,24(sp)
    8000333e:	6442                	ld	s0,16(sp)
    80003340:	64a2                	ld	s1,8(sp)
    80003342:	6902                	ld	s2,0(sp)
    80003344:	6105                	addi	sp,sp,32
    80003346:	8082                	ret

0000000080003348 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003348:	1101                	addi	sp,sp,-32
    8000334a:	ec06                	sd	ra,24(sp)
    8000334c:	e822                	sd	s0,16(sp)
    8000334e:	e426                	sd	s1,8(sp)
    80003350:	e04a                	sd	s2,0(sp)
    80003352:	1000                	addi	s0,sp,32
    80003354:	84aa                	mv	s1,a0
    80003356:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003358:	00004597          	auipc	a1,0x4
    8000335c:	39858593          	addi	a1,a1,920 # 800076f0 <syscalls+0x298>
    80003360:	0521                	addi	a0,a0,8
    80003362:	428020ef          	jal	ra,8000578a <initlock>
  lk->name = name;
    80003366:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    8000336a:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000336e:	0204a423          	sw	zero,40(s1)
}
    80003372:	60e2                	ld	ra,24(sp)
    80003374:	6442                	ld	s0,16(sp)
    80003376:	64a2                	ld	s1,8(sp)
    80003378:	6902                	ld	s2,0(sp)
    8000337a:	6105                	addi	sp,sp,32
    8000337c:	8082                	ret

000000008000337e <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    8000337e:	1101                	addi	sp,sp,-32
    80003380:	ec06                	sd	ra,24(sp)
    80003382:	e822                	sd	s0,16(sp)
    80003384:	e426                	sd	s1,8(sp)
    80003386:	e04a                	sd	s2,0(sp)
    80003388:	1000                	addi	s0,sp,32
    8000338a:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000338c:	00850913          	addi	s2,a0,8
    80003390:	854a                	mv	a0,s2
    80003392:	478020ef          	jal	ra,8000580a <acquire>
  while (lk->locked) {
    80003396:	409c                	lw	a5,0(s1)
    80003398:	c799                	beqz	a5,800033a6 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    8000339a:	85ca                	mv	a1,s2
    8000339c:	8526                	mv	a0,s1
    8000339e:	8bafe0ef          	jal	ra,80001458 <sleep>
  while (lk->locked) {
    800033a2:	409c                	lw	a5,0(s1)
    800033a4:	fbfd                	bnez	a5,8000339a <acquiresleep+0x1c>
  }
  lk->locked = 1;
    800033a6:	4785                	li	a5,1
    800033a8:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    800033aa:	a59fd0ef          	jal	ra,80000e02 <myproc>
    800033ae:	591c                	lw	a5,48(a0)
    800033b0:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    800033b2:	854a                	mv	a0,s2
    800033b4:	4ee020ef          	jal	ra,800058a2 <release>
}
    800033b8:	60e2                	ld	ra,24(sp)
    800033ba:	6442                	ld	s0,16(sp)
    800033bc:	64a2                	ld	s1,8(sp)
    800033be:	6902                	ld	s2,0(sp)
    800033c0:	6105                	addi	sp,sp,32
    800033c2:	8082                	ret

00000000800033c4 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800033c4:	1101                	addi	sp,sp,-32
    800033c6:	ec06                	sd	ra,24(sp)
    800033c8:	e822                	sd	s0,16(sp)
    800033ca:	e426                	sd	s1,8(sp)
    800033cc:	e04a                	sd	s2,0(sp)
    800033ce:	1000                	addi	s0,sp,32
    800033d0:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800033d2:	00850913          	addi	s2,a0,8
    800033d6:	854a                	mv	a0,s2
    800033d8:	432020ef          	jal	ra,8000580a <acquire>
  lk->locked = 0;
    800033dc:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800033e0:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    800033e4:	8526                	mv	a0,s1
    800033e6:	8befe0ef          	jal	ra,800014a4 <wakeup>
  release(&lk->lk);
    800033ea:	854a                	mv	a0,s2
    800033ec:	4b6020ef          	jal	ra,800058a2 <release>
}
    800033f0:	60e2                	ld	ra,24(sp)
    800033f2:	6442                	ld	s0,16(sp)
    800033f4:	64a2                	ld	s1,8(sp)
    800033f6:	6902                	ld	s2,0(sp)
    800033f8:	6105                	addi	sp,sp,32
    800033fa:	8082                	ret

00000000800033fc <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    800033fc:	7179                	addi	sp,sp,-48
    800033fe:	f406                	sd	ra,40(sp)
    80003400:	f022                	sd	s0,32(sp)
    80003402:	ec26                	sd	s1,24(sp)
    80003404:	e84a                	sd	s2,16(sp)
    80003406:	e44e                	sd	s3,8(sp)
    80003408:	1800                	addi	s0,sp,48
    8000340a:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    8000340c:	00850913          	addi	s2,a0,8
    80003410:	854a                	mv	a0,s2
    80003412:	3f8020ef          	jal	ra,8000580a <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003416:	409c                	lw	a5,0(s1)
    80003418:	ef89                	bnez	a5,80003432 <holdingsleep+0x36>
    8000341a:	4481                	li	s1,0
  release(&lk->lk);
    8000341c:	854a                	mv	a0,s2
    8000341e:	484020ef          	jal	ra,800058a2 <release>
  return r;
}
    80003422:	8526                	mv	a0,s1
    80003424:	70a2                	ld	ra,40(sp)
    80003426:	7402                	ld	s0,32(sp)
    80003428:	64e2                	ld	s1,24(sp)
    8000342a:	6942                	ld	s2,16(sp)
    8000342c:	69a2                	ld	s3,8(sp)
    8000342e:	6145                	addi	sp,sp,48
    80003430:	8082                	ret
  r = lk->locked && (lk->pid == myproc()->pid);
    80003432:	0284a983          	lw	s3,40(s1)
    80003436:	9cdfd0ef          	jal	ra,80000e02 <myproc>
    8000343a:	5904                	lw	s1,48(a0)
    8000343c:	413484b3          	sub	s1,s1,s3
    80003440:	0014b493          	seqz	s1,s1
    80003444:	bfe1                	j	8000341c <holdingsleep+0x20>

0000000080003446 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80003446:	1141                	addi	sp,sp,-16
    80003448:	e406                	sd	ra,8(sp)
    8000344a:	e022                	sd	s0,0(sp)
    8000344c:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    8000344e:	00004597          	auipc	a1,0x4
    80003452:	2b258593          	addi	a1,a1,690 # 80007700 <syscalls+0x2a8>
    80003456:	00015517          	auipc	a0,0x15
    8000345a:	89250513          	addi	a0,a0,-1902 # 80017ce8 <ftable>
    8000345e:	32c020ef          	jal	ra,8000578a <initlock>
}
    80003462:	60a2                	ld	ra,8(sp)
    80003464:	6402                	ld	s0,0(sp)
    80003466:	0141                	addi	sp,sp,16
    80003468:	8082                	ret

000000008000346a <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    8000346a:	1101                	addi	sp,sp,-32
    8000346c:	ec06                	sd	ra,24(sp)
    8000346e:	e822                	sd	s0,16(sp)
    80003470:	e426                	sd	s1,8(sp)
    80003472:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80003474:	00015517          	auipc	a0,0x15
    80003478:	87450513          	addi	a0,a0,-1932 # 80017ce8 <ftable>
    8000347c:	38e020ef          	jal	ra,8000580a <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003480:	00015497          	auipc	s1,0x15
    80003484:	88048493          	addi	s1,s1,-1920 # 80017d00 <ftable+0x18>
    80003488:	00016717          	auipc	a4,0x16
    8000348c:	81870713          	addi	a4,a4,-2024 # 80018ca0 <disk>
    if(f->ref == 0){
    80003490:	40dc                	lw	a5,4(s1)
    80003492:	cf89                	beqz	a5,800034ac <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003494:	02848493          	addi	s1,s1,40
    80003498:	fee49ce3          	bne	s1,a4,80003490 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    8000349c:	00015517          	auipc	a0,0x15
    800034a0:	84c50513          	addi	a0,a0,-1972 # 80017ce8 <ftable>
    800034a4:	3fe020ef          	jal	ra,800058a2 <release>
  return 0;
    800034a8:	4481                	li	s1,0
    800034aa:	a809                	j	800034bc <filealloc+0x52>
      f->ref = 1;
    800034ac:	4785                	li	a5,1
    800034ae:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800034b0:	00015517          	auipc	a0,0x15
    800034b4:	83850513          	addi	a0,a0,-1992 # 80017ce8 <ftable>
    800034b8:	3ea020ef          	jal	ra,800058a2 <release>
}
    800034bc:	8526                	mv	a0,s1
    800034be:	60e2                	ld	ra,24(sp)
    800034c0:	6442                	ld	s0,16(sp)
    800034c2:	64a2                	ld	s1,8(sp)
    800034c4:	6105                	addi	sp,sp,32
    800034c6:	8082                	ret

00000000800034c8 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    800034c8:	1101                	addi	sp,sp,-32
    800034ca:	ec06                	sd	ra,24(sp)
    800034cc:	e822                	sd	s0,16(sp)
    800034ce:	e426                	sd	s1,8(sp)
    800034d0:	1000                	addi	s0,sp,32
    800034d2:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    800034d4:	00015517          	auipc	a0,0x15
    800034d8:	81450513          	addi	a0,a0,-2028 # 80017ce8 <ftable>
    800034dc:	32e020ef          	jal	ra,8000580a <acquire>
  if(f->ref < 1)
    800034e0:	40dc                	lw	a5,4(s1)
    800034e2:	02f05063          	blez	a5,80003502 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    800034e6:	2785                	addiw	a5,a5,1
    800034e8:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    800034ea:	00014517          	auipc	a0,0x14
    800034ee:	7fe50513          	addi	a0,a0,2046 # 80017ce8 <ftable>
    800034f2:	3b0020ef          	jal	ra,800058a2 <release>
  return f;
}
    800034f6:	8526                	mv	a0,s1
    800034f8:	60e2                	ld	ra,24(sp)
    800034fa:	6442                	ld	s0,16(sp)
    800034fc:	64a2                	ld	s1,8(sp)
    800034fe:	6105                	addi	sp,sp,32
    80003500:	8082                	ret
    panic("filedup");
    80003502:	00004517          	auipc	a0,0x4
    80003506:	20650513          	addi	a0,a0,518 # 80007708 <syscalls+0x2b0>
    8000350a:	7ed010ef          	jal	ra,800054f6 <panic>

000000008000350e <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    8000350e:	7139                	addi	sp,sp,-64
    80003510:	fc06                	sd	ra,56(sp)
    80003512:	f822                	sd	s0,48(sp)
    80003514:	f426                	sd	s1,40(sp)
    80003516:	f04a                	sd	s2,32(sp)
    80003518:	ec4e                	sd	s3,24(sp)
    8000351a:	e852                	sd	s4,16(sp)
    8000351c:	e456                	sd	s5,8(sp)
    8000351e:	0080                	addi	s0,sp,64
    80003520:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80003522:	00014517          	auipc	a0,0x14
    80003526:	7c650513          	addi	a0,a0,1990 # 80017ce8 <ftable>
    8000352a:	2e0020ef          	jal	ra,8000580a <acquire>
  if(f->ref < 1)
    8000352e:	40dc                	lw	a5,4(s1)
    80003530:	04f05963          	blez	a5,80003582 <fileclose+0x74>
    panic("fileclose");
  if(--f->ref > 0){
    80003534:	37fd                	addiw	a5,a5,-1
    80003536:	0007871b          	sext.w	a4,a5
    8000353a:	c0dc                	sw	a5,4(s1)
    8000353c:	04e04963          	bgtz	a4,8000358e <fileclose+0x80>
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80003540:	0004a903          	lw	s2,0(s1)
    80003544:	0094ca83          	lbu	s5,9(s1)
    80003548:	0104ba03          	ld	s4,16(s1)
    8000354c:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    80003550:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80003554:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80003558:	00014517          	auipc	a0,0x14
    8000355c:	79050513          	addi	a0,a0,1936 # 80017ce8 <ftable>
    80003560:	342020ef          	jal	ra,800058a2 <release>

  if(ff.type == FD_PIPE){
    80003564:	4785                	li	a5,1
    80003566:	04f90363          	beq	s2,a5,800035ac <fileclose+0x9e>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    8000356a:	3979                	addiw	s2,s2,-2
    8000356c:	4785                	li	a5,1
    8000356e:	0327e663          	bltu	a5,s2,8000359a <fileclose+0x8c>
    begin_op();
    80003572:	b81ff0ef          	jal	ra,800030f2 <begin_op>
    iput(ff.ip);
    80003576:	854e                	mv	a0,s3
    80003578:	c6aff0ef          	jal	ra,800029e2 <iput>
    end_op();
    8000357c:	be7ff0ef          	jal	ra,80003162 <end_op>
    80003580:	a829                	j	8000359a <fileclose+0x8c>
    panic("fileclose");
    80003582:	00004517          	auipc	a0,0x4
    80003586:	18e50513          	addi	a0,a0,398 # 80007710 <syscalls+0x2b8>
    8000358a:	76d010ef          	jal	ra,800054f6 <panic>
    release(&ftable.lock);
    8000358e:	00014517          	auipc	a0,0x14
    80003592:	75a50513          	addi	a0,a0,1882 # 80017ce8 <ftable>
    80003596:	30c020ef          	jal	ra,800058a2 <release>
  }
}
    8000359a:	70e2                	ld	ra,56(sp)
    8000359c:	7442                	ld	s0,48(sp)
    8000359e:	74a2                	ld	s1,40(sp)
    800035a0:	7902                	ld	s2,32(sp)
    800035a2:	69e2                	ld	s3,24(sp)
    800035a4:	6a42                	ld	s4,16(sp)
    800035a6:	6aa2                	ld	s5,8(sp)
    800035a8:	6121                	addi	sp,sp,64
    800035aa:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800035ac:	85d6                	mv	a1,s5
    800035ae:	8552                	mv	a0,s4
    800035b0:	2ec000ef          	jal	ra,8000389c <pipeclose>
    800035b4:	b7dd                	j	8000359a <fileclose+0x8c>

00000000800035b6 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800035b6:	715d                	addi	sp,sp,-80
    800035b8:	e486                	sd	ra,72(sp)
    800035ba:	e0a2                	sd	s0,64(sp)
    800035bc:	fc26                	sd	s1,56(sp)
    800035be:	f84a                	sd	s2,48(sp)
    800035c0:	f44e                	sd	s3,40(sp)
    800035c2:	0880                	addi	s0,sp,80
    800035c4:	84aa                	mv	s1,a0
    800035c6:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    800035c8:	83bfd0ef          	jal	ra,80000e02 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    800035cc:	409c                	lw	a5,0(s1)
    800035ce:	37f9                	addiw	a5,a5,-2
    800035d0:	4705                	li	a4,1
    800035d2:	02f76f63          	bltu	a4,a5,80003610 <filestat+0x5a>
    800035d6:	892a                	mv	s2,a0
    ilock(f->ip);
    800035d8:	6c88                	ld	a0,24(s1)
    800035da:	a8aff0ef          	jal	ra,80002864 <ilock>
    stati(f->ip, &st);
    800035de:	fb840593          	addi	a1,s0,-72
    800035e2:	6c88                	ld	a0,24(s1)
    800035e4:	ca6ff0ef          	jal	ra,80002a8a <stati>
    iunlock(f->ip);
    800035e8:	6c88                	ld	a0,24(s1)
    800035ea:	b24ff0ef          	jal	ra,8000290e <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    800035ee:	46e1                	li	a3,24
    800035f0:	fb840613          	addi	a2,s0,-72
    800035f4:	85ce                	mv	a1,s3
    800035f6:	05893503          	ld	a0,88(s2)
    800035fa:	c7efd0ef          	jal	ra,80000a78 <copyout>
    800035fe:	41f5551b          	sraiw	a0,a0,0x1f
      return -1;
    return 0;
  }
  return -1;
}
    80003602:	60a6                	ld	ra,72(sp)
    80003604:	6406                	ld	s0,64(sp)
    80003606:	74e2                	ld	s1,56(sp)
    80003608:	7942                	ld	s2,48(sp)
    8000360a:	79a2                	ld	s3,40(sp)
    8000360c:	6161                	addi	sp,sp,80
    8000360e:	8082                	ret
  return -1;
    80003610:	557d                	li	a0,-1
    80003612:	bfc5                	j	80003602 <filestat+0x4c>

0000000080003614 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80003614:	7179                	addi	sp,sp,-48
    80003616:	f406                	sd	ra,40(sp)
    80003618:	f022                	sd	s0,32(sp)
    8000361a:	ec26                	sd	s1,24(sp)
    8000361c:	e84a                	sd	s2,16(sp)
    8000361e:	e44e                	sd	s3,8(sp)
    80003620:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80003622:	00854783          	lbu	a5,8(a0)
    80003626:	cbc1                	beqz	a5,800036b6 <fileread+0xa2>
    80003628:	84aa                	mv	s1,a0
    8000362a:	89ae                	mv	s3,a1
    8000362c:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    8000362e:	411c                	lw	a5,0(a0)
    80003630:	4705                	li	a4,1
    80003632:	04e78363          	beq	a5,a4,80003678 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80003636:	470d                	li	a4,3
    80003638:	04e78563          	beq	a5,a4,80003682 <fileread+0x6e>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    8000363c:	4709                	li	a4,2
    8000363e:	06e79663          	bne	a5,a4,800036aa <fileread+0x96>
    ilock(f->ip);
    80003642:	6d08                	ld	a0,24(a0)
    80003644:	a20ff0ef          	jal	ra,80002864 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80003648:	874a                	mv	a4,s2
    8000364a:	5094                	lw	a3,32(s1)
    8000364c:	864e                	mv	a2,s3
    8000364e:	4585                	li	a1,1
    80003650:	6c88                	ld	a0,24(s1)
    80003652:	c62ff0ef          	jal	ra,80002ab4 <readi>
    80003656:	892a                	mv	s2,a0
    80003658:	00a05563          	blez	a0,80003662 <fileread+0x4e>
      f->off += r;
    8000365c:	509c                	lw	a5,32(s1)
    8000365e:	9fa9                	addw	a5,a5,a0
    80003660:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80003662:	6c88                	ld	a0,24(s1)
    80003664:	aaaff0ef          	jal	ra,8000290e <iunlock>
  } else {
    panic("fileread");
  }

  return r;
}
    80003668:	854a                	mv	a0,s2
    8000366a:	70a2                	ld	ra,40(sp)
    8000366c:	7402                	ld	s0,32(sp)
    8000366e:	64e2                	ld	s1,24(sp)
    80003670:	6942                	ld	s2,16(sp)
    80003672:	69a2                	ld	s3,8(sp)
    80003674:	6145                	addi	sp,sp,48
    80003676:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80003678:	6908                	ld	a0,16(a0)
    8000367a:	34e000ef          	jal	ra,800039c8 <piperead>
    8000367e:	892a                	mv	s2,a0
    80003680:	b7e5                	j	80003668 <fileread+0x54>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80003682:	02451783          	lh	a5,36(a0)
    80003686:	03079693          	slli	a3,a5,0x30
    8000368a:	92c1                	srli	a3,a3,0x30
    8000368c:	4725                	li	a4,9
    8000368e:	02d76663          	bltu	a4,a3,800036ba <fileread+0xa6>
    80003692:	0792                	slli	a5,a5,0x4
    80003694:	00014717          	auipc	a4,0x14
    80003698:	5b470713          	addi	a4,a4,1460 # 80017c48 <devsw>
    8000369c:	97ba                	add	a5,a5,a4
    8000369e:	639c                	ld	a5,0(a5)
    800036a0:	cf99                	beqz	a5,800036be <fileread+0xaa>
    r = devsw[f->major].read(1, addr, n);
    800036a2:	4505                	li	a0,1
    800036a4:	9782                	jalr	a5
    800036a6:	892a                	mv	s2,a0
    800036a8:	b7c1                	j	80003668 <fileread+0x54>
    panic("fileread");
    800036aa:	00004517          	auipc	a0,0x4
    800036ae:	07650513          	addi	a0,a0,118 # 80007720 <syscalls+0x2c8>
    800036b2:	645010ef          	jal	ra,800054f6 <panic>
    return -1;
    800036b6:	597d                	li	s2,-1
    800036b8:	bf45                	j	80003668 <fileread+0x54>
      return -1;
    800036ba:	597d                	li	s2,-1
    800036bc:	b775                	j	80003668 <fileread+0x54>
    800036be:	597d                	li	s2,-1
    800036c0:	b765                	j	80003668 <fileread+0x54>

00000000800036c2 <filewrite>:

// Write to file f.
// addr is a user virtual address.
int
filewrite(struct file *f, uint64 addr, int n)
{
    800036c2:	715d                	addi	sp,sp,-80
    800036c4:	e486                	sd	ra,72(sp)
    800036c6:	e0a2                	sd	s0,64(sp)
    800036c8:	fc26                	sd	s1,56(sp)
    800036ca:	f84a                	sd	s2,48(sp)
    800036cc:	f44e                	sd	s3,40(sp)
    800036ce:	f052                	sd	s4,32(sp)
    800036d0:	ec56                	sd	s5,24(sp)
    800036d2:	e85a                	sd	s6,16(sp)
    800036d4:	e45e                	sd	s7,8(sp)
    800036d6:	e062                	sd	s8,0(sp)
    800036d8:	0880                	addi	s0,sp,80
  int r, ret = 0;

  if(f->writable == 0)
    800036da:	00954783          	lbu	a5,9(a0)
    800036de:	0e078863          	beqz	a5,800037ce <filewrite+0x10c>
    800036e2:	892a                	mv	s2,a0
    800036e4:	8aae                	mv	s5,a1
    800036e6:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    800036e8:	411c                	lw	a5,0(a0)
    800036ea:	4705                	li	a4,1
    800036ec:	02e78263          	beq	a5,a4,80003710 <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800036f0:	470d                	li	a4,3
    800036f2:	02e78463          	beq	a5,a4,8000371a <filewrite+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800036f6:	4709                	li	a4,2
    800036f8:	0ce79563          	bne	a5,a4,800037c2 <filewrite+0x100>
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800036fc:	0ac05163          	blez	a2,8000379e <filewrite+0xdc>
    int i = 0;
    80003700:	4981                	li	s3,0
    80003702:	6b05                	lui	s6,0x1
    80003704:	c00b0b13          	addi	s6,s6,-1024 # c00 <_entry-0x7ffff400>
    80003708:	6b85                	lui	s7,0x1
    8000370a:	c00b8b9b          	addiw	s7,s7,-1024
    8000370e:	a041                	j	8000378e <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    80003710:	6908                	ld	a0,16(a0)
    80003712:	1e2000ef          	jal	ra,800038f4 <pipewrite>
    80003716:	8a2a                	mv	s4,a0
    80003718:	a071                	j	800037a4 <filewrite+0xe2>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    8000371a:	02451783          	lh	a5,36(a0)
    8000371e:	03079693          	slli	a3,a5,0x30
    80003722:	92c1                	srli	a3,a3,0x30
    80003724:	4725                	li	a4,9
    80003726:	0ad76663          	bltu	a4,a3,800037d2 <filewrite+0x110>
    8000372a:	0792                	slli	a5,a5,0x4
    8000372c:	00014717          	auipc	a4,0x14
    80003730:	51c70713          	addi	a4,a4,1308 # 80017c48 <devsw>
    80003734:	97ba                	add	a5,a5,a4
    80003736:	679c                	ld	a5,8(a5)
    80003738:	cfd9                	beqz	a5,800037d6 <filewrite+0x114>
    ret = devsw[f->major].write(1, addr, n);
    8000373a:	4505                	li	a0,1
    8000373c:	9782                	jalr	a5
    8000373e:	8a2a                	mv	s4,a0
    80003740:	a095                	j	800037a4 <filewrite+0xe2>
    80003742:	00048c1b          	sext.w	s8,s1
      int n1 = n - i;
      if(n1 > max)
        n1 = max;

      begin_op();
    80003746:	9adff0ef          	jal	ra,800030f2 <begin_op>
      ilock(f->ip);
    8000374a:	01893503          	ld	a0,24(s2)
    8000374e:	916ff0ef          	jal	ra,80002864 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80003752:	8762                	mv	a4,s8
    80003754:	02092683          	lw	a3,32(s2)
    80003758:	01598633          	add	a2,s3,s5
    8000375c:	4585                	li	a1,1
    8000375e:	01893503          	ld	a0,24(s2)
    80003762:	c36ff0ef          	jal	ra,80002b98 <writei>
    80003766:	84aa                	mv	s1,a0
    80003768:	00a05763          	blez	a0,80003776 <filewrite+0xb4>
        f->off += r;
    8000376c:	02092783          	lw	a5,32(s2)
    80003770:	9fa9                	addw	a5,a5,a0
    80003772:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80003776:	01893503          	ld	a0,24(s2)
    8000377a:	994ff0ef          	jal	ra,8000290e <iunlock>
      end_op();
    8000377e:	9e5ff0ef          	jal	ra,80003162 <end_op>

      if(r != n1){
    80003782:	009c1f63          	bne	s8,s1,800037a0 <filewrite+0xde>
        // error from writei
        break;
      }
      i += r;
    80003786:	013489bb          	addw	s3,s1,s3
    while(i < n){
    8000378a:	0149db63          	bge	s3,s4,800037a0 <filewrite+0xde>
      int n1 = n - i;
    8000378e:	413a07bb          	subw	a5,s4,s3
      if(n1 > max)
    80003792:	84be                	mv	s1,a5
    80003794:	2781                	sext.w	a5,a5
    80003796:	fafb56e3          	bge	s6,a5,80003742 <filewrite+0x80>
    8000379a:	84de                	mv	s1,s7
    8000379c:	b75d                	j	80003742 <filewrite+0x80>
    int i = 0;
    8000379e:	4981                	li	s3,0
    }
    ret = (i == n ? n : -1);
    800037a0:	013a1f63          	bne	s4,s3,800037be <filewrite+0xfc>
  } else {
    panic("filewrite");
  }

  return ret;
}
    800037a4:	8552                	mv	a0,s4
    800037a6:	60a6                	ld	ra,72(sp)
    800037a8:	6406                	ld	s0,64(sp)
    800037aa:	74e2                	ld	s1,56(sp)
    800037ac:	7942                	ld	s2,48(sp)
    800037ae:	79a2                	ld	s3,40(sp)
    800037b0:	7a02                	ld	s4,32(sp)
    800037b2:	6ae2                	ld	s5,24(sp)
    800037b4:	6b42                	ld	s6,16(sp)
    800037b6:	6ba2                	ld	s7,8(sp)
    800037b8:	6c02                	ld	s8,0(sp)
    800037ba:	6161                	addi	sp,sp,80
    800037bc:	8082                	ret
    ret = (i == n ? n : -1);
    800037be:	5a7d                	li	s4,-1
    800037c0:	b7d5                	j	800037a4 <filewrite+0xe2>
    panic("filewrite");
    800037c2:	00004517          	auipc	a0,0x4
    800037c6:	f6e50513          	addi	a0,a0,-146 # 80007730 <syscalls+0x2d8>
    800037ca:	52d010ef          	jal	ra,800054f6 <panic>
    return -1;
    800037ce:	5a7d                	li	s4,-1
    800037d0:	bfd1                	j	800037a4 <filewrite+0xe2>
      return -1;
    800037d2:	5a7d                	li	s4,-1
    800037d4:	bfc1                	j	800037a4 <filewrite+0xe2>
    800037d6:	5a7d                	li	s4,-1
    800037d8:	b7f1                	j	800037a4 <filewrite+0xe2>

00000000800037da <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800037da:	7179                	addi	sp,sp,-48
    800037dc:	f406                	sd	ra,40(sp)
    800037de:	f022                	sd	s0,32(sp)
    800037e0:	ec26                	sd	s1,24(sp)
    800037e2:	e84a                	sd	s2,16(sp)
    800037e4:	e44e                	sd	s3,8(sp)
    800037e6:	e052                	sd	s4,0(sp)
    800037e8:	1800                	addi	s0,sp,48
    800037ea:	84aa                	mv	s1,a0
    800037ec:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800037ee:	0005b023          	sd	zero,0(a1)
    800037f2:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800037f6:	c75ff0ef          	jal	ra,8000346a <filealloc>
    800037fa:	e088                	sd	a0,0(s1)
    800037fc:	cd35                	beqz	a0,80003878 <pipealloc+0x9e>
    800037fe:	c6dff0ef          	jal	ra,8000346a <filealloc>
    80003802:	00aa3023          	sd	a0,0(s4)
    80003806:	c52d                	beqz	a0,80003870 <pipealloc+0x96>
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    80003808:	8f5fc0ef          	jal	ra,800000fc <kalloc>
    8000380c:	892a                	mv	s2,a0
    8000380e:	cd31                	beqz	a0,8000386a <pipealloc+0x90>
    goto bad;
  pi->readopen = 1;
    80003810:	4985                	li	s3,1
    80003812:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80003816:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    8000381a:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    8000381e:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80003822:	00004597          	auipc	a1,0x4
    80003826:	f1e58593          	addi	a1,a1,-226 # 80007740 <syscalls+0x2e8>
    8000382a:	761010ef          	jal	ra,8000578a <initlock>
  (*f0)->type = FD_PIPE;
    8000382e:	609c                	ld	a5,0(s1)
    80003830:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80003834:	609c                	ld	a5,0(s1)
    80003836:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    8000383a:	609c                	ld	a5,0(s1)
    8000383c:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80003840:	609c                	ld	a5,0(s1)
    80003842:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80003846:	000a3783          	ld	a5,0(s4)
    8000384a:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    8000384e:	000a3783          	ld	a5,0(s4)
    80003852:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80003856:	000a3783          	ld	a5,0(s4)
    8000385a:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    8000385e:	000a3783          	ld	a5,0(s4)
    80003862:	0127b823          	sd	s2,16(a5)
  return 0;
    80003866:	4501                	li	a0,0
    80003868:	a005                	j	80003888 <pipealloc+0xae>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    8000386a:	6088                	ld	a0,0(s1)
    8000386c:	e501                	bnez	a0,80003874 <pipealloc+0x9a>
    8000386e:	a029                	j	80003878 <pipealloc+0x9e>
    80003870:	6088                	ld	a0,0(s1)
    80003872:	c11d                	beqz	a0,80003898 <pipealloc+0xbe>
    fileclose(*f0);
    80003874:	c9bff0ef          	jal	ra,8000350e <fileclose>
  if(*f1)
    80003878:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    8000387c:	557d                	li	a0,-1
  if(*f1)
    8000387e:	c789                	beqz	a5,80003888 <pipealloc+0xae>
    fileclose(*f1);
    80003880:	853e                	mv	a0,a5
    80003882:	c8dff0ef          	jal	ra,8000350e <fileclose>
  return -1;
    80003886:	557d                	li	a0,-1
}
    80003888:	70a2                	ld	ra,40(sp)
    8000388a:	7402                	ld	s0,32(sp)
    8000388c:	64e2                	ld	s1,24(sp)
    8000388e:	6942                	ld	s2,16(sp)
    80003890:	69a2                	ld	s3,8(sp)
    80003892:	6a02                	ld	s4,0(sp)
    80003894:	6145                	addi	sp,sp,48
    80003896:	8082                	ret
  return -1;
    80003898:	557d                	li	a0,-1
    8000389a:	b7fd                	j	80003888 <pipealloc+0xae>

000000008000389c <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    8000389c:	1101                	addi	sp,sp,-32
    8000389e:	ec06                	sd	ra,24(sp)
    800038a0:	e822                	sd	s0,16(sp)
    800038a2:	e426                	sd	s1,8(sp)
    800038a4:	e04a                	sd	s2,0(sp)
    800038a6:	1000                	addi	s0,sp,32
    800038a8:	84aa                	mv	s1,a0
    800038aa:	892e                	mv	s2,a1
  acquire(&pi->lock);
    800038ac:	75f010ef          	jal	ra,8000580a <acquire>
  if(writable){
    800038b0:	02090763          	beqz	s2,800038de <pipeclose+0x42>
    pi->writeopen = 0;
    800038b4:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    800038b8:	21848513          	addi	a0,s1,536
    800038bc:	be9fd0ef          	jal	ra,800014a4 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    800038c0:	2204b783          	ld	a5,544(s1)
    800038c4:	e785                	bnez	a5,800038ec <pipeclose+0x50>
    release(&pi->lock);
    800038c6:	8526                	mv	a0,s1
    800038c8:	7db010ef          	jal	ra,800058a2 <release>
    kfree((char*)pi);
    800038cc:	8526                	mv	a0,s1
    800038ce:	f4efc0ef          	jal	ra,8000001c <kfree>
  } else
    release(&pi->lock);
}
    800038d2:	60e2                	ld	ra,24(sp)
    800038d4:	6442                	ld	s0,16(sp)
    800038d6:	64a2                	ld	s1,8(sp)
    800038d8:	6902                	ld	s2,0(sp)
    800038da:	6105                	addi	sp,sp,32
    800038dc:	8082                	ret
    pi->readopen = 0;
    800038de:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    800038e2:	21c48513          	addi	a0,s1,540
    800038e6:	bbffd0ef          	jal	ra,800014a4 <wakeup>
    800038ea:	bfd9                	j	800038c0 <pipeclose+0x24>
    release(&pi->lock);
    800038ec:	8526                	mv	a0,s1
    800038ee:	7b5010ef          	jal	ra,800058a2 <release>
}
    800038f2:	b7c5                	j	800038d2 <pipeclose+0x36>

00000000800038f4 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800038f4:	711d                	addi	sp,sp,-96
    800038f6:	ec86                	sd	ra,88(sp)
    800038f8:	e8a2                	sd	s0,80(sp)
    800038fa:	e4a6                	sd	s1,72(sp)
    800038fc:	e0ca                	sd	s2,64(sp)
    800038fe:	fc4e                	sd	s3,56(sp)
    80003900:	f852                	sd	s4,48(sp)
    80003902:	f456                	sd	s5,40(sp)
    80003904:	f05a                	sd	s6,32(sp)
    80003906:	ec5e                	sd	s7,24(sp)
    80003908:	e862                	sd	s8,16(sp)
    8000390a:	1080                	addi	s0,sp,96
    8000390c:	84aa                	mv	s1,a0
    8000390e:	8aae                	mv	s5,a1
    80003910:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80003912:	cf0fd0ef          	jal	ra,80000e02 <myproc>
    80003916:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80003918:	8526                	mv	a0,s1
    8000391a:	6f1010ef          	jal	ra,8000580a <acquire>
  while(i < n){
    8000391e:	09405c63          	blez	s4,800039b6 <pipewrite+0xc2>
  int i = 0;
    80003922:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80003924:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80003926:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    8000392a:	21c48b93          	addi	s7,s1,540
    8000392e:	a81d                	j	80003964 <pipewrite+0x70>
      release(&pi->lock);
    80003930:	8526                	mv	a0,s1
    80003932:	771010ef          	jal	ra,800058a2 <release>
      return -1;
    80003936:	597d                	li	s2,-1
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80003938:	854a                	mv	a0,s2
    8000393a:	60e6                	ld	ra,88(sp)
    8000393c:	6446                	ld	s0,80(sp)
    8000393e:	64a6                	ld	s1,72(sp)
    80003940:	6906                	ld	s2,64(sp)
    80003942:	79e2                	ld	s3,56(sp)
    80003944:	7a42                	ld	s4,48(sp)
    80003946:	7aa2                	ld	s5,40(sp)
    80003948:	7b02                	ld	s6,32(sp)
    8000394a:	6be2                	ld	s7,24(sp)
    8000394c:	6c42                	ld	s8,16(sp)
    8000394e:	6125                	addi	sp,sp,96
    80003950:	8082                	ret
      wakeup(&pi->nread);
    80003952:	8562                	mv	a0,s8
    80003954:	b51fd0ef          	jal	ra,800014a4 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80003958:	85a6                	mv	a1,s1
    8000395a:	855e                	mv	a0,s7
    8000395c:	afdfd0ef          	jal	ra,80001458 <sleep>
  while(i < n){
    80003960:	05495c63          	bge	s2,s4,800039b8 <pipewrite+0xc4>
    if(pi->readopen == 0 || killed(pr)){
    80003964:	2204a783          	lw	a5,544(s1)
    80003968:	d7e1                	beqz	a5,80003930 <pipewrite+0x3c>
    8000396a:	854e                	mv	a0,s3
    8000396c:	d25fd0ef          	jal	ra,80001690 <killed>
    80003970:	f161                	bnez	a0,80003930 <pipewrite+0x3c>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80003972:	2184a783          	lw	a5,536(s1)
    80003976:	21c4a703          	lw	a4,540(s1)
    8000397a:	2007879b          	addiw	a5,a5,512
    8000397e:	fcf70ae3          	beq	a4,a5,80003952 <pipewrite+0x5e>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80003982:	4685                	li	a3,1
    80003984:	01590633          	add	a2,s2,s5
    80003988:	faf40593          	addi	a1,s0,-81
    8000398c:	0589b503          	ld	a0,88(s3)
    80003990:	9a0fd0ef          	jal	ra,80000b30 <copyin>
    80003994:	03650263          	beq	a0,s6,800039b8 <pipewrite+0xc4>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80003998:	21c4a783          	lw	a5,540(s1)
    8000399c:	0017871b          	addiw	a4,a5,1
    800039a0:	20e4ae23          	sw	a4,540(s1)
    800039a4:	1ff7f793          	andi	a5,a5,511
    800039a8:	97a6                	add	a5,a5,s1
    800039aa:	faf44703          	lbu	a4,-81(s0)
    800039ae:	00e78c23          	sb	a4,24(a5)
      i++;
    800039b2:	2905                	addiw	s2,s2,1
    800039b4:	b775                	j	80003960 <pipewrite+0x6c>
  int i = 0;
    800039b6:	4901                	li	s2,0
  wakeup(&pi->nread);
    800039b8:	21848513          	addi	a0,s1,536
    800039bc:	ae9fd0ef          	jal	ra,800014a4 <wakeup>
  release(&pi->lock);
    800039c0:	8526                	mv	a0,s1
    800039c2:	6e1010ef          	jal	ra,800058a2 <release>
  return i;
    800039c6:	bf8d                	j	80003938 <pipewrite+0x44>

00000000800039c8 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800039c8:	715d                	addi	sp,sp,-80
    800039ca:	e486                	sd	ra,72(sp)
    800039cc:	e0a2                	sd	s0,64(sp)
    800039ce:	fc26                	sd	s1,56(sp)
    800039d0:	f84a                	sd	s2,48(sp)
    800039d2:	f44e                	sd	s3,40(sp)
    800039d4:	f052                	sd	s4,32(sp)
    800039d6:	ec56                	sd	s5,24(sp)
    800039d8:	e85a                	sd	s6,16(sp)
    800039da:	0880                	addi	s0,sp,80
    800039dc:	84aa                	mv	s1,a0
    800039de:	892e                	mv	s2,a1
    800039e0:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    800039e2:	c20fd0ef          	jal	ra,80000e02 <myproc>
    800039e6:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    800039e8:	8526                	mv	a0,s1
    800039ea:	621010ef          	jal	ra,8000580a <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800039ee:	2184a703          	lw	a4,536(s1)
    800039f2:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800039f6:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800039fa:	02f71363          	bne	a4,a5,80003a20 <piperead+0x58>
    800039fe:	2244a783          	lw	a5,548(s1)
    80003a02:	cf99                	beqz	a5,80003a20 <piperead+0x58>
    if(killed(pr)){
    80003a04:	8552                	mv	a0,s4
    80003a06:	c8bfd0ef          	jal	ra,80001690 <killed>
    80003a0a:	e141                	bnez	a0,80003a8a <piperead+0xc2>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80003a0c:	85a6                	mv	a1,s1
    80003a0e:	854e                	mv	a0,s3
    80003a10:	a49fd0ef          	jal	ra,80001458 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003a14:	2184a703          	lw	a4,536(s1)
    80003a18:	21c4a783          	lw	a5,540(s1)
    80003a1c:	fef701e3          	beq	a4,a5,800039fe <piperead+0x36>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003a20:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003a22:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003a24:	05505163          	blez	s5,80003a66 <piperead+0x9e>
    if(pi->nread == pi->nwrite)
    80003a28:	2184a783          	lw	a5,536(s1)
    80003a2c:	21c4a703          	lw	a4,540(s1)
    80003a30:	02f70b63          	beq	a4,a5,80003a66 <piperead+0x9e>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80003a34:	0017871b          	addiw	a4,a5,1
    80003a38:	20e4ac23          	sw	a4,536(s1)
    80003a3c:	1ff7f793          	andi	a5,a5,511
    80003a40:	97a6                	add	a5,a5,s1
    80003a42:	0187c783          	lbu	a5,24(a5)
    80003a46:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003a4a:	4685                	li	a3,1
    80003a4c:	fbf40613          	addi	a2,s0,-65
    80003a50:	85ca                	mv	a1,s2
    80003a52:	058a3503          	ld	a0,88(s4)
    80003a56:	822fd0ef          	jal	ra,80000a78 <copyout>
    80003a5a:	01650663          	beq	a0,s6,80003a66 <piperead+0x9e>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003a5e:	2985                	addiw	s3,s3,1
    80003a60:	0905                	addi	s2,s2,1
    80003a62:	fd3a93e3          	bne	s5,s3,80003a28 <piperead+0x60>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80003a66:	21c48513          	addi	a0,s1,540
    80003a6a:	a3bfd0ef          	jal	ra,800014a4 <wakeup>
  release(&pi->lock);
    80003a6e:	8526                	mv	a0,s1
    80003a70:	633010ef          	jal	ra,800058a2 <release>
  return i;
}
    80003a74:	854e                	mv	a0,s3
    80003a76:	60a6                	ld	ra,72(sp)
    80003a78:	6406                	ld	s0,64(sp)
    80003a7a:	74e2                	ld	s1,56(sp)
    80003a7c:	7942                	ld	s2,48(sp)
    80003a7e:	79a2                	ld	s3,40(sp)
    80003a80:	7a02                	ld	s4,32(sp)
    80003a82:	6ae2                	ld	s5,24(sp)
    80003a84:	6b42                	ld	s6,16(sp)
    80003a86:	6161                	addi	sp,sp,80
    80003a88:	8082                	ret
      release(&pi->lock);
    80003a8a:	8526                	mv	a0,s1
    80003a8c:	617010ef          	jal	ra,800058a2 <release>
      return -1;
    80003a90:	59fd                	li	s3,-1
    80003a92:	b7cd                	j	80003a74 <piperead+0xac>

0000000080003a94 <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80003a94:	1141                	addi	sp,sp,-16
    80003a96:	e422                	sd	s0,8(sp)
    80003a98:	0800                	addi	s0,sp,16
    80003a9a:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80003a9c:	8905                	andi	a0,a0,1
    80003a9e:	c111                	beqz	a0,80003aa2 <flags2perm+0xe>
      perm = PTE_X;
    80003aa0:	4521                	li	a0,8
    if(flags & 0x2)
    80003aa2:	8b89                	andi	a5,a5,2
    80003aa4:	c399                	beqz	a5,80003aaa <flags2perm+0x16>
      perm |= PTE_W;
    80003aa6:	00456513          	ori	a0,a0,4
    return perm;
}
    80003aaa:	6422                	ld	s0,8(sp)
    80003aac:	0141                	addi	sp,sp,16
    80003aae:	8082                	ret

0000000080003ab0 <exec>:

int
exec(char *path, char **argv)
{
    80003ab0:	de010113          	addi	sp,sp,-544
    80003ab4:	20113c23          	sd	ra,536(sp)
    80003ab8:	20813823          	sd	s0,528(sp)
    80003abc:	20913423          	sd	s1,520(sp)
    80003ac0:	21213023          	sd	s2,512(sp)
    80003ac4:	ffce                	sd	s3,504(sp)
    80003ac6:	fbd2                	sd	s4,496(sp)
    80003ac8:	f7d6                	sd	s5,488(sp)
    80003aca:	f3da                	sd	s6,480(sp)
    80003acc:	efde                	sd	s7,472(sp)
    80003ace:	ebe2                	sd	s8,464(sp)
    80003ad0:	e7e6                	sd	s9,456(sp)
    80003ad2:	e3ea                	sd	s10,448(sp)
    80003ad4:	ff6e                	sd	s11,440(sp)
    80003ad6:	1400                	addi	s0,sp,544
    80003ad8:	892a                	mv	s2,a0
    80003ada:	dea43423          	sd	a0,-536(s0)
    80003ade:	deb43823          	sd	a1,-528(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80003ae2:	b20fd0ef          	jal	ra,80000e02 <myproc>
    80003ae6:	84aa                	mv	s1,a0

  begin_op();
    80003ae8:	e0aff0ef          	jal	ra,800030f2 <begin_op>

  if((ip = namei(path)) == 0){
    80003aec:	854a                	mv	a0,s2
    80003aee:	c28ff0ef          	jal	ra,80002f16 <namei>
    80003af2:	c13d                	beqz	a0,80003b58 <exec+0xa8>
    80003af4:	8aaa                	mv	s5,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80003af6:	d6ffe0ef          	jal	ra,80002864 <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80003afa:	04000713          	li	a4,64
    80003afe:	4681                	li	a3,0
    80003b00:	e5040613          	addi	a2,s0,-432
    80003b04:	4581                	li	a1,0
    80003b06:	8556                	mv	a0,s5
    80003b08:	fadfe0ef          	jal	ra,80002ab4 <readi>
    80003b0c:	04000793          	li	a5,64
    80003b10:	00f51a63          	bne	a0,a5,80003b24 <exec+0x74>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80003b14:	e5042703          	lw	a4,-432(s0)
    80003b18:	464c47b7          	lui	a5,0x464c4
    80003b1c:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80003b20:	04f70063          	beq	a4,a5,80003b60 <exec+0xb0>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80003b24:	8556                	mv	a0,s5
    80003b26:	f45fe0ef          	jal	ra,80002a6a <iunlockput>
    end_op();
    80003b2a:	e38ff0ef          	jal	ra,80003162 <end_op>
  }
  return -1;
    80003b2e:	557d                	li	a0,-1
}
    80003b30:	21813083          	ld	ra,536(sp)
    80003b34:	21013403          	ld	s0,528(sp)
    80003b38:	20813483          	ld	s1,520(sp)
    80003b3c:	20013903          	ld	s2,512(sp)
    80003b40:	79fe                	ld	s3,504(sp)
    80003b42:	7a5e                	ld	s4,496(sp)
    80003b44:	7abe                	ld	s5,488(sp)
    80003b46:	7b1e                	ld	s6,480(sp)
    80003b48:	6bfe                	ld	s7,472(sp)
    80003b4a:	6c5e                	ld	s8,464(sp)
    80003b4c:	6cbe                	ld	s9,456(sp)
    80003b4e:	6d1e                	ld	s10,448(sp)
    80003b50:	7dfa                	ld	s11,440(sp)
    80003b52:	22010113          	addi	sp,sp,544
    80003b56:	8082                	ret
    end_op();
    80003b58:	e0aff0ef          	jal	ra,80003162 <end_op>
    return -1;
    80003b5c:	557d                	li	a0,-1
    80003b5e:	bfc9                	j	80003b30 <exec+0x80>
  if((pagetable = proc_pagetable(p)) == 0)
    80003b60:	8526                	mv	a0,s1
    80003b62:	b48fd0ef          	jal	ra,80000eaa <proc_pagetable>
    80003b66:	8b2a                	mv	s6,a0
    80003b68:	dd55                	beqz	a0,80003b24 <exec+0x74>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003b6a:	e7042783          	lw	a5,-400(s0)
    80003b6e:	e8845703          	lhu	a4,-376(s0)
    80003b72:	c325                	beqz	a4,80003bd2 <exec+0x122>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003b74:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003b76:	e0043423          	sd	zero,-504(s0)
    if(ph.vaddr % PGSIZE != 0)
    80003b7a:	6a05                	lui	s4,0x1
    80003b7c:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    80003b80:	dee43023          	sd	a4,-544(s0)
loadseg(pagetable_t pagetable, uint64 va, struct inode *ip, uint offset, uint sz)
{
  uint i, n;
  uint64 pa;

  for(i = 0; i < sz; i += PGSIZE){
    80003b84:	6d85                	lui	s11,0x1
    80003b86:	7d7d                	lui	s10,0xfffff
    80003b88:	ac29                	j	80003da2 <exec+0x2f2>
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    80003b8a:	00004517          	auipc	a0,0x4
    80003b8e:	bbe50513          	addi	a0,a0,-1090 # 80007748 <syscalls+0x2f0>
    80003b92:	165010ef          	jal	ra,800054f6 <panic>
    if(sz - i < PGSIZE)
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80003b96:	874a                	mv	a4,s2
    80003b98:	009c86bb          	addw	a3,s9,s1
    80003b9c:	4581                	li	a1,0
    80003b9e:	8556                	mv	a0,s5
    80003ba0:	f15fe0ef          	jal	ra,80002ab4 <readi>
    80003ba4:	2501                	sext.w	a0,a0
    80003ba6:	18a91d63          	bne	s2,a0,80003d40 <exec+0x290>
  for(i = 0; i < sz; i += PGSIZE){
    80003baa:	009d84bb          	addw	s1,s11,s1
    80003bae:	013d09bb          	addw	s3,s10,s3
    80003bb2:	1d74f863          	bgeu	s1,s7,80003d82 <exec+0x2d2>
    pa = walkaddr(pagetable, va + i);
    80003bb6:	02049593          	slli	a1,s1,0x20
    80003bba:	9181                	srli	a1,a1,0x20
    80003bbc:	95e2                	add	a1,a1,s8
    80003bbe:	855a                	mv	a0,s6
    80003bc0:	94dfc0ef          	jal	ra,8000050c <walkaddr>
    80003bc4:	862a                	mv	a2,a0
    if(pa == 0)
    80003bc6:	d171                	beqz	a0,80003b8a <exec+0xda>
      n = PGSIZE;
    80003bc8:	8952                	mv	s2,s4
    if(sz - i < PGSIZE)
    80003bca:	fd49f6e3          	bgeu	s3,s4,80003b96 <exec+0xe6>
      n = sz - i;
    80003bce:	894e                	mv	s2,s3
    80003bd0:	b7d9                	j	80003b96 <exec+0xe6>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003bd2:	4901                	li	s2,0
  iunlockput(ip);
    80003bd4:	8556                	mv	a0,s5
    80003bd6:	e95fe0ef          	jal	ra,80002a6a <iunlockput>
  end_op();
    80003bda:	d88ff0ef          	jal	ra,80003162 <end_op>
  p = myproc();
    80003bde:	a24fd0ef          	jal	ra,80000e02 <myproc>
    80003be2:	8baa                	mv	s7,a0
  uint64 oldsz = p->sz;
    80003be4:	05053d03          	ld	s10,80(a0)
  sz = PGROUNDUP(sz);
    80003be8:	6785                	lui	a5,0x1
    80003bea:	17fd                	addi	a5,a5,-1
    80003bec:	993e                	add	s2,s2,a5
    80003bee:	77fd                	lui	a5,0xfffff
    80003bf0:	00f977b3          	and	a5,s2,a5
    80003bf4:	def43c23          	sd	a5,-520(s0)
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80003bf8:	4691                	li	a3,4
    80003bfa:	6609                	lui	a2,0x2
    80003bfc:	963e                	add	a2,a2,a5
    80003bfe:	85be                	mv	a1,a5
    80003c00:	855a                	mv	a0,s6
    80003c02:	c73fc0ef          	jal	ra,80000874 <uvmalloc>
    80003c06:	8c2a                	mv	s8,a0
  ip = 0;
    80003c08:	4a81                	li	s5,0
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80003c0a:	12050b63          	beqz	a0,80003d40 <exec+0x290>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80003c0e:	75f9                	lui	a1,0xffffe
    80003c10:	95aa                	add	a1,a1,a0
    80003c12:	855a                	mv	a0,s6
    80003c14:	e3bfc0ef          	jal	ra,80000a4e <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80003c18:	7afd                	lui	s5,0xfffff
    80003c1a:	9ae2                	add	s5,s5,s8
  for(argc = 0; argv[argc]; argc++) {
    80003c1c:	df043783          	ld	a5,-528(s0)
    80003c20:	6388                	ld	a0,0(a5)
    80003c22:	c135                	beqz	a0,80003c86 <exec+0x1d6>
    80003c24:	e9040993          	addi	s3,s0,-368
    80003c28:	f9040c93          	addi	s9,s0,-112
  sp = sz;
    80003c2c:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80003c2e:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80003c30:	e94fc0ef          	jal	ra,800002c4 <strlen>
    80003c34:	0015079b          	addiw	a5,a0,1
    80003c38:	40f90933          	sub	s2,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80003c3c:	ff097913          	andi	s2,s2,-16
    if(sp < stackbase)
    80003c40:	13596563          	bltu	s2,s5,80003d6a <exec+0x2ba>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80003c44:	df043d83          	ld	s11,-528(s0)
    80003c48:	000dba03          	ld	s4,0(s11) # 1000 <_entry-0x7ffff000>
    80003c4c:	8552                	mv	a0,s4
    80003c4e:	e76fc0ef          	jal	ra,800002c4 <strlen>
    80003c52:	0015069b          	addiw	a3,a0,1
    80003c56:	8652                	mv	a2,s4
    80003c58:	85ca                	mv	a1,s2
    80003c5a:	855a                	mv	a0,s6
    80003c5c:	e1dfc0ef          	jal	ra,80000a78 <copyout>
    80003c60:	10054963          	bltz	a0,80003d72 <exec+0x2c2>
    ustack[argc] = sp;
    80003c64:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    80003c68:	0485                	addi	s1,s1,1
    80003c6a:	008d8793          	addi	a5,s11,8
    80003c6e:	def43823          	sd	a5,-528(s0)
    80003c72:	008db503          	ld	a0,8(s11)
    80003c76:	c911                	beqz	a0,80003c8a <exec+0x1da>
    if(argc >= MAXARG)
    80003c78:	09a1                	addi	s3,s3,8
    80003c7a:	fb3c9be3          	bne	s9,s3,80003c30 <exec+0x180>
  sz = sz1;
    80003c7e:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80003c82:	4a81                	li	s5,0
    80003c84:	a875                	j	80003d40 <exec+0x290>
  sp = sz;
    80003c86:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80003c88:	4481                	li	s1,0
  ustack[argc] = 0;
    80003c8a:	00349793          	slli	a5,s1,0x3
    80003c8e:	f9040713          	addi	a4,s0,-112
    80003c92:	97ba                	add	a5,a5,a4
    80003c94:	f007b023          	sd	zero,-256(a5) # ffffffffffffef00 <end+0xffffffff7ffde020>
  sp -= (argc+1) * sizeof(uint64);
    80003c98:	00148693          	addi	a3,s1,1
    80003c9c:	068e                	slli	a3,a3,0x3
    80003c9e:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80003ca2:	ff097913          	andi	s2,s2,-16
  if(sp < stackbase)
    80003ca6:	01597663          	bgeu	s2,s5,80003cb2 <exec+0x202>
  sz = sz1;
    80003caa:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80003cae:	4a81                	li	s5,0
    80003cb0:	a841                	j	80003d40 <exec+0x290>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80003cb2:	e9040613          	addi	a2,s0,-368
    80003cb6:	85ca                	mv	a1,s2
    80003cb8:	855a                	mv	a0,s6
    80003cba:	dbffc0ef          	jal	ra,80000a78 <copyout>
    80003cbe:	0a054e63          	bltz	a0,80003d7a <exec+0x2ca>
  p->trapframe->a1 = sp;
    80003cc2:	060bb783          	ld	a5,96(s7) # 1060 <_entry-0x7fffefa0>
    80003cc6:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80003cca:	de843783          	ld	a5,-536(s0)
    80003cce:	0007c703          	lbu	a4,0(a5)
    80003cd2:	cf11                	beqz	a4,80003cee <exec+0x23e>
    80003cd4:	0785                	addi	a5,a5,1
    if(*s == '/')
    80003cd6:	02f00693          	li	a3,47
    80003cda:	a039                	j	80003ce8 <exec+0x238>
      last = s+1;
    80003cdc:	def43423          	sd	a5,-536(s0)
  for(last=s=path; *s; s++)
    80003ce0:	0785                	addi	a5,a5,1
    80003ce2:	fff7c703          	lbu	a4,-1(a5)
    80003ce6:	c701                	beqz	a4,80003cee <exec+0x23e>
    if(*s == '/')
    80003ce8:	fed71ce3          	bne	a4,a3,80003ce0 <exec+0x230>
    80003cec:	bfc5                	j	80003cdc <exec+0x22c>
  safestrcpy(p->name, last, sizeof(p->name));
    80003cee:	4641                	li	a2,16
    80003cf0:	de843583          	ld	a1,-536(s0)
    80003cf4:	160b8513          	addi	a0,s7,352
    80003cf8:	d9afc0ef          	jal	ra,80000292 <safestrcpy>
  oldpagetable = p->pagetable;
    80003cfc:	058bb983          	ld	s3,88(s7)
  p->pagetable = pagetable;
    80003d00:	056bbc23          	sd	s6,88(s7)
  p->sz = sz;
    80003d04:	058bb823          	sd	s8,80(s7)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80003d08:	060bb783          	ld	a5,96(s7)
    80003d0c:	e6843703          	ld	a4,-408(s0)
    80003d10:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80003d12:	060bb783          	ld	a5,96(s7)
    80003d16:	0327b823          	sd	s2,48(a5)
  if(p->pid == 1)   // init process only // pgtbl lab q1
    80003d1a:	030ba703          	lw	a4,48(s7)
    80003d1e:	4785                	li	a5,1
    80003d20:	00f70963          	beq	a4,a5,80003d32 <exec+0x282>
  proc_freepagetable(oldpagetable, oldsz);
    80003d24:	85ea                	mv	a1,s10
    80003d26:	854e                	mv	a0,s3
    80003d28:	a06fd0ef          	jal	ra,80000f2e <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80003d2c:	0004851b          	sext.w	a0,s1
    80003d30:	b501                	j	80003b30 <exec+0x80>
    vmprint(p->pagetable);
    80003d32:	058bb503          	ld	a0,88(s7)
    80003d36:	f31fc0ef          	jal	ra,80000c66 <vmprint>
    80003d3a:	b7ed                	j	80003d24 <exec+0x274>
    80003d3c:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80003d40:	df843583          	ld	a1,-520(s0)
    80003d44:	855a                	mv	a0,s6
    80003d46:	9e8fd0ef          	jal	ra,80000f2e <proc_freepagetable>
  if(ip){
    80003d4a:	dc0a9de3          	bnez	s5,80003b24 <exec+0x74>
  return -1;
    80003d4e:	557d                	li	a0,-1
    80003d50:	b3c5                	j	80003b30 <exec+0x80>
    80003d52:	df243c23          	sd	s2,-520(s0)
    80003d56:	b7ed                	j	80003d40 <exec+0x290>
    80003d58:	df243c23          	sd	s2,-520(s0)
    80003d5c:	b7d5                	j	80003d40 <exec+0x290>
    80003d5e:	df243c23          	sd	s2,-520(s0)
    80003d62:	bff9                	j	80003d40 <exec+0x290>
    80003d64:	df243c23          	sd	s2,-520(s0)
    80003d68:	bfe1                	j	80003d40 <exec+0x290>
  sz = sz1;
    80003d6a:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80003d6e:	4a81                	li	s5,0
    80003d70:	bfc1                	j	80003d40 <exec+0x290>
  sz = sz1;
    80003d72:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80003d76:	4a81                	li	s5,0
    80003d78:	b7e1                	j	80003d40 <exec+0x290>
  sz = sz1;
    80003d7a:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80003d7e:	4a81                	li	s5,0
    80003d80:	b7c1                	j	80003d40 <exec+0x290>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80003d82:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003d86:	e0843783          	ld	a5,-504(s0)
    80003d8a:	0017869b          	addiw	a3,a5,1
    80003d8e:	e0d43423          	sd	a3,-504(s0)
    80003d92:	e0043783          	ld	a5,-512(s0)
    80003d96:	0387879b          	addiw	a5,a5,56
    80003d9a:	e8845703          	lhu	a4,-376(s0)
    80003d9e:	e2e6dbe3          	bge	a3,a4,80003bd4 <exec+0x124>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003da2:	2781                	sext.w	a5,a5
    80003da4:	e0f43023          	sd	a5,-512(s0)
    80003da8:	03800713          	li	a4,56
    80003dac:	86be                	mv	a3,a5
    80003dae:	e1840613          	addi	a2,s0,-488
    80003db2:	4581                	li	a1,0
    80003db4:	8556                	mv	a0,s5
    80003db6:	cfffe0ef          	jal	ra,80002ab4 <readi>
    80003dba:	03800793          	li	a5,56
    80003dbe:	f6f51fe3          	bne	a0,a5,80003d3c <exec+0x28c>
    if(ph.type != ELF_PROG_LOAD)
    80003dc2:	e1842783          	lw	a5,-488(s0)
    80003dc6:	4705                	li	a4,1
    80003dc8:	fae79fe3          	bne	a5,a4,80003d86 <exec+0x2d6>
    if(ph.memsz < ph.filesz)
    80003dcc:	e4043483          	ld	s1,-448(s0)
    80003dd0:	e3843783          	ld	a5,-456(s0)
    80003dd4:	f6f4efe3          	bltu	s1,a5,80003d52 <exec+0x2a2>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80003dd8:	e2843783          	ld	a5,-472(s0)
    80003ddc:	94be                	add	s1,s1,a5
    80003dde:	f6f4ede3          	bltu	s1,a5,80003d58 <exec+0x2a8>
    if(ph.vaddr % PGSIZE != 0)
    80003de2:	de043703          	ld	a4,-544(s0)
    80003de6:	8ff9                	and	a5,a5,a4
    80003de8:	fbbd                	bnez	a5,80003d5e <exec+0x2ae>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80003dea:	e1c42503          	lw	a0,-484(s0)
    80003dee:	ca7ff0ef          	jal	ra,80003a94 <flags2perm>
    80003df2:	86aa                	mv	a3,a0
    80003df4:	8626                	mv	a2,s1
    80003df6:	85ca                	mv	a1,s2
    80003df8:	855a                	mv	a0,s6
    80003dfa:	a7bfc0ef          	jal	ra,80000874 <uvmalloc>
    80003dfe:	dea43c23          	sd	a0,-520(s0)
    80003e02:	d12d                	beqz	a0,80003d64 <exec+0x2b4>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003e04:	e2843c03          	ld	s8,-472(s0)
    80003e08:	e2042c83          	lw	s9,-480(s0)
    80003e0c:	e3842b83          	lw	s7,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003e10:	f60b89e3          	beqz	s7,80003d82 <exec+0x2d2>
    80003e14:	89de                	mv	s3,s7
    80003e16:	4481                	li	s1,0
    80003e18:	bb79                	j	80003bb6 <exec+0x106>

0000000080003e1a <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80003e1a:	7179                	addi	sp,sp,-48
    80003e1c:	f406                	sd	ra,40(sp)
    80003e1e:	f022                	sd	s0,32(sp)
    80003e20:	ec26                	sd	s1,24(sp)
    80003e22:	e84a                	sd	s2,16(sp)
    80003e24:	1800                	addi	s0,sp,48
    80003e26:	892e                	mv	s2,a1
    80003e28:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80003e2a:	fdc40593          	addi	a1,s0,-36
    80003e2e:	f0dfd0ef          	jal	ra,80001d3a <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80003e32:	fdc42703          	lw	a4,-36(s0)
    80003e36:	47bd                	li	a5,15
    80003e38:	02e7e963          	bltu	a5,a4,80003e6a <argfd+0x50>
    80003e3c:	fc7fc0ef          	jal	ra,80000e02 <myproc>
    80003e40:	fdc42703          	lw	a4,-36(s0)
    80003e44:	01a70793          	addi	a5,a4,26
    80003e48:	078e                	slli	a5,a5,0x3
    80003e4a:	953e                	add	a0,a0,a5
    80003e4c:	651c                	ld	a5,8(a0)
    80003e4e:	c385                	beqz	a5,80003e6e <argfd+0x54>
    return -1;
  if(pfd)
    80003e50:	00090463          	beqz	s2,80003e58 <argfd+0x3e>
    *pfd = fd;
    80003e54:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80003e58:	4501                	li	a0,0
  if(pf)
    80003e5a:	c091                	beqz	s1,80003e5e <argfd+0x44>
    *pf = f;
    80003e5c:	e09c                	sd	a5,0(s1)
}
    80003e5e:	70a2                	ld	ra,40(sp)
    80003e60:	7402                	ld	s0,32(sp)
    80003e62:	64e2                	ld	s1,24(sp)
    80003e64:	6942                	ld	s2,16(sp)
    80003e66:	6145                	addi	sp,sp,48
    80003e68:	8082                	ret
    return -1;
    80003e6a:	557d                	li	a0,-1
    80003e6c:	bfcd                	j	80003e5e <argfd+0x44>
    80003e6e:	557d                	li	a0,-1
    80003e70:	b7fd                	j	80003e5e <argfd+0x44>

0000000080003e72 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80003e72:	1101                	addi	sp,sp,-32
    80003e74:	ec06                	sd	ra,24(sp)
    80003e76:	e822                	sd	s0,16(sp)
    80003e78:	e426                	sd	s1,8(sp)
    80003e7a:	1000                	addi	s0,sp,32
    80003e7c:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80003e7e:	f85fc0ef          	jal	ra,80000e02 <myproc>
    80003e82:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80003e84:	0d850793          	addi	a5,a0,216
    80003e88:	4501                	li	a0,0
    80003e8a:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80003e8c:	6398                	ld	a4,0(a5)
    80003e8e:	cb19                	beqz	a4,80003ea4 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80003e90:	2505                	addiw	a0,a0,1
    80003e92:	07a1                	addi	a5,a5,8
    80003e94:	fed51ce3          	bne	a0,a3,80003e8c <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80003e98:	557d                	li	a0,-1
}
    80003e9a:	60e2                	ld	ra,24(sp)
    80003e9c:	6442                	ld	s0,16(sp)
    80003e9e:	64a2                	ld	s1,8(sp)
    80003ea0:	6105                	addi	sp,sp,32
    80003ea2:	8082                	ret
      p->ofile[fd] = f;
    80003ea4:	01a50793          	addi	a5,a0,26
    80003ea8:	078e                	slli	a5,a5,0x3
    80003eaa:	963e                	add	a2,a2,a5
    80003eac:	e604                	sd	s1,8(a2)
      return fd;
    80003eae:	b7f5                	j	80003e9a <fdalloc+0x28>

0000000080003eb0 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80003eb0:	715d                	addi	sp,sp,-80
    80003eb2:	e486                	sd	ra,72(sp)
    80003eb4:	e0a2                	sd	s0,64(sp)
    80003eb6:	fc26                	sd	s1,56(sp)
    80003eb8:	f84a                	sd	s2,48(sp)
    80003eba:	f44e                	sd	s3,40(sp)
    80003ebc:	f052                	sd	s4,32(sp)
    80003ebe:	ec56                	sd	s5,24(sp)
    80003ec0:	e85a                	sd	s6,16(sp)
    80003ec2:	0880                	addi	s0,sp,80
    80003ec4:	8b2e                	mv	s6,a1
    80003ec6:	89b2                	mv	s3,a2
    80003ec8:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80003eca:	fb040593          	addi	a1,s0,-80
    80003ece:	862ff0ef          	jal	ra,80002f30 <nameiparent>
    80003ed2:	84aa                	mv	s1,a0
    80003ed4:	10050b63          	beqz	a0,80003fea <create+0x13a>
    return 0;

  ilock(dp);
    80003ed8:	98dfe0ef          	jal	ra,80002864 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80003edc:	4601                	li	a2,0
    80003ede:	fb040593          	addi	a1,s0,-80
    80003ee2:	8526                	mv	a0,s1
    80003ee4:	dcdfe0ef          	jal	ra,80002cb0 <dirlookup>
    80003ee8:	8aaa                	mv	s5,a0
    80003eea:	c521                	beqz	a0,80003f32 <create+0x82>
    iunlockput(dp);
    80003eec:	8526                	mv	a0,s1
    80003eee:	b7dfe0ef          	jal	ra,80002a6a <iunlockput>
    ilock(ip);
    80003ef2:	8556                	mv	a0,s5
    80003ef4:	971fe0ef          	jal	ra,80002864 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80003ef8:	000b059b          	sext.w	a1,s6
    80003efc:	4789                	li	a5,2
    80003efe:	02f59563          	bne	a1,a5,80003f28 <create+0x78>
    80003f02:	044ad783          	lhu	a5,68(s5) # fffffffffffff044 <end+0xffffffff7ffde164>
    80003f06:	37f9                	addiw	a5,a5,-2
    80003f08:	17c2                	slli	a5,a5,0x30
    80003f0a:	93c1                	srli	a5,a5,0x30
    80003f0c:	4705                	li	a4,1
    80003f0e:	00f76d63          	bltu	a4,a5,80003f28 <create+0x78>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80003f12:	8556                	mv	a0,s5
    80003f14:	60a6                	ld	ra,72(sp)
    80003f16:	6406                	ld	s0,64(sp)
    80003f18:	74e2                	ld	s1,56(sp)
    80003f1a:	7942                	ld	s2,48(sp)
    80003f1c:	79a2                	ld	s3,40(sp)
    80003f1e:	7a02                	ld	s4,32(sp)
    80003f20:	6ae2                	ld	s5,24(sp)
    80003f22:	6b42                	ld	s6,16(sp)
    80003f24:	6161                	addi	sp,sp,80
    80003f26:	8082                	ret
    iunlockput(ip);
    80003f28:	8556                	mv	a0,s5
    80003f2a:	b41fe0ef          	jal	ra,80002a6a <iunlockput>
    return 0;
    80003f2e:	4a81                	li	s5,0
    80003f30:	b7cd                	j	80003f12 <create+0x62>
  if((ip = ialloc(dp->dev, type)) == 0){
    80003f32:	85da                	mv	a1,s6
    80003f34:	4088                	lw	a0,0(s1)
    80003f36:	fc6fe0ef          	jal	ra,800026fc <ialloc>
    80003f3a:	8a2a                	mv	s4,a0
    80003f3c:	cd1d                	beqz	a0,80003f7a <create+0xca>
  ilock(ip);
    80003f3e:	927fe0ef          	jal	ra,80002864 <ilock>
  ip->major = major;
    80003f42:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    80003f46:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    80003f4a:	4905                	li	s2,1
    80003f4c:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80003f50:	8552                	mv	a0,s4
    80003f52:	861fe0ef          	jal	ra,800027b2 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80003f56:	000b059b          	sext.w	a1,s6
    80003f5a:	03258563          	beq	a1,s2,80003f84 <create+0xd4>
  if(dirlink(dp, name, ip->inum) < 0)
    80003f5e:	004a2603          	lw	a2,4(s4)
    80003f62:	fb040593          	addi	a1,s0,-80
    80003f66:	8526                	mv	a0,s1
    80003f68:	f15fe0ef          	jal	ra,80002e7c <dirlink>
    80003f6c:	06054363          	bltz	a0,80003fd2 <create+0x122>
  iunlockput(dp);
    80003f70:	8526                	mv	a0,s1
    80003f72:	af9fe0ef          	jal	ra,80002a6a <iunlockput>
  return ip;
    80003f76:	8ad2                	mv	s5,s4
    80003f78:	bf69                	j	80003f12 <create+0x62>
    iunlockput(dp);
    80003f7a:	8526                	mv	a0,s1
    80003f7c:	aeffe0ef          	jal	ra,80002a6a <iunlockput>
    return 0;
    80003f80:	8ad2                	mv	s5,s4
    80003f82:	bf41                	j	80003f12 <create+0x62>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80003f84:	004a2603          	lw	a2,4(s4)
    80003f88:	00003597          	auipc	a1,0x3
    80003f8c:	7e058593          	addi	a1,a1,2016 # 80007768 <syscalls+0x310>
    80003f90:	8552                	mv	a0,s4
    80003f92:	eebfe0ef          	jal	ra,80002e7c <dirlink>
    80003f96:	02054e63          	bltz	a0,80003fd2 <create+0x122>
    80003f9a:	40d0                	lw	a2,4(s1)
    80003f9c:	00003597          	auipc	a1,0x3
    80003fa0:	0b458593          	addi	a1,a1,180 # 80007050 <etext+0x50>
    80003fa4:	8552                	mv	a0,s4
    80003fa6:	ed7fe0ef          	jal	ra,80002e7c <dirlink>
    80003faa:	02054463          	bltz	a0,80003fd2 <create+0x122>
  if(dirlink(dp, name, ip->inum) < 0)
    80003fae:	004a2603          	lw	a2,4(s4)
    80003fb2:	fb040593          	addi	a1,s0,-80
    80003fb6:	8526                	mv	a0,s1
    80003fb8:	ec5fe0ef          	jal	ra,80002e7c <dirlink>
    80003fbc:	00054b63          	bltz	a0,80003fd2 <create+0x122>
    dp->nlink++;  // for ".."
    80003fc0:	04a4d783          	lhu	a5,74(s1)
    80003fc4:	2785                	addiw	a5,a5,1
    80003fc6:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80003fca:	8526                	mv	a0,s1
    80003fcc:	fe6fe0ef          	jal	ra,800027b2 <iupdate>
    80003fd0:	b745                	j	80003f70 <create+0xc0>
  ip->nlink = 0;
    80003fd2:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80003fd6:	8552                	mv	a0,s4
    80003fd8:	fdafe0ef          	jal	ra,800027b2 <iupdate>
  iunlockput(ip);
    80003fdc:	8552                	mv	a0,s4
    80003fde:	a8dfe0ef          	jal	ra,80002a6a <iunlockput>
  iunlockput(dp);
    80003fe2:	8526                	mv	a0,s1
    80003fe4:	a87fe0ef          	jal	ra,80002a6a <iunlockput>
  return 0;
    80003fe8:	b72d                	j	80003f12 <create+0x62>
    return 0;
    80003fea:	8aaa                	mv	s5,a0
    80003fec:	b71d                	j	80003f12 <create+0x62>

0000000080003fee <sys_dup>:
{
    80003fee:	7179                	addi	sp,sp,-48
    80003ff0:	f406                	sd	ra,40(sp)
    80003ff2:	f022                	sd	s0,32(sp)
    80003ff4:	ec26                	sd	s1,24(sp)
    80003ff6:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80003ff8:	fd840613          	addi	a2,s0,-40
    80003ffc:	4581                	li	a1,0
    80003ffe:	4501                	li	a0,0
    80004000:	e1bff0ef          	jal	ra,80003e1a <argfd>
    return -1;
    80004004:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004006:	00054f63          	bltz	a0,80004024 <sys_dup+0x36>
  if((fd=fdalloc(f)) < 0)
    8000400a:	fd843503          	ld	a0,-40(s0)
    8000400e:	e65ff0ef          	jal	ra,80003e72 <fdalloc>
    80004012:	84aa                	mv	s1,a0
    return -1;
    80004014:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004016:	00054763          	bltz	a0,80004024 <sys_dup+0x36>
  filedup(f);
    8000401a:	fd843503          	ld	a0,-40(s0)
    8000401e:	caaff0ef          	jal	ra,800034c8 <filedup>
  return fd;
    80004022:	87a6                	mv	a5,s1
}
    80004024:	853e                	mv	a0,a5
    80004026:	70a2                	ld	ra,40(sp)
    80004028:	7402                	ld	s0,32(sp)
    8000402a:	64e2                	ld	s1,24(sp)
    8000402c:	6145                	addi	sp,sp,48
    8000402e:	8082                	ret

0000000080004030 <sys_read>:
{
    80004030:	7179                	addi	sp,sp,-48
    80004032:	f406                	sd	ra,40(sp)
    80004034:	f022                	sd	s0,32(sp)
    80004036:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004038:	fd840593          	addi	a1,s0,-40
    8000403c:	4505                	li	a0,1
    8000403e:	d19fd0ef          	jal	ra,80001d56 <argaddr>
  argint(2, &n);
    80004042:	fe440593          	addi	a1,s0,-28
    80004046:	4509                	li	a0,2
    80004048:	cf3fd0ef          	jal	ra,80001d3a <argint>
  if(argfd(0, 0, &f) < 0)
    8000404c:	fe840613          	addi	a2,s0,-24
    80004050:	4581                	li	a1,0
    80004052:	4501                	li	a0,0
    80004054:	dc7ff0ef          	jal	ra,80003e1a <argfd>
    80004058:	87aa                	mv	a5,a0
    return -1;
    8000405a:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000405c:	0007ca63          	bltz	a5,80004070 <sys_read+0x40>
  return fileread(f, p, n);
    80004060:	fe442603          	lw	a2,-28(s0)
    80004064:	fd843583          	ld	a1,-40(s0)
    80004068:	fe843503          	ld	a0,-24(s0)
    8000406c:	da8ff0ef          	jal	ra,80003614 <fileread>
}
    80004070:	70a2                	ld	ra,40(sp)
    80004072:	7402                	ld	s0,32(sp)
    80004074:	6145                	addi	sp,sp,48
    80004076:	8082                	ret

0000000080004078 <sys_write>:
{
    80004078:	7179                	addi	sp,sp,-48
    8000407a:	f406                	sd	ra,40(sp)
    8000407c:	f022                	sd	s0,32(sp)
    8000407e:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004080:	fd840593          	addi	a1,s0,-40
    80004084:	4505                	li	a0,1
    80004086:	cd1fd0ef          	jal	ra,80001d56 <argaddr>
  argint(2, &n);
    8000408a:	fe440593          	addi	a1,s0,-28
    8000408e:	4509                	li	a0,2
    80004090:	cabfd0ef          	jal	ra,80001d3a <argint>
  if(argfd(0, 0, &f) < 0)
    80004094:	fe840613          	addi	a2,s0,-24
    80004098:	4581                	li	a1,0
    8000409a:	4501                	li	a0,0
    8000409c:	d7fff0ef          	jal	ra,80003e1a <argfd>
    800040a0:	87aa                	mv	a5,a0
    return -1;
    800040a2:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800040a4:	0007ca63          	bltz	a5,800040b8 <sys_write+0x40>
  return filewrite(f, p, n);
    800040a8:	fe442603          	lw	a2,-28(s0)
    800040ac:	fd843583          	ld	a1,-40(s0)
    800040b0:	fe843503          	ld	a0,-24(s0)
    800040b4:	e0eff0ef          	jal	ra,800036c2 <filewrite>
}
    800040b8:	70a2                	ld	ra,40(sp)
    800040ba:	7402                	ld	s0,32(sp)
    800040bc:	6145                	addi	sp,sp,48
    800040be:	8082                	ret

00000000800040c0 <sys_close>:
{
    800040c0:	1101                	addi	sp,sp,-32
    800040c2:	ec06                	sd	ra,24(sp)
    800040c4:	e822                	sd	s0,16(sp)
    800040c6:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    800040c8:	fe040613          	addi	a2,s0,-32
    800040cc:	fec40593          	addi	a1,s0,-20
    800040d0:	4501                	li	a0,0
    800040d2:	d49ff0ef          	jal	ra,80003e1a <argfd>
    return -1;
    800040d6:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    800040d8:	02054063          	bltz	a0,800040f8 <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    800040dc:	d27fc0ef          	jal	ra,80000e02 <myproc>
    800040e0:	fec42783          	lw	a5,-20(s0)
    800040e4:	07e9                	addi	a5,a5,26
    800040e6:	078e                	slli	a5,a5,0x3
    800040e8:	97aa                	add	a5,a5,a0
    800040ea:	0007b423          	sd	zero,8(a5)
  fileclose(f);
    800040ee:	fe043503          	ld	a0,-32(s0)
    800040f2:	c1cff0ef          	jal	ra,8000350e <fileclose>
  return 0;
    800040f6:	4781                	li	a5,0
}
    800040f8:	853e                	mv	a0,a5
    800040fa:	60e2                	ld	ra,24(sp)
    800040fc:	6442                	ld	s0,16(sp)
    800040fe:	6105                	addi	sp,sp,32
    80004100:	8082                	ret

0000000080004102 <sys_fstat>:
{
    80004102:	1101                	addi	sp,sp,-32
    80004104:	ec06                	sd	ra,24(sp)
    80004106:	e822                	sd	s0,16(sp)
    80004108:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    8000410a:	fe040593          	addi	a1,s0,-32
    8000410e:	4505                	li	a0,1
    80004110:	c47fd0ef          	jal	ra,80001d56 <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004114:	fe840613          	addi	a2,s0,-24
    80004118:	4581                	li	a1,0
    8000411a:	4501                	li	a0,0
    8000411c:	cffff0ef          	jal	ra,80003e1a <argfd>
    80004120:	87aa                	mv	a5,a0
    return -1;
    80004122:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004124:	0007c863          	bltz	a5,80004134 <sys_fstat+0x32>
  return filestat(f, st);
    80004128:	fe043583          	ld	a1,-32(s0)
    8000412c:	fe843503          	ld	a0,-24(s0)
    80004130:	c86ff0ef          	jal	ra,800035b6 <filestat>
}
    80004134:	60e2                	ld	ra,24(sp)
    80004136:	6442                	ld	s0,16(sp)
    80004138:	6105                	addi	sp,sp,32
    8000413a:	8082                	ret

000000008000413c <sys_link>:
{
    8000413c:	7169                	addi	sp,sp,-304
    8000413e:	f606                	sd	ra,296(sp)
    80004140:	f222                	sd	s0,288(sp)
    80004142:	ee26                	sd	s1,280(sp)
    80004144:	ea4a                	sd	s2,272(sp)
    80004146:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004148:	08000613          	li	a2,128
    8000414c:	ed040593          	addi	a1,s0,-304
    80004150:	4501                	li	a0,0
    80004152:	c21fd0ef          	jal	ra,80001d72 <argstr>
    return -1;
    80004156:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004158:	0c054663          	bltz	a0,80004224 <sys_link+0xe8>
    8000415c:	08000613          	li	a2,128
    80004160:	f5040593          	addi	a1,s0,-176
    80004164:	4505                	li	a0,1
    80004166:	c0dfd0ef          	jal	ra,80001d72 <argstr>
    return -1;
    8000416a:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000416c:	0a054c63          	bltz	a0,80004224 <sys_link+0xe8>
  begin_op();
    80004170:	f83fe0ef          	jal	ra,800030f2 <begin_op>
  if((ip = namei(old)) == 0){
    80004174:	ed040513          	addi	a0,s0,-304
    80004178:	d9ffe0ef          	jal	ra,80002f16 <namei>
    8000417c:	84aa                	mv	s1,a0
    8000417e:	c525                	beqz	a0,800041e6 <sys_link+0xaa>
  ilock(ip);
    80004180:	ee4fe0ef          	jal	ra,80002864 <ilock>
  if(ip->type == T_DIR){
    80004184:	04449703          	lh	a4,68(s1)
    80004188:	4785                	li	a5,1
    8000418a:	06f70263          	beq	a4,a5,800041ee <sys_link+0xb2>
  ip->nlink++;
    8000418e:	04a4d783          	lhu	a5,74(s1)
    80004192:	2785                	addiw	a5,a5,1
    80004194:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004198:	8526                	mv	a0,s1
    8000419a:	e18fe0ef          	jal	ra,800027b2 <iupdate>
  iunlock(ip);
    8000419e:	8526                	mv	a0,s1
    800041a0:	f6efe0ef          	jal	ra,8000290e <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    800041a4:	fd040593          	addi	a1,s0,-48
    800041a8:	f5040513          	addi	a0,s0,-176
    800041ac:	d85fe0ef          	jal	ra,80002f30 <nameiparent>
    800041b0:	892a                	mv	s2,a0
    800041b2:	c921                	beqz	a0,80004202 <sys_link+0xc6>
  ilock(dp);
    800041b4:	eb0fe0ef          	jal	ra,80002864 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    800041b8:	00092703          	lw	a4,0(s2)
    800041bc:	409c                	lw	a5,0(s1)
    800041be:	02f71f63          	bne	a4,a5,800041fc <sys_link+0xc0>
    800041c2:	40d0                	lw	a2,4(s1)
    800041c4:	fd040593          	addi	a1,s0,-48
    800041c8:	854a                	mv	a0,s2
    800041ca:	cb3fe0ef          	jal	ra,80002e7c <dirlink>
    800041ce:	02054763          	bltz	a0,800041fc <sys_link+0xc0>
  iunlockput(dp);
    800041d2:	854a                	mv	a0,s2
    800041d4:	897fe0ef          	jal	ra,80002a6a <iunlockput>
  iput(ip);
    800041d8:	8526                	mv	a0,s1
    800041da:	809fe0ef          	jal	ra,800029e2 <iput>
  end_op();
    800041de:	f85fe0ef          	jal	ra,80003162 <end_op>
  return 0;
    800041e2:	4781                	li	a5,0
    800041e4:	a081                	j	80004224 <sys_link+0xe8>
    end_op();
    800041e6:	f7dfe0ef          	jal	ra,80003162 <end_op>
    return -1;
    800041ea:	57fd                	li	a5,-1
    800041ec:	a825                	j	80004224 <sys_link+0xe8>
    iunlockput(ip);
    800041ee:	8526                	mv	a0,s1
    800041f0:	87bfe0ef          	jal	ra,80002a6a <iunlockput>
    end_op();
    800041f4:	f6ffe0ef          	jal	ra,80003162 <end_op>
    return -1;
    800041f8:	57fd                	li	a5,-1
    800041fa:	a02d                	j	80004224 <sys_link+0xe8>
    iunlockput(dp);
    800041fc:	854a                	mv	a0,s2
    800041fe:	86dfe0ef          	jal	ra,80002a6a <iunlockput>
  ilock(ip);
    80004202:	8526                	mv	a0,s1
    80004204:	e60fe0ef          	jal	ra,80002864 <ilock>
  ip->nlink--;
    80004208:	04a4d783          	lhu	a5,74(s1)
    8000420c:	37fd                	addiw	a5,a5,-1
    8000420e:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004212:	8526                	mv	a0,s1
    80004214:	d9efe0ef          	jal	ra,800027b2 <iupdate>
  iunlockput(ip);
    80004218:	8526                	mv	a0,s1
    8000421a:	851fe0ef          	jal	ra,80002a6a <iunlockput>
  end_op();
    8000421e:	f45fe0ef          	jal	ra,80003162 <end_op>
  return -1;
    80004222:	57fd                	li	a5,-1
}
    80004224:	853e                	mv	a0,a5
    80004226:	70b2                	ld	ra,296(sp)
    80004228:	7412                	ld	s0,288(sp)
    8000422a:	64f2                	ld	s1,280(sp)
    8000422c:	6952                	ld	s2,272(sp)
    8000422e:	6155                	addi	sp,sp,304
    80004230:	8082                	ret

0000000080004232 <sys_unlink>:
{
    80004232:	7151                	addi	sp,sp,-240
    80004234:	f586                	sd	ra,232(sp)
    80004236:	f1a2                	sd	s0,224(sp)
    80004238:	eda6                	sd	s1,216(sp)
    8000423a:	e9ca                	sd	s2,208(sp)
    8000423c:	e5ce                	sd	s3,200(sp)
    8000423e:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004240:	08000613          	li	a2,128
    80004244:	f3040593          	addi	a1,s0,-208
    80004248:	4501                	li	a0,0
    8000424a:	b29fd0ef          	jal	ra,80001d72 <argstr>
    8000424e:	12054b63          	bltz	a0,80004384 <sys_unlink+0x152>
  begin_op();
    80004252:	ea1fe0ef          	jal	ra,800030f2 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004256:	fb040593          	addi	a1,s0,-80
    8000425a:	f3040513          	addi	a0,s0,-208
    8000425e:	cd3fe0ef          	jal	ra,80002f30 <nameiparent>
    80004262:	84aa                	mv	s1,a0
    80004264:	c54d                	beqz	a0,8000430e <sys_unlink+0xdc>
  ilock(dp);
    80004266:	dfefe0ef          	jal	ra,80002864 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    8000426a:	00003597          	auipc	a1,0x3
    8000426e:	4fe58593          	addi	a1,a1,1278 # 80007768 <syscalls+0x310>
    80004272:	fb040513          	addi	a0,s0,-80
    80004276:	a25fe0ef          	jal	ra,80002c9a <namecmp>
    8000427a:	10050a63          	beqz	a0,8000438e <sys_unlink+0x15c>
    8000427e:	00003597          	auipc	a1,0x3
    80004282:	dd258593          	addi	a1,a1,-558 # 80007050 <etext+0x50>
    80004286:	fb040513          	addi	a0,s0,-80
    8000428a:	a11fe0ef          	jal	ra,80002c9a <namecmp>
    8000428e:	10050063          	beqz	a0,8000438e <sys_unlink+0x15c>
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004292:	f2c40613          	addi	a2,s0,-212
    80004296:	fb040593          	addi	a1,s0,-80
    8000429a:	8526                	mv	a0,s1
    8000429c:	a15fe0ef          	jal	ra,80002cb0 <dirlookup>
    800042a0:	892a                	mv	s2,a0
    800042a2:	0e050663          	beqz	a0,8000438e <sys_unlink+0x15c>
  ilock(ip);
    800042a6:	dbefe0ef          	jal	ra,80002864 <ilock>
  if(ip->nlink < 1)
    800042aa:	04a91783          	lh	a5,74(s2)
    800042ae:	06f05463          	blez	a5,80004316 <sys_unlink+0xe4>
  if(ip->type == T_DIR && !isdirempty(ip)){
    800042b2:	04491703          	lh	a4,68(s2)
    800042b6:	4785                	li	a5,1
    800042b8:	06f70563          	beq	a4,a5,80004322 <sys_unlink+0xf0>
  memset(&de, 0, sizeof(de));
    800042bc:	4641                	li	a2,16
    800042be:	4581                	li	a1,0
    800042c0:	fc040513          	addi	a0,s0,-64
    800042c4:	e89fb0ef          	jal	ra,8000014c <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800042c8:	4741                	li	a4,16
    800042ca:	f2c42683          	lw	a3,-212(s0)
    800042ce:	fc040613          	addi	a2,s0,-64
    800042d2:	4581                	li	a1,0
    800042d4:	8526                	mv	a0,s1
    800042d6:	8c3fe0ef          	jal	ra,80002b98 <writei>
    800042da:	47c1                	li	a5,16
    800042dc:	08f51563          	bne	a0,a5,80004366 <sys_unlink+0x134>
  if(ip->type == T_DIR){
    800042e0:	04491703          	lh	a4,68(s2)
    800042e4:	4785                	li	a5,1
    800042e6:	08f70663          	beq	a4,a5,80004372 <sys_unlink+0x140>
  iunlockput(dp);
    800042ea:	8526                	mv	a0,s1
    800042ec:	f7efe0ef          	jal	ra,80002a6a <iunlockput>
  ip->nlink--;
    800042f0:	04a95783          	lhu	a5,74(s2)
    800042f4:	37fd                	addiw	a5,a5,-1
    800042f6:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    800042fa:	854a                	mv	a0,s2
    800042fc:	cb6fe0ef          	jal	ra,800027b2 <iupdate>
  iunlockput(ip);
    80004300:	854a                	mv	a0,s2
    80004302:	f68fe0ef          	jal	ra,80002a6a <iunlockput>
  end_op();
    80004306:	e5dfe0ef          	jal	ra,80003162 <end_op>
  return 0;
    8000430a:	4501                	li	a0,0
    8000430c:	a079                	j	8000439a <sys_unlink+0x168>
    end_op();
    8000430e:	e55fe0ef          	jal	ra,80003162 <end_op>
    return -1;
    80004312:	557d                	li	a0,-1
    80004314:	a059                	j	8000439a <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    80004316:	00003517          	auipc	a0,0x3
    8000431a:	45a50513          	addi	a0,a0,1114 # 80007770 <syscalls+0x318>
    8000431e:	1d8010ef          	jal	ra,800054f6 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004322:	04c92703          	lw	a4,76(s2)
    80004326:	02000793          	li	a5,32
    8000432a:	f8e7f9e3          	bgeu	a5,a4,800042bc <sys_unlink+0x8a>
    8000432e:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004332:	4741                	li	a4,16
    80004334:	86ce                	mv	a3,s3
    80004336:	f1840613          	addi	a2,s0,-232
    8000433a:	4581                	li	a1,0
    8000433c:	854a                	mv	a0,s2
    8000433e:	f76fe0ef          	jal	ra,80002ab4 <readi>
    80004342:	47c1                	li	a5,16
    80004344:	00f51b63          	bne	a0,a5,8000435a <sys_unlink+0x128>
    if(de.inum != 0)
    80004348:	f1845783          	lhu	a5,-232(s0)
    8000434c:	ef95                	bnez	a5,80004388 <sys_unlink+0x156>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000434e:	29c1                	addiw	s3,s3,16
    80004350:	04c92783          	lw	a5,76(s2)
    80004354:	fcf9efe3          	bltu	s3,a5,80004332 <sys_unlink+0x100>
    80004358:	b795                	j	800042bc <sys_unlink+0x8a>
      panic("isdirempty: readi");
    8000435a:	00003517          	auipc	a0,0x3
    8000435e:	42e50513          	addi	a0,a0,1070 # 80007788 <syscalls+0x330>
    80004362:	194010ef          	jal	ra,800054f6 <panic>
    panic("unlink: writei");
    80004366:	00003517          	auipc	a0,0x3
    8000436a:	43a50513          	addi	a0,a0,1082 # 800077a0 <syscalls+0x348>
    8000436e:	188010ef          	jal	ra,800054f6 <panic>
    dp->nlink--;
    80004372:	04a4d783          	lhu	a5,74(s1)
    80004376:	37fd                	addiw	a5,a5,-1
    80004378:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    8000437c:	8526                	mv	a0,s1
    8000437e:	c34fe0ef          	jal	ra,800027b2 <iupdate>
    80004382:	b7a5                	j	800042ea <sys_unlink+0xb8>
    return -1;
    80004384:	557d                	li	a0,-1
    80004386:	a811                	j	8000439a <sys_unlink+0x168>
    iunlockput(ip);
    80004388:	854a                	mv	a0,s2
    8000438a:	ee0fe0ef          	jal	ra,80002a6a <iunlockput>
  iunlockput(dp);
    8000438e:	8526                	mv	a0,s1
    80004390:	edafe0ef          	jal	ra,80002a6a <iunlockput>
  end_op();
    80004394:	dcffe0ef          	jal	ra,80003162 <end_op>
  return -1;
    80004398:	557d                	li	a0,-1
}
    8000439a:	70ae                	ld	ra,232(sp)
    8000439c:	740e                	ld	s0,224(sp)
    8000439e:	64ee                	ld	s1,216(sp)
    800043a0:	694e                	ld	s2,208(sp)
    800043a2:	69ae                	ld	s3,200(sp)
    800043a4:	616d                	addi	sp,sp,240
    800043a6:	8082                	ret

00000000800043a8 <sys_open>:

uint64
sys_open(void)
{
    800043a8:	7131                	addi	sp,sp,-192
    800043aa:	fd06                	sd	ra,184(sp)
    800043ac:	f922                	sd	s0,176(sp)
    800043ae:	f526                	sd	s1,168(sp)
    800043b0:	f14a                	sd	s2,160(sp)
    800043b2:	ed4e                	sd	s3,152(sp)
    800043b4:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800043b6:	f4c40593          	addi	a1,s0,-180
    800043ba:	4505                	li	a0,1
    800043bc:	97ffd0ef          	jal	ra,80001d3a <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    800043c0:	08000613          	li	a2,128
    800043c4:	f5040593          	addi	a1,s0,-176
    800043c8:	4501                	li	a0,0
    800043ca:	9a9fd0ef          	jal	ra,80001d72 <argstr>
    800043ce:	87aa                	mv	a5,a0
    return -1;
    800043d0:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    800043d2:	0807cd63          	bltz	a5,8000446c <sys_open+0xc4>

  begin_op();
    800043d6:	d1dfe0ef          	jal	ra,800030f2 <begin_op>

  if(omode & O_CREATE){
    800043da:	f4c42783          	lw	a5,-180(s0)
    800043de:	2007f793          	andi	a5,a5,512
    800043e2:	c3c5                	beqz	a5,80004482 <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    800043e4:	4681                	li	a3,0
    800043e6:	4601                	li	a2,0
    800043e8:	4589                	li	a1,2
    800043ea:	f5040513          	addi	a0,s0,-176
    800043ee:	ac3ff0ef          	jal	ra,80003eb0 <create>
    800043f2:	84aa                	mv	s1,a0
    if(ip == 0){
    800043f4:	c159                	beqz	a0,8000447a <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    800043f6:	04449703          	lh	a4,68(s1)
    800043fa:	478d                	li	a5,3
    800043fc:	00f71763          	bne	a4,a5,8000440a <sys_open+0x62>
    80004400:	0464d703          	lhu	a4,70(s1)
    80004404:	47a5                	li	a5,9
    80004406:	0ae7e963          	bltu	a5,a4,800044b8 <sys_open+0x110>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    8000440a:	860ff0ef          	jal	ra,8000346a <filealloc>
    8000440e:	89aa                	mv	s3,a0
    80004410:	0c050963          	beqz	a0,800044e2 <sys_open+0x13a>
    80004414:	a5fff0ef          	jal	ra,80003e72 <fdalloc>
    80004418:	892a                	mv	s2,a0
    8000441a:	0c054163          	bltz	a0,800044dc <sys_open+0x134>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    8000441e:	04449703          	lh	a4,68(s1)
    80004422:	478d                	li	a5,3
    80004424:	0af70163          	beq	a4,a5,800044c6 <sys_open+0x11e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80004428:	4789                	li	a5,2
    8000442a:	00f9a023          	sw	a5,0(s3)
    f->off = 0;
    8000442e:	0209a023          	sw	zero,32(s3)
  }
  f->ip = ip;
    80004432:	0099bc23          	sd	s1,24(s3)
  f->readable = !(omode & O_WRONLY);
    80004436:	f4c42783          	lw	a5,-180(s0)
    8000443a:	0017c713          	xori	a4,a5,1
    8000443e:	8b05                	andi	a4,a4,1
    80004440:	00e98423          	sb	a4,8(s3)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004444:	0037f713          	andi	a4,a5,3
    80004448:	00e03733          	snez	a4,a4
    8000444c:	00e984a3          	sb	a4,9(s3)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80004450:	4007f793          	andi	a5,a5,1024
    80004454:	c791                	beqz	a5,80004460 <sys_open+0xb8>
    80004456:	04449703          	lh	a4,68(s1)
    8000445a:	4789                	li	a5,2
    8000445c:	06f70c63          	beq	a4,a5,800044d4 <sys_open+0x12c>
    itrunc(ip);
  }

  iunlock(ip);
    80004460:	8526                	mv	a0,s1
    80004462:	cacfe0ef          	jal	ra,8000290e <iunlock>
  end_op();
    80004466:	cfdfe0ef          	jal	ra,80003162 <end_op>

  return fd;
    8000446a:	854a                	mv	a0,s2
}
    8000446c:	70ea                	ld	ra,184(sp)
    8000446e:	744a                	ld	s0,176(sp)
    80004470:	74aa                	ld	s1,168(sp)
    80004472:	790a                	ld	s2,160(sp)
    80004474:	69ea                	ld	s3,152(sp)
    80004476:	6129                	addi	sp,sp,192
    80004478:	8082                	ret
      end_op();
    8000447a:	ce9fe0ef          	jal	ra,80003162 <end_op>
      return -1;
    8000447e:	557d                	li	a0,-1
    80004480:	b7f5                	j	8000446c <sys_open+0xc4>
    if((ip = namei(path)) == 0){
    80004482:	f5040513          	addi	a0,s0,-176
    80004486:	a91fe0ef          	jal	ra,80002f16 <namei>
    8000448a:	84aa                	mv	s1,a0
    8000448c:	c115                	beqz	a0,800044b0 <sys_open+0x108>
    ilock(ip);
    8000448e:	bd6fe0ef          	jal	ra,80002864 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    80004492:	04449703          	lh	a4,68(s1)
    80004496:	4785                	li	a5,1
    80004498:	f4f71fe3          	bne	a4,a5,800043f6 <sys_open+0x4e>
    8000449c:	f4c42783          	lw	a5,-180(s0)
    800044a0:	d7ad                	beqz	a5,8000440a <sys_open+0x62>
      iunlockput(ip);
    800044a2:	8526                	mv	a0,s1
    800044a4:	dc6fe0ef          	jal	ra,80002a6a <iunlockput>
      end_op();
    800044a8:	cbbfe0ef          	jal	ra,80003162 <end_op>
      return -1;
    800044ac:	557d                	li	a0,-1
    800044ae:	bf7d                	j	8000446c <sys_open+0xc4>
      end_op();
    800044b0:	cb3fe0ef          	jal	ra,80003162 <end_op>
      return -1;
    800044b4:	557d                	li	a0,-1
    800044b6:	bf5d                	j	8000446c <sys_open+0xc4>
    iunlockput(ip);
    800044b8:	8526                	mv	a0,s1
    800044ba:	db0fe0ef          	jal	ra,80002a6a <iunlockput>
    end_op();
    800044be:	ca5fe0ef          	jal	ra,80003162 <end_op>
    return -1;
    800044c2:	557d                	li	a0,-1
    800044c4:	b765                	j	8000446c <sys_open+0xc4>
    f->type = FD_DEVICE;
    800044c6:	00f9a023          	sw	a5,0(s3)
    f->major = ip->major;
    800044ca:	04649783          	lh	a5,70(s1)
    800044ce:	02f99223          	sh	a5,36(s3)
    800044d2:	b785                	j	80004432 <sys_open+0x8a>
    itrunc(ip);
    800044d4:	8526                	mv	a0,s1
    800044d6:	c78fe0ef          	jal	ra,8000294e <itrunc>
    800044da:	b759                	j	80004460 <sys_open+0xb8>
      fileclose(f);
    800044dc:	854e                	mv	a0,s3
    800044de:	830ff0ef          	jal	ra,8000350e <fileclose>
    iunlockput(ip);
    800044e2:	8526                	mv	a0,s1
    800044e4:	d86fe0ef          	jal	ra,80002a6a <iunlockput>
    end_op();
    800044e8:	c7bfe0ef          	jal	ra,80003162 <end_op>
    return -1;
    800044ec:	557d                	li	a0,-1
    800044ee:	bfbd                	j	8000446c <sys_open+0xc4>

00000000800044f0 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    800044f0:	7175                	addi	sp,sp,-144
    800044f2:	e506                	sd	ra,136(sp)
    800044f4:	e122                	sd	s0,128(sp)
    800044f6:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    800044f8:	bfbfe0ef          	jal	ra,800030f2 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    800044fc:	08000613          	li	a2,128
    80004500:	f7040593          	addi	a1,s0,-144
    80004504:	4501                	li	a0,0
    80004506:	86dfd0ef          	jal	ra,80001d72 <argstr>
    8000450a:	02054363          	bltz	a0,80004530 <sys_mkdir+0x40>
    8000450e:	4681                	li	a3,0
    80004510:	4601                	li	a2,0
    80004512:	4585                	li	a1,1
    80004514:	f7040513          	addi	a0,s0,-144
    80004518:	999ff0ef          	jal	ra,80003eb0 <create>
    8000451c:	c911                	beqz	a0,80004530 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000451e:	d4cfe0ef          	jal	ra,80002a6a <iunlockput>
  end_op();
    80004522:	c41fe0ef          	jal	ra,80003162 <end_op>
  return 0;
    80004526:	4501                	li	a0,0
}
    80004528:	60aa                	ld	ra,136(sp)
    8000452a:	640a                	ld	s0,128(sp)
    8000452c:	6149                	addi	sp,sp,144
    8000452e:	8082                	ret
    end_op();
    80004530:	c33fe0ef          	jal	ra,80003162 <end_op>
    return -1;
    80004534:	557d                	li	a0,-1
    80004536:	bfcd                	j	80004528 <sys_mkdir+0x38>

0000000080004538 <sys_mknod>:

uint64
sys_mknod(void)
{
    80004538:	7135                	addi	sp,sp,-160
    8000453a:	ed06                	sd	ra,152(sp)
    8000453c:	e922                	sd	s0,144(sp)
    8000453e:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80004540:	bb3fe0ef          	jal	ra,800030f2 <begin_op>
  argint(1, &major);
    80004544:	f6c40593          	addi	a1,s0,-148
    80004548:	4505                	li	a0,1
    8000454a:	ff0fd0ef          	jal	ra,80001d3a <argint>
  argint(2, &minor);
    8000454e:	f6840593          	addi	a1,s0,-152
    80004552:	4509                	li	a0,2
    80004554:	fe6fd0ef          	jal	ra,80001d3a <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004558:	08000613          	li	a2,128
    8000455c:	f7040593          	addi	a1,s0,-144
    80004560:	4501                	li	a0,0
    80004562:	811fd0ef          	jal	ra,80001d72 <argstr>
    80004566:	02054563          	bltz	a0,80004590 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    8000456a:	f6841683          	lh	a3,-152(s0)
    8000456e:	f6c41603          	lh	a2,-148(s0)
    80004572:	458d                	li	a1,3
    80004574:	f7040513          	addi	a0,s0,-144
    80004578:	939ff0ef          	jal	ra,80003eb0 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    8000457c:	c911                	beqz	a0,80004590 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000457e:	cecfe0ef          	jal	ra,80002a6a <iunlockput>
  end_op();
    80004582:	be1fe0ef          	jal	ra,80003162 <end_op>
  return 0;
    80004586:	4501                	li	a0,0
}
    80004588:	60ea                	ld	ra,152(sp)
    8000458a:	644a                	ld	s0,144(sp)
    8000458c:	610d                	addi	sp,sp,160
    8000458e:	8082                	ret
    end_op();
    80004590:	bd3fe0ef          	jal	ra,80003162 <end_op>
    return -1;
    80004594:	557d                	li	a0,-1
    80004596:	bfcd                	j	80004588 <sys_mknod+0x50>

0000000080004598 <sys_chdir>:

uint64
sys_chdir(void)
{
    80004598:	7135                	addi	sp,sp,-160
    8000459a:	ed06                	sd	ra,152(sp)
    8000459c:	e922                	sd	s0,144(sp)
    8000459e:	e526                	sd	s1,136(sp)
    800045a0:	e14a                	sd	s2,128(sp)
    800045a2:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800045a4:	85ffc0ef          	jal	ra,80000e02 <myproc>
    800045a8:	892a                	mv	s2,a0
  
  begin_op();
    800045aa:	b49fe0ef          	jal	ra,800030f2 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    800045ae:	08000613          	li	a2,128
    800045b2:	f6040593          	addi	a1,s0,-160
    800045b6:	4501                	li	a0,0
    800045b8:	fbafd0ef          	jal	ra,80001d72 <argstr>
    800045bc:	04054163          	bltz	a0,800045fe <sys_chdir+0x66>
    800045c0:	f6040513          	addi	a0,s0,-160
    800045c4:	953fe0ef          	jal	ra,80002f16 <namei>
    800045c8:	84aa                	mv	s1,a0
    800045ca:	c915                	beqz	a0,800045fe <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    800045cc:	a98fe0ef          	jal	ra,80002864 <ilock>
  if(ip->type != T_DIR){
    800045d0:	04449703          	lh	a4,68(s1)
    800045d4:	4785                	li	a5,1
    800045d6:	02f71863          	bne	a4,a5,80004606 <sys_chdir+0x6e>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800045da:	8526                	mv	a0,s1
    800045dc:	b32fe0ef          	jal	ra,8000290e <iunlock>
  iput(p->cwd);
    800045e0:	15893503          	ld	a0,344(s2)
    800045e4:	bfefe0ef          	jal	ra,800029e2 <iput>
  end_op();
    800045e8:	b7bfe0ef          	jal	ra,80003162 <end_op>
  p->cwd = ip;
    800045ec:	14993c23          	sd	s1,344(s2)
  return 0;
    800045f0:	4501                	li	a0,0
}
    800045f2:	60ea                	ld	ra,152(sp)
    800045f4:	644a                	ld	s0,144(sp)
    800045f6:	64aa                	ld	s1,136(sp)
    800045f8:	690a                	ld	s2,128(sp)
    800045fa:	610d                	addi	sp,sp,160
    800045fc:	8082                	ret
    end_op();
    800045fe:	b65fe0ef          	jal	ra,80003162 <end_op>
    return -1;
    80004602:	557d                	li	a0,-1
    80004604:	b7fd                	j	800045f2 <sys_chdir+0x5a>
    iunlockput(ip);
    80004606:	8526                	mv	a0,s1
    80004608:	c62fe0ef          	jal	ra,80002a6a <iunlockput>
    end_op();
    8000460c:	b57fe0ef          	jal	ra,80003162 <end_op>
    return -1;
    80004610:	557d                	li	a0,-1
    80004612:	b7c5                	j	800045f2 <sys_chdir+0x5a>

0000000080004614 <sys_exec>:

uint64
sys_exec(void)
{
    80004614:	7145                	addi	sp,sp,-464
    80004616:	e786                	sd	ra,456(sp)
    80004618:	e3a2                	sd	s0,448(sp)
    8000461a:	ff26                	sd	s1,440(sp)
    8000461c:	fb4a                	sd	s2,432(sp)
    8000461e:	f74e                	sd	s3,424(sp)
    80004620:	f352                	sd	s4,416(sp)
    80004622:	ef56                	sd	s5,408(sp)
    80004624:	0b80                	addi	s0,sp,464
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80004626:	e3840593          	addi	a1,s0,-456
    8000462a:	4505                	li	a0,1
    8000462c:	f2afd0ef          	jal	ra,80001d56 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80004630:	08000613          	li	a2,128
    80004634:	f4040593          	addi	a1,s0,-192
    80004638:	4501                	li	a0,0
    8000463a:	f38fd0ef          	jal	ra,80001d72 <argstr>
    8000463e:	87aa                	mv	a5,a0
    return -1;
    80004640:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80004642:	0a07c463          	bltz	a5,800046ea <sys_exec+0xd6>
  }
  memset(argv, 0, sizeof(argv));
    80004646:	10000613          	li	a2,256
    8000464a:	4581                	li	a1,0
    8000464c:	e4040513          	addi	a0,s0,-448
    80004650:	afdfb0ef          	jal	ra,8000014c <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80004654:	e4040493          	addi	s1,s0,-448
  memset(argv, 0, sizeof(argv));
    80004658:	89a6                	mv	s3,s1
    8000465a:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    8000465c:	02000a13          	li	s4,32
    80004660:	00090a9b          	sext.w	s5,s2
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80004664:	00391793          	slli	a5,s2,0x3
    80004668:	e3040593          	addi	a1,s0,-464
    8000466c:	e3843503          	ld	a0,-456(s0)
    80004670:	953e                	add	a0,a0,a5
    80004672:	e3efd0ef          	jal	ra,80001cb0 <fetchaddr>
    80004676:	02054663          	bltz	a0,800046a2 <sys_exec+0x8e>
      goto bad;
    }
    if(uarg == 0){
    8000467a:	e3043783          	ld	a5,-464(s0)
    8000467e:	cf8d                	beqz	a5,800046b8 <sys_exec+0xa4>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    80004680:	a7dfb0ef          	jal	ra,800000fc <kalloc>
    80004684:	85aa                	mv	a1,a0
    80004686:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    8000468a:	cd01                	beqz	a0,800046a2 <sys_exec+0x8e>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    8000468c:	6605                	lui	a2,0x1
    8000468e:	e3043503          	ld	a0,-464(s0)
    80004692:	e68fd0ef          	jal	ra,80001cfa <fetchstr>
    80004696:	00054663          	bltz	a0,800046a2 <sys_exec+0x8e>
    if(i >= NELEM(argv)){
    8000469a:	0905                	addi	s2,s2,1
    8000469c:	09a1                	addi	s3,s3,8
    8000469e:	fd4911e3          	bne	s2,s4,80004660 <sys_exec+0x4c>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800046a2:	10048913          	addi	s2,s1,256
    800046a6:	6088                	ld	a0,0(s1)
    800046a8:	c121                	beqz	a0,800046e8 <sys_exec+0xd4>
    kfree(argv[i]);
    800046aa:	973fb0ef          	jal	ra,8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800046ae:	04a1                	addi	s1,s1,8
    800046b0:	ff249be3          	bne	s1,s2,800046a6 <sys_exec+0x92>
  return -1;
    800046b4:	557d                	li	a0,-1
    800046b6:	a815                	j	800046ea <sys_exec+0xd6>
      argv[i] = 0;
    800046b8:	0a8e                	slli	s5,s5,0x3
    800046ba:	fc040793          	addi	a5,s0,-64
    800046be:	9abe                	add	s5,s5,a5
    800046c0:	e80ab023          	sd	zero,-384(s5)
  int ret = exec(path, argv);
    800046c4:	e4040593          	addi	a1,s0,-448
    800046c8:	f4040513          	addi	a0,s0,-192
    800046cc:	be4ff0ef          	jal	ra,80003ab0 <exec>
    800046d0:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800046d2:	10048993          	addi	s3,s1,256
    800046d6:	6088                	ld	a0,0(s1)
    800046d8:	c511                	beqz	a0,800046e4 <sys_exec+0xd0>
    kfree(argv[i]);
    800046da:	943fb0ef          	jal	ra,8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800046de:	04a1                	addi	s1,s1,8
    800046e0:	ff349be3          	bne	s1,s3,800046d6 <sys_exec+0xc2>
  return ret;
    800046e4:	854a                	mv	a0,s2
    800046e6:	a011                	j	800046ea <sys_exec+0xd6>
  return -1;
    800046e8:	557d                	li	a0,-1
}
    800046ea:	60be                	ld	ra,456(sp)
    800046ec:	641e                	ld	s0,448(sp)
    800046ee:	74fa                	ld	s1,440(sp)
    800046f0:	795a                	ld	s2,432(sp)
    800046f2:	79ba                	ld	s3,424(sp)
    800046f4:	7a1a                	ld	s4,416(sp)
    800046f6:	6afa                	ld	s5,408(sp)
    800046f8:	6179                	addi	sp,sp,464
    800046fa:	8082                	ret

00000000800046fc <sys_pipe>:

uint64
sys_pipe(void)
{
    800046fc:	7139                	addi	sp,sp,-64
    800046fe:	fc06                	sd	ra,56(sp)
    80004700:	f822                	sd	s0,48(sp)
    80004702:	f426                	sd	s1,40(sp)
    80004704:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80004706:	efcfc0ef          	jal	ra,80000e02 <myproc>
    8000470a:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    8000470c:	fd840593          	addi	a1,s0,-40
    80004710:	4501                	li	a0,0
    80004712:	e44fd0ef          	jal	ra,80001d56 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80004716:	fc840593          	addi	a1,s0,-56
    8000471a:	fd040513          	addi	a0,s0,-48
    8000471e:	8bcff0ef          	jal	ra,800037da <pipealloc>
    return -1;
    80004722:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80004724:	0a054463          	bltz	a0,800047cc <sys_pipe+0xd0>
  fd0 = -1;
    80004728:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    8000472c:	fd043503          	ld	a0,-48(s0)
    80004730:	f42ff0ef          	jal	ra,80003e72 <fdalloc>
    80004734:	fca42223          	sw	a0,-60(s0)
    80004738:	08054163          	bltz	a0,800047ba <sys_pipe+0xbe>
    8000473c:	fc843503          	ld	a0,-56(s0)
    80004740:	f32ff0ef          	jal	ra,80003e72 <fdalloc>
    80004744:	fca42023          	sw	a0,-64(s0)
    80004748:	06054063          	bltz	a0,800047a8 <sys_pipe+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    8000474c:	4691                	li	a3,4
    8000474e:	fc440613          	addi	a2,s0,-60
    80004752:	fd843583          	ld	a1,-40(s0)
    80004756:	6ca8                	ld	a0,88(s1)
    80004758:	b20fc0ef          	jal	ra,80000a78 <copyout>
    8000475c:	00054e63          	bltz	a0,80004778 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80004760:	4691                	li	a3,4
    80004762:	fc040613          	addi	a2,s0,-64
    80004766:	fd843583          	ld	a1,-40(s0)
    8000476a:	0591                	addi	a1,a1,4
    8000476c:	6ca8                	ld	a0,88(s1)
    8000476e:	b0afc0ef          	jal	ra,80000a78 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80004772:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80004774:	04055c63          	bgez	a0,800047cc <sys_pipe+0xd0>
    p->ofile[fd0] = 0;
    80004778:	fc442783          	lw	a5,-60(s0)
    8000477c:	07e9                	addi	a5,a5,26
    8000477e:	078e                	slli	a5,a5,0x3
    80004780:	97a6                	add	a5,a5,s1
    80004782:	0007b423          	sd	zero,8(a5)
    p->ofile[fd1] = 0;
    80004786:	fc042503          	lw	a0,-64(s0)
    8000478a:	0569                	addi	a0,a0,26
    8000478c:	050e                	slli	a0,a0,0x3
    8000478e:	94aa                	add	s1,s1,a0
    80004790:	0004b423          	sd	zero,8(s1)
    fileclose(rf);
    80004794:	fd043503          	ld	a0,-48(s0)
    80004798:	d77fe0ef          	jal	ra,8000350e <fileclose>
    fileclose(wf);
    8000479c:	fc843503          	ld	a0,-56(s0)
    800047a0:	d6ffe0ef          	jal	ra,8000350e <fileclose>
    return -1;
    800047a4:	57fd                	li	a5,-1
    800047a6:	a01d                	j	800047cc <sys_pipe+0xd0>
    if(fd0 >= 0)
    800047a8:	fc442783          	lw	a5,-60(s0)
    800047ac:	0007c763          	bltz	a5,800047ba <sys_pipe+0xbe>
      p->ofile[fd0] = 0;
    800047b0:	07e9                	addi	a5,a5,26
    800047b2:	078e                	slli	a5,a5,0x3
    800047b4:	94be                	add	s1,s1,a5
    800047b6:	0004b423          	sd	zero,8(s1)
    fileclose(rf);
    800047ba:	fd043503          	ld	a0,-48(s0)
    800047be:	d51fe0ef          	jal	ra,8000350e <fileclose>
    fileclose(wf);
    800047c2:	fc843503          	ld	a0,-56(s0)
    800047c6:	d49fe0ef          	jal	ra,8000350e <fileclose>
    return -1;
    800047ca:	57fd                	li	a5,-1
}
    800047cc:	853e                	mv	a0,a5
    800047ce:	70e2                	ld	ra,56(sp)
    800047d0:	7442                	ld	s0,48(sp)
    800047d2:	74a2                	ld	s1,40(sp)
    800047d4:	6121                	addi	sp,sp,64
    800047d6:	8082                	ret
	...

00000000800047e0 <kernelvec>:
    800047e0:	7111                	addi	sp,sp,-256
    800047e2:	e006                	sd	ra,0(sp)
    800047e4:	e40a                	sd	sp,8(sp)
    800047e6:	e80e                	sd	gp,16(sp)
    800047e8:	ec12                	sd	tp,24(sp)
    800047ea:	f016                	sd	t0,32(sp)
    800047ec:	f41a                	sd	t1,40(sp)
    800047ee:	f81e                	sd	t2,48(sp)
    800047f0:	e4aa                	sd	a0,72(sp)
    800047f2:	e8ae                	sd	a1,80(sp)
    800047f4:	ecb2                	sd	a2,88(sp)
    800047f6:	f0b6                	sd	a3,96(sp)
    800047f8:	f4ba                	sd	a4,104(sp)
    800047fa:	f8be                	sd	a5,112(sp)
    800047fc:	fcc2                	sd	a6,120(sp)
    800047fe:	e146                	sd	a7,128(sp)
    80004800:	edf2                	sd	t3,216(sp)
    80004802:	f1f6                	sd	t4,224(sp)
    80004804:	f5fa                	sd	t5,232(sp)
    80004806:	f9fe                	sd	t6,240(sp)
    80004808:	bb8fd0ef          	jal	ra,80001bc0 <kerneltrap>
    8000480c:	6082                	ld	ra,0(sp)
    8000480e:	6122                	ld	sp,8(sp)
    80004810:	61c2                	ld	gp,16(sp)
    80004812:	7282                	ld	t0,32(sp)
    80004814:	7322                	ld	t1,40(sp)
    80004816:	73c2                	ld	t2,48(sp)
    80004818:	6526                	ld	a0,72(sp)
    8000481a:	65c6                	ld	a1,80(sp)
    8000481c:	6666                	ld	a2,88(sp)
    8000481e:	7686                	ld	a3,96(sp)
    80004820:	7726                	ld	a4,104(sp)
    80004822:	77c6                	ld	a5,112(sp)
    80004824:	7866                	ld	a6,120(sp)
    80004826:	688a                	ld	a7,128(sp)
    80004828:	6e6e                	ld	t3,216(sp)
    8000482a:	7e8e                	ld	t4,224(sp)
    8000482c:	7f2e                	ld	t5,232(sp)
    8000482e:	7fce                	ld	t6,240(sp)
    80004830:	6111                	addi	sp,sp,256
    80004832:	10200073          	sret
	...

000000008000483e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000483e:	1141                	addi	sp,sp,-16
    80004840:	e422                	sd	s0,8(sp)
    80004842:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80004844:	0c0007b7          	lui	a5,0xc000
    80004848:	4705                	li	a4,1
    8000484a:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000484c:	c3d8                	sw	a4,4(a5)
}
    8000484e:	6422                	ld	s0,8(sp)
    80004850:	0141                	addi	sp,sp,16
    80004852:	8082                	ret

0000000080004854 <plicinithart>:

void
plicinithart(void)
{
    80004854:	1141                	addi	sp,sp,-16
    80004856:	e406                	sd	ra,8(sp)
    80004858:	e022                	sd	s0,0(sp)
    8000485a:	0800                	addi	s0,sp,16
  int hart = cpuid();
    8000485c:	d7afc0ef          	jal	ra,80000dd6 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80004860:	0085171b          	slliw	a4,a0,0x8
    80004864:	0c0027b7          	lui	a5,0xc002
    80004868:	97ba                	add	a5,a5,a4
    8000486a:	40200713          	li	a4,1026
    8000486e:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80004872:	00d5151b          	slliw	a0,a0,0xd
    80004876:	0c2017b7          	lui	a5,0xc201
    8000487a:	953e                	add	a0,a0,a5
    8000487c:	00052023          	sw	zero,0(a0)
}
    80004880:	60a2                	ld	ra,8(sp)
    80004882:	6402                	ld	s0,0(sp)
    80004884:	0141                	addi	sp,sp,16
    80004886:	8082                	ret

0000000080004888 <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    80004888:	1141                	addi	sp,sp,-16
    8000488a:	e406                	sd	ra,8(sp)
    8000488c:	e022                	sd	s0,0(sp)
    8000488e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80004890:	d46fc0ef          	jal	ra,80000dd6 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80004894:	00d5179b          	slliw	a5,a0,0xd
    80004898:	0c201537          	lui	a0,0xc201
    8000489c:	953e                	add	a0,a0,a5
  return irq;
}
    8000489e:	4148                	lw	a0,4(a0)
    800048a0:	60a2                	ld	ra,8(sp)
    800048a2:	6402                	ld	s0,0(sp)
    800048a4:	0141                	addi	sp,sp,16
    800048a6:	8082                	ret

00000000800048a8 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    800048a8:	1101                	addi	sp,sp,-32
    800048aa:	ec06                	sd	ra,24(sp)
    800048ac:	e822                	sd	s0,16(sp)
    800048ae:	e426                	sd	s1,8(sp)
    800048b0:	1000                	addi	s0,sp,32
    800048b2:	84aa                	mv	s1,a0
  int hart = cpuid();
    800048b4:	d22fc0ef          	jal	ra,80000dd6 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    800048b8:	00d5151b          	slliw	a0,a0,0xd
    800048bc:	0c2017b7          	lui	a5,0xc201
    800048c0:	97aa                	add	a5,a5,a0
    800048c2:	c3c4                	sw	s1,4(a5)
}
    800048c4:	60e2                	ld	ra,24(sp)
    800048c6:	6442                	ld	s0,16(sp)
    800048c8:	64a2                	ld	s1,8(sp)
    800048ca:	6105                	addi	sp,sp,32
    800048cc:	8082                	ret

00000000800048ce <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    800048ce:	1141                	addi	sp,sp,-16
    800048d0:	e406                	sd	ra,8(sp)
    800048d2:	e022                	sd	s0,0(sp)
    800048d4:	0800                	addi	s0,sp,16
  if(i >= NUM)
    800048d6:	479d                	li	a5,7
    800048d8:	04a7ca63          	blt	a5,a0,8000492c <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    800048dc:	00014797          	auipc	a5,0x14
    800048e0:	3c478793          	addi	a5,a5,964 # 80018ca0 <disk>
    800048e4:	97aa                	add	a5,a5,a0
    800048e6:	0187c783          	lbu	a5,24(a5)
    800048ea:	e7b9                	bnez	a5,80004938 <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    800048ec:	00451613          	slli	a2,a0,0x4
    800048f0:	00014797          	auipc	a5,0x14
    800048f4:	3b078793          	addi	a5,a5,944 # 80018ca0 <disk>
    800048f8:	6394                	ld	a3,0(a5)
    800048fa:	96b2                	add	a3,a3,a2
    800048fc:	0006b023          	sd	zero,0(a3)
  disk.desc[i].len = 0;
    80004900:	6398                	ld	a4,0(a5)
    80004902:	9732                	add	a4,a4,a2
    80004904:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80004908:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    8000490c:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80004910:	953e                	add	a0,a0,a5
    80004912:	4785                	li	a5,1
    80004914:	00f50c23          	sb	a5,24(a0) # c201018 <_entry-0x73dfefe8>
  wakeup(&disk.free[0]);
    80004918:	00014517          	auipc	a0,0x14
    8000491c:	3a050513          	addi	a0,a0,928 # 80018cb8 <disk+0x18>
    80004920:	b85fc0ef          	jal	ra,800014a4 <wakeup>
}
    80004924:	60a2                	ld	ra,8(sp)
    80004926:	6402                	ld	s0,0(sp)
    80004928:	0141                	addi	sp,sp,16
    8000492a:	8082                	ret
    panic("free_desc 1");
    8000492c:	00003517          	auipc	a0,0x3
    80004930:	e8450513          	addi	a0,a0,-380 # 800077b0 <syscalls+0x358>
    80004934:	3c3000ef          	jal	ra,800054f6 <panic>
    panic("free_desc 2");
    80004938:	00003517          	auipc	a0,0x3
    8000493c:	e8850513          	addi	a0,a0,-376 # 800077c0 <syscalls+0x368>
    80004940:	3b7000ef          	jal	ra,800054f6 <panic>

0000000080004944 <virtio_disk_init>:
{
    80004944:	1101                	addi	sp,sp,-32
    80004946:	ec06                	sd	ra,24(sp)
    80004948:	e822                	sd	s0,16(sp)
    8000494a:	e426                	sd	s1,8(sp)
    8000494c:	e04a                	sd	s2,0(sp)
    8000494e:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80004950:	00003597          	auipc	a1,0x3
    80004954:	e8058593          	addi	a1,a1,-384 # 800077d0 <syscalls+0x378>
    80004958:	00014517          	auipc	a0,0x14
    8000495c:	47050513          	addi	a0,a0,1136 # 80018dc8 <disk+0x128>
    80004960:	62b000ef          	jal	ra,8000578a <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004964:	100017b7          	lui	a5,0x10001
    80004968:	4398                	lw	a4,0(a5)
    8000496a:	2701                	sext.w	a4,a4
    8000496c:	747277b7          	lui	a5,0x74727
    80004970:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80004974:	14f71063          	bne	a4,a5,80004ab4 <virtio_disk_init+0x170>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80004978:	100017b7          	lui	a5,0x10001
    8000497c:	43dc                	lw	a5,4(a5)
    8000497e:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004980:	4709                	li	a4,2
    80004982:	12e79963          	bne	a5,a4,80004ab4 <virtio_disk_init+0x170>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80004986:	100017b7          	lui	a5,0x10001
    8000498a:	479c                	lw	a5,8(a5)
    8000498c:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    8000498e:	12e79363          	bne	a5,a4,80004ab4 <virtio_disk_init+0x170>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80004992:	100017b7          	lui	a5,0x10001
    80004996:	47d8                	lw	a4,12(a5)
    80004998:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000499a:	554d47b7          	lui	a5,0x554d4
    8000499e:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800049a2:	10f71963          	bne	a4,a5,80004ab4 <virtio_disk_init+0x170>
  *R(VIRTIO_MMIO_STATUS) = status;
    800049a6:	100017b7          	lui	a5,0x10001
    800049aa:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    800049ae:	4705                	li	a4,1
    800049b0:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800049b2:	470d                	li	a4,3
    800049b4:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800049b6:	4b94                	lw	a3,16(a5)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    800049b8:	c7ffe737          	lui	a4,0xc7ffe
    800049bc:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47fdd87f>
    800049c0:	8f75                	and	a4,a4,a3
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    800049c2:	2701                	sext.w	a4,a4
    800049c4:	d398                	sw	a4,32(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800049c6:	472d                	li	a4,11
    800049c8:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    800049ca:	5bbc                	lw	a5,112(a5)
    800049cc:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    800049d0:	8ba1                	andi	a5,a5,8
    800049d2:	0e078763          	beqz	a5,80004ac0 <virtio_disk_init+0x17c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    800049d6:	100017b7          	lui	a5,0x10001
    800049da:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    800049de:	43fc                	lw	a5,68(a5)
    800049e0:	2781                	sext.w	a5,a5
    800049e2:	0e079563          	bnez	a5,80004acc <virtio_disk_init+0x188>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    800049e6:	100017b7          	lui	a5,0x10001
    800049ea:	5bdc                	lw	a5,52(a5)
    800049ec:	2781                	sext.w	a5,a5
  if(max == 0)
    800049ee:	0e078563          	beqz	a5,80004ad8 <virtio_disk_init+0x194>
  if(max < NUM)
    800049f2:	471d                	li	a4,7
    800049f4:	0ef77863          	bgeu	a4,a5,80004ae4 <virtio_disk_init+0x1a0>
  disk.desc = kalloc();
    800049f8:	f04fb0ef          	jal	ra,800000fc <kalloc>
    800049fc:	00014497          	auipc	s1,0x14
    80004a00:	2a448493          	addi	s1,s1,676 # 80018ca0 <disk>
    80004a04:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80004a06:	ef6fb0ef          	jal	ra,800000fc <kalloc>
    80004a0a:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80004a0c:	ef0fb0ef          	jal	ra,800000fc <kalloc>
    80004a10:	87aa                	mv	a5,a0
    80004a12:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80004a14:	6088                	ld	a0,0(s1)
    80004a16:	cd69                	beqz	a0,80004af0 <virtio_disk_init+0x1ac>
    80004a18:	00014717          	auipc	a4,0x14
    80004a1c:	29073703          	ld	a4,656(a4) # 80018ca8 <disk+0x8>
    80004a20:	cb61                	beqz	a4,80004af0 <virtio_disk_init+0x1ac>
    80004a22:	c7f9                	beqz	a5,80004af0 <virtio_disk_init+0x1ac>
  memset(disk.desc, 0, PGSIZE);
    80004a24:	6605                	lui	a2,0x1
    80004a26:	4581                	li	a1,0
    80004a28:	f24fb0ef          	jal	ra,8000014c <memset>
  memset(disk.avail, 0, PGSIZE);
    80004a2c:	00014497          	auipc	s1,0x14
    80004a30:	27448493          	addi	s1,s1,628 # 80018ca0 <disk>
    80004a34:	6605                	lui	a2,0x1
    80004a36:	4581                	li	a1,0
    80004a38:	6488                	ld	a0,8(s1)
    80004a3a:	f12fb0ef          	jal	ra,8000014c <memset>
  memset(disk.used, 0, PGSIZE);
    80004a3e:	6605                	lui	a2,0x1
    80004a40:	4581                	li	a1,0
    80004a42:	6888                	ld	a0,16(s1)
    80004a44:	f08fb0ef          	jal	ra,8000014c <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80004a48:	100017b7          	lui	a5,0x10001
    80004a4c:	4721                	li	a4,8
    80004a4e:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80004a50:	4098                	lw	a4,0(s1)
    80004a52:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80004a56:	40d8                	lw	a4,4(s1)
    80004a58:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80004a5c:	6498                	ld	a4,8(s1)
    80004a5e:	0007069b          	sext.w	a3,a4
    80004a62:	08d7a823          	sw	a3,144(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80004a66:	9701                	srai	a4,a4,0x20
    80004a68:	08e7aa23          	sw	a4,148(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80004a6c:	6898                	ld	a4,16(s1)
    80004a6e:	0007069b          	sext.w	a3,a4
    80004a72:	0ad7a023          	sw	a3,160(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80004a76:	9701                	srai	a4,a4,0x20
    80004a78:	0ae7a223          	sw	a4,164(a5)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80004a7c:	4705                	li	a4,1
    80004a7e:	c3f8                	sw	a4,68(a5)
    disk.free[i] = 1;
    80004a80:	00e48c23          	sb	a4,24(s1)
    80004a84:	00e48ca3          	sb	a4,25(s1)
    80004a88:	00e48d23          	sb	a4,26(s1)
    80004a8c:	00e48da3          	sb	a4,27(s1)
    80004a90:	00e48e23          	sb	a4,28(s1)
    80004a94:	00e48ea3          	sb	a4,29(s1)
    80004a98:	00e48f23          	sb	a4,30(s1)
    80004a9c:	00e48fa3          	sb	a4,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80004aa0:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80004aa4:	0727a823          	sw	s2,112(a5)
}
    80004aa8:	60e2                	ld	ra,24(sp)
    80004aaa:	6442                	ld	s0,16(sp)
    80004aac:	64a2                	ld	s1,8(sp)
    80004aae:	6902                	ld	s2,0(sp)
    80004ab0:	6105                	addi	sp,sp,32
    80004ab2:	8082                	ret
    panic("could not find virtio disk");
    80004ab4:	00003517          	auipc	a0,0x3
    80004ab8:	d2c50513          	addi	a0,a0,-724 # 800077e0 <syscalls+0x388>
    80004abc:	23b000ef          	jal	ra,800054f6 <panic>
    panic("virtio disk FEATURES_OK unset");
    80004ac0:	00003517          	auipc	a0,0x3
    80004ac4:	d4050513          	addi	a0,a0,-704 # 80007800 <syscalls+0x3a8>
    80004ac8:	22f000ef          	jal	ra,800054f6 <panic>
    panic("virtio disk should not be ready");
    80004acc:	00003517          	auipc	a0,0x3
    80004ad0:	d5450513          	addi	a0,a0,-684 # 80007820 <syscalls+0x3c8>
    80004ad4:	223000ef          	jal	ra,800054f6 <panic>
    panic("virtio disk has no queue 0");
    80004ad8:	00003517          	auipc	a0,0x3
    80004adc:	d6850513          	addi	a0,a0,-664 # 80007840 <syscalls+0x3e8>
    80004ae0:	217000ef          	jal	ra,800054f6 <panic>
    panic("virtio disk max queue too short");
    80004ae4:	00003517          	auipc	a0,0x3
    80004ae8:	d7c50513          	addi	a0,a0,-644 # 80007860 <syscalls+0x408>
    80004aec:	20b000ef          	jal	ra,800054f6 <panic>
    panic("virtio disk kalloc");
    80004af0:	00003517          	auipc	a0,0x3
    80004af4:	d9050513          	addi	a0,a0,-624 # 80007880 <syscalls+0x428>
    80004af8:	1ff000ef          	jal	ra,800054f6 <panic>

0000000080004afc <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80004afc:	7119                	addi	sp,sp,-128
    80004afe:	fc86                	sd	ra,120(sp)
    80004b00:	f8a2                	sd	s0,112(sp)
    80004b02:	f4a6                	sd	s1,104(sp)
    80004b04:	f0ca                	sd	s2,96(sp)
    80004b06:	ecce                	sd	s3,88(sp)
    80004b08:	e8d2                	sd	s4,80(sp)
    80004b0a:	e4d6                	sd	s5,72(sp)
    80004b0c:	e0da                	sd	s6,64(sp)
    80004b0e:	fc5e                	sd	s7,56(sp)
    80004b10:	f862                	sd	s8,48(sp)
    80004b12:	f466                	sd	s9,40(sp)
    80004b14:	f06a                	sd	s10,32(sp)
    80004b16:	ec6e                	sd	s11,24(sp)
    80004b18:	0100                	addi	s0,sp,128
    80004b1a:	8aaa                	mv	s5,a0
    80004b1c:	8c2e                	mv	s8,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80004b1e:	00c52d03          	lw	s10,12(a0)
    80004b22:	001d1d1b          	slliw	s10,s10,0x1
    80004b26:	1d02                	slli	s10,s10,0x20
    80004b28:	020d5d13          	srli	s10,s10,0x20

  acquire(&disk.vdisk_lock);
    80004b2c:	00014517          	auipc	a0,0x14
    80004b30:	29c50513          	addi	a0,a0,668 # 80018dc8 <disk+0x128>
    80004b34:	4d7000ef          	jal	ra,8000580a <acquire>
  for(int i = 0; i < 3; i++){
    80004b38:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    80004b3a:	44a1                	li	s1,8
      disk.free[i] = 0;
    80004b3c:	00014b97          	auipc	s7,0x14
    80004b40:	164b8b93          	addi	s7,s7,356 # 80018ca0 <disk>
  for(int i = 0; i < 3; i++){
    80004b44:	4b0d                	li	s6,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80004b46:	00014c97          	auipc	s9,0x14
    80004b4a:	282c8c93          	addi	s9,s9,642 # 80018dc8 <disk+0x128>
    80004b4e:	a8a9                	j	80004ba8 <virtio_disk_rw+0xac>
      disk.free[i] = 0;
    80004b50:	00fb8733          	add	a4,s7,a5
    80004b54:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80004b58:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80004b5a:	0207c563          	bltz	a5,80004b84 <virtio_disk_rw+0x88>
  for(int i = 0; i < 3; i++){
    80004b5e:	2905                	addiw	s2,s2,1
    80004b60:	0611                	addi	a2,a2,4
    80004b62:	05690863          	beq	s2,s6,80004bb2 <virtio_disk_rw+0xb6>
    idx[i] = alloc_desc();
    80004b66:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80004b68:	00014717          	auipc	a4,0x14
    80004b6c:	13870713          	addi	a4,a4,312 # 80018ca0 <disk>
    80004b70:	87ce                	mv	a5,s3
    if(disk.free[i]){
    80004b72:	01874683          	lbu	a3,24(a4)
    80004b76:	fee9                	bnez	a3,80004b50 <virtio_disk_rw+0x54>
  for(int i = 0; i < NUM; i++){
    80004b78:	2785                	addiw	a5,a5,1
    80004b7a:	0705                	addi	a4,a4,1
    80004b7c:	fe979be3          	bne	a5,s1,80004b72 <virtio_disk_rw+0x76>
    idx[i] = alloc_desc();
    80004b80:	57fd                	li	a5,-1
    80004b82:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    80004b84:	01205b63          	blez	s2,80004b9a <virtio_disk_rw+0x9e>
    80004b88:	8dce                	mv	s11,s3
        free_desc(idx[j]);
    80004b8a:	000a2503          	lw	a0,0(s4)
    80004b8e:	d41ff0ef          	jal	ra,800048ce <free_desc>
      for(int j = 0; j < i; j++)
    80004b92:	2d85                	addiw	s11,s11,1
    80004b94:	0a11                	addi	s4,s4,4
    80004b96:	ffb91ae3          	bne	s2,s11,80004b8a <virtio_disk_rw+0x8e>
    sleep(&disk.free[0], &disk.vdisk_lock);
    80004b9a:	85e6                	mv	a1,s9
    80004b9c:	00014517          	auipc	a0,0x14
    80004ba0:	11c50513          	addi	a0,a0,284 # 80018cb8 <disk+0x18>
    80004ba4:	8b5fc0ef          	jal	ra,80001458 <sleep>
  for(int i = 0; i < 3; i++){
    80004ba8:	f8040a13          	addi	s4,s0,-128
{
    80004bac:	8652                	mv	a2,s4
  for(int i = 0; i < 3; i++){
    80004bae:	894e                	mv	s2,s3
    80004bb0:	bf5d                	j	80004b66 <virtio_disk_rw+0x6a>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004bb2:	f8042583          	lw	a1,-128(s0)
    80004bb6:	00a58793          	addi	a5,a1,10
    80004bba:	0792                	slli	a5,a5,0x4

  if(write)
    80004bbc:	00014617          	auipc	a2,0x14
    80004bc0:	0e460613          	addi	a2,a2,228 # 80018ca0 <disk>
    80004bc4:	00f60733          	add	a4,a2,a5
    80004bc8:	018036b3          	snez	a3,s8
    80004bcc:	c714                	sw	a3,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80004bce:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80004bd2:	01a73823          	sd	s10,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80004bd6:	f6078693          	addi	a3,a5,-160
    80004bda:	6218                	ld	a4,0(a2)
    80004bdc:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004bde:	00878513          	addi	a0,a5,8
    80004be2:	9532                	add	a0,a0,a2
  disk.desc[idx[0]].addr = (uint64) buf0;
    80004be4:	e308                	sd	a0,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80004be6:	6208                	ld	a0,0(a2)
    80004be8:	96aa                	add	a3,a3,a0
    80004bea:	4741                	li	a4,16
    80004bec:	c698                	sw	a4,8(a3)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80004bee:	4705                	li	a4,1
    80004bf0:	00e69623          	sh	a4,12(a3)
  disk.desc[idx[0]].next = idx[1];
    80004bf4:	f8442703          	lw	a4,-124(s0)
    80004bf8:	00e69723          	sh	a4,14(a3)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80004bfc:	0712                	slli	a4,a4,0x4
    80004bfe:	953a                	add	a0,a0,a4
    80004c00:	058a8693          	addi	a3,s5,88
    80004c04:	e114                	sd	a3,0(a0)
  disk.desc[idx[1]].len = BSIZE;
    80004c06:	6208                	ld	a0,0(a2)
    80004c08:	972a                	add	a4,a4,a0
    80004c0a:	40000693          	li	a3,1024
    80004c0e:	c714                	sw	a3,8(a4)
  if(write)
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
    80004c10:	001c3c13          	seqz	s8,s8
    80004c14:	0c06                	slli	s8,s8,0x1
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80004c16:	001c6c13          	ori	s8,s8,1
    80004c1a:	01871623          	sh	s8,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80004c1e:	f8842603          	lw	a2,-120(s0)
    80004c22:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80004c26:	00014697          	auipc	a3,0x14
    80004c2a:	07a68693          	addi	a3,a3,122 # 80018ca0 <disk>
    80004c2e:	00258713          	addi	a4,a1,2
    80004c32:	0712                	slli	a4,a4,0x4
    80004c34:	9736                	add	a4,a4,a3
    80004c36:	587d                	li	a6,-1
    80004c38:	01070823          	sb	a6,16(a4)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80004c3c:	0612                	slli	a2,a2,0x4
    80004c3e:	9532                	add	a0,a0,a2
    80004c40:	f9078793          	addi	a5,a5,-112
    80004c44:	97b6                	add	a5,a5,a3
    80004c46:	e11c                	sd	a5,0(a0)
  disk.desc[idx[2]].len = 1;
    80004c48:	629c                	ld	a5,0(a3)
    80004c4a:	97b2                	add	a5,a5,a2
    80004c4c:	4605                	li	a2,1
    80004c4e:	c790                	sw	a2,8(a5)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80004c50:	4509                	li	a0,2
    80004c52:	00a79623          	sh	a0,12(a5)
  disk.desc[idx[2]].next = 0;
    80004c56:	00079723          	sh	zero,14(a5)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80004c5a:	00caa223          	sw	a2,4(s5)
  disk.info[idx[0]].b = b;
    80004c5e:	01573423          	sd	s5,8(a4)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80004c62:	6698                	ld	a4,8(a3)
    80004c64:	00275783          	lhu	a5,2(a4)
    80004c68:	8b9d                	andi	a5,a5,7
    80004c6a:	0786                	slli	a5,a5,0x1
    80004c6c:	97ba                	add	a5,a5,a4
    80004c6e:	00b79223          	sh	a1,4(a5)

  __sync_synchronize();
    80004c72:	0ff0000f          	fence

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80004c76:	6698                	ld	a4,8(a3)
    80004c78:	00275783          	lhu	a5,2(a4)
    80004c7c:	2785                	addiw	a5,a5,1
    80004c7e:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80004c82:	0ff0000f          	fence

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80004c86:	100017b7          	lui	a5,0x10001
    80004c8a:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80004c8e:	004aa783          	lw	a5,4(s5)
    80004c92:	00c79f63          	bne	a5,a2,80004cb0 <virtio_disk_rw+0x1b4>
    sleep(b, &disk.vdisk_lock);
    80004c96:	00014917          	auipc	s2,0x14
    80004c9a:	13290913          	addi	s2,s2,306 # 80018dc8 <disk+0x128>
  while(b->disk == 1) {
    80004c9e:	4485                	li	s1,1
    sleep(b, &disk.vdisk_lock);
    80004ca0:	85ca                	mv	a1,s2
    80004ca2:	8556                	mv	a0,s5
    80004ca4:	fb4fc0ef          	jal	ra,80001458 <sleep>
  while(b->disk == 1) {
    80004ca8:	004aa783          	lw	a5,4(s5)
    80004cac:	fe978ae3          	beq	a5,s1,80004ca0 <virtio_disk_rw+0x1a4>
  }

  disk.info[idx[0]].b = 0;
    80004cb0:	f8042903          	lw	s2,-128(s0)
    80004cb4:	00290793          	addi	a5,s2,2
    80004cb8:	00479713          	slli	a4,a5,0x4
    80004cbc:	00014797          	auipc	a5,0x14
    80004cc0:	fe478793          	addi	a5,a5,-28 # 80018ca0 <disk>
    80004cc4:	97ba                	add	a5,a5,a4
    80004cc6:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80004cca:	00014997          	auipc	s3,0x14
    80004cce:	fd698993          	addi	s3,s3,-42 # 80018ca0 <disk>
    80004cd2:	00491713          	slli	a4,s2,0x4
    80004cd6:	0009b783          	ld	a5,0(s3)
    80004cda:	97ba                	add	a5,a5,a4
    80004cdc:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80004ce0:	854a                	mv	a0,s2
    80004ce2:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80004ce6:	be9ff0ef          	jal	ra,800048ce <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80004cea:	8885                	andi	s1,s1,1
    80004cec:	f0fd                	bnez	s1,80004cd2 <virtio_disk_rw+0x1d6>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80004cee:	00014517          	auipc	a0,0x14
    80004cf2:	0da50513          	addi	a0,a0,218 # 80018dc8 <disk+0x128>
    80004cf6:	3ad000ef          	jal	ra,800058a2 <release>
}
    80004cfa:	70e6                	ld	ra,120(sp)
    80004cfc:	7446                	ld	s0,112(sp)
    80004cfe:	74a6                	ld	s1,104(sp)
    80004d00:	7906                	ld	s2,96(sp)
    80004d02:	69e6                	ld	s3,88(sp)
    80004d04:	6a46                	ld	s4,80(sp)
    80004d06:	6aa6                	ld	s5,72(sp)
    80004d08:	6b06                	ld	s6,64(sp)
    80004d0a:	7be2                	ld	s7,56(sp)
    80004d0c:	7c42                	ld	s8,48(sp)
    80004d0e:	7ca2                	ld	s9,40(sp)
    80004d10:	7d02                	ld	s10,32(sp)
    80004d12:	6de2                	ld	s11,24(sp)
    80004d14:	6109                	addi	sp,sp,128
    80004d16:	8082                	ret

0000000080004d18 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80004d18:	1101                	addi	sp,sp,-32
    80004d1a:	ec06                	sd	ra,24(sp)
    80004d1c:	e822                	sd	s0,16(sp)
    80004d1e:	e426                	sd	s1,8(sp)
    80004d20:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80004d22:	00014497          	auipc	s1,0x14
    80004d26:	f7e48493          	addi	s1,s1,-130 # 80018ca0 <disk>
    80004d2a:	00014517          	auipc	a0,0x14
    80004d2e:	09e50513          	addi	a0,a0,158 # 80018dc8 <disk+0x128>
    80004d32:	2d9000ef          	jal	ra,8000580a <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80004d36:	10001737          	lui	a4,0x10001
    80004d3a:	533c                	lw	a5,96(a4)
    80004d3c:	8b8d                	andi	a5,a5,3
    80004d3e:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80004d40:	0ff0000f          	fence

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80004d44:	689c                	ld	a5,16(s1)
    80004d46:	0204d703          	lhu	a4,32(s1)
    80004d4a:	0027d783          	lhu	a5,2(a5)
    80004d4e:	04f70663          	beq	a4,a5,80004d9a <virtio_disk_intr+0x82>
    __sync_synchronize();
    80004d52:	0ff0000f          	fence
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80004d56:	6898                	ld	a4,16(s1)
    80004d58:	0204d783          	lhu	a5,32(s1)
    80004d5c:	8b9d                	andi	a5,a5,7
    80004d5e:	078e                	slli	a5,a5,0x3
    80004d60:	97ba                	add	a5,a5,a4
    80004d62:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80004d64:	00278713          	addi	a4,a5,2
    80004d68:	0712                	slli	a4,a4,0x4
    80004d6a:	9726                	add	a4,a4,s1
    80004d6c:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    80004d70:	e321                	bnez	a4,80004db0 <virtio_disk_intr+0x98>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80004d72:	0789                	addi	a5,a5,2
    80004d74:	0792                	slli	a5,a5,0x4
    80004d76:	97a6                	add	a5,a5,s1
    80004d78:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80004d7a:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80004d7e:	f26fc0ef          	jal	ra,800014a4 <wakeup>

    disk.used_idx += 1;
    80004d82:	0204d783          	lhu	a5,32(s1)
    80004d86:	2785                	addiw	a5,a5,1
    80004d88:	17c2                	slli	a5,a5,0x30
    80004d8a:	93c1                	srli	a5,a5,0x30
    80004d8c:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80004d90:	6898                	ld	a4,16(s1)
    80004d92:	00275703          	lhu	a4,2(a4)
    80004d96:	faf71ee3          	bne	a4,a5,80004d52 <virtio_disk_intr+0x3a>
  }

  release(&disk.vdisk_lock);
    80004d9a:	00014517          	auipc	a0,0x14
    80004d9e:	02e50513          	addi	a0,a0,46 # 80018dc8 <disk+0x128>
    80004da2:	301000ef          	jal	ra,800058a2 <release>
}
    80004da6:	60e2                	ld	ra,24(sp)
    80004da8:	6442                	ld	s0,16(sp)
    80004daa:	64a2                	ld	s1,8(sp)
    80004dac:	6105                	addi	sp,sp,32
    80004dae:	8082                	ret
      panic("virtio_disk_intr status");
    80004db0:	00003517          	auipc	a0,0x3
    80004db4:	ae850513          	addi	a0,a0,-1304 # 80007898 <syscalls+0x440>
    80004db8:	73e000ef          	jal	ra,800054f6 <panic>

0000000080004dbc <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    80004dbc:	1141                	addi	sp,sp,-16
    80004dbe:	e422                	sd	s0,8(sp)
    80004dc0:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mie" : "=r" (x) );
    80004dc2:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80004dc6:	0207e793          	ori	a5,a5,32
  asm volatile("csrw mie, %0" : : "r" (x));
    80004dca:	30479073          	csrw	mie,a5
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80004dce:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80004dd2:	577d                	li	a4,-1
    80004dd4:	177e                	slli	a4,a4,0x3f
    80004dd6:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80004dd8:	30a79073          	csrw	0x30a,a5
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    80004ddc:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80004de0:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80004de4:	30679073          	csrw	mcounteren,a5
  asm volatile("csrr %0, time" : "=r" (x) );
    80004de8:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80004dec:	000f4737          	lui	a4,0xf4
    80004df0:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80004df4:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80004df6:	14d79073          	csrw	0x14d,a5
}
    80004dfa:	6422                	ld	s0,8(sp)
    80004dfc:	0141                	addi	sp,sp,16
    80004dfe:	8082                	ret

0000000080004e00 <start>:
{
    80004e00:	1141                	addi	sp,sp,-16
    80004e02:	e406                	sd	ra,8(sp)
    80004e04:	e022                	sd	s0,0(sp)
    80004e06:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80004e08:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80004e0c:	7779                	lui	a4,0xffffe
    80004e0e:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdd91f>
    80004e12:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80004e14:	6705                	lui	a4,0x1
    80004e16:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80004e1a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80004e1c:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80004e20:	ffffb797          	auipc	a5,0xffffb
    80004e24:	4ce78793          	addi	a5,a5,1230 # 800002ee <main>
    80004e28:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80004e2c:	4781                	li	a5,0
    80004e2e:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80004e32:	67c1                	lui	a5,0x10
    80004e34:	17fd                	addi	a5,a5,-1
    80004e36:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    80004e3a:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    80004e3e:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    80004e42:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    80004e46:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    80004e4a:	57fd                	li	a5,-1
    80004e4c:	83a9                	srli	a5,a5,0xa
    80004e4e:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    80004e52:	47bd                	li	a5,15
    80004e54:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    80004e58:	f65ff0ef          	jal	ra,80004dbc <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80004e5c:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    80004e60:	2781                	sext.w	a5,a5
  asm volatile("mv tp, %0" : : "r" (x));
    80004e62:	823e                	mv	tp,a5
  asm volatile("mret");
    80004e64:	30200073          	mret
}
    80004e68:	60a2                	ld	ra,8(sp)
    80004e6a:	6402                	ld	s0,0(sp)
    80004e6c:	0141                	addi	sp,sp,16
    80004e6e:	8082                	ret

0000000080004e70 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    80004e70:	715d                	addi	sp,sp,-80
    80004e72:	e486                	sd	ra,72(sp)
    80004e74:	e0a2                	sd	s0,64(sp)
    80004e76:	fc26                	sd	s1,56(sp)
    80004e78:	f84a                	sd	s2,48(sp)
    80004e7a:	f44e                	sd	s3,40(sp)
    80004e7c:	f052                	sd	s4,32(sp)
    80004e7e:	ec56                	sd	s5,24(sp)
    80004e80:	0880                	addi	s0,sp,80
  int i;

  for(i = 0; i < n; i++){
    80004e82:	04c05263          	blez	a2,80004ec6 <consolewrite+0x56>
    80004e86:	8a2a                	mv	s4,a0
    80004e88:	84ae                	mv	s1,a1
    80004e8a:	89b2                	mv	s3,a2
    80004e8c:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    80004e8e:	5afd                	li	s5,-1
    80004e90:	4685                	li	a3,1
    80004e92:	8626                	mv	a2,s1
    80004e94:	85d2                	mv	a1,s4
    80004e96:	fbf40513          	addi	a0,s0,-65
    80004e9a:	965fc0ef          	jal	ra,800017fe <either_copyin>
    80004e9e:	01550a63          	beq	a0,s5,80004eb2 <consolewrite+0x42>
      break;
    uartputc(c);
    80004ea2:	fbf44503          	lbu	a0,-65(s0)
    80004ea6:	7da000ef          	jal	ra,80005680 <uartputc>
  for(i = 0; i < n; i++){
    80004eaa:	2905                	addiw	s2,s2,1
    80004eac:	0485                	addi	s1,s1,1
    80004eae:	ff2991e3          	bne	s3,s2,80004e90 <consolewrite+0x20>
  }

  return i;
}
    80004eb2:	854a                	mv	a0,s2
    80004eb4:	60a6                	ld	ra,72(sp)
    80004eb6:	6406                	ld	s0,64(sp)
    80004eb8:	74e2                	ld	s1,56(sp)
    80004eba:	7942                	ld	s2,48(sp)
    80004ebc:	79a2                	ld	s3,40(sp)
    80004ebe:	7a02                	ld	s4,32(sp)
    80004ec0:	6ae2                	ld	s5,24(sp)
    80004ec2:	6161                	addi	sp,sp,80
    80004ec4:	8082                	ret
  for(i = 0; i < n; i++){
    80004ec6:	4901                	li	s2,0
    80004ec8:	b7ed                	j	80004eb2 <consolewrite+0x42>

0000000080004eca <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80004eca:	7159                	addi	sp,sp,-112
    80004ecc:	f486                	sd	ra,104(sp)
    80004ece:	f0a2                	sd	s0,96(sp)
    80004ed0:	eca6                	sd	s1,88(sp)
    80004ed2:	e8ca                	sd	s2,80(sp)
    80004ed4:	e4ce                	sd	s3,72(sp)
    80004ed6:	e0d2                	sd	s4,64(sp)
    80004ed8:	fc56                	sd	s5,56(sp)
    80004eda:	f85a                	sd	s6,48(sp)
    80004edc:	f45e                	sd	s7,40(sp)
    80004ede:	f062                	sd	s8,32(sp)
    80004ee0:	ec66                	sd	s9,24(sp)
    80004ee2:	e86a                	sd	s10,16(sp)
    80004ee4:	1880                	addi	s0,sp,112
    80004ee6:	8aaa                	mv	s5,a0
    80004ee8:	8a2e                	mv	s4,a1
    80004eea:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80004eec:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    80004ef0:	0001c517          	auipc	a0,0x1c
    80004ef4:	ef050513          	addi	a0,a0,-272 # 80020de0 <cons>
    80004ef8:	113000ef          	jal	ra,8000580a <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80004efc:	0001c497          	auipc	s1,0x1c
    80004f00:	ee448493          	addi	s1,s1,-284 # 80020de0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80004f04:	0001c917          	auipc	s2,0x1c
    80004f08:	f7490913          	addi	s2,s2,-140 # 80020e78 <cons+0x98>
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];

    if(c == C('D')){  // end-of-file
    80004f0c:	4b91                	li	s7,4
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80004f0e:	5c7d                	li	s8,-1
      break;

    dst++;
    --n;

    if(c == '\n'){
    80004f10:	4ca9                	li	s9,10
  while(n > 0){
    80004f12:	07305363          	blez	s3,80004f78 <consoleread+0xae>
    while(cons.r == cons.w){
    80004f16:	0984a783          	lw	a5,152(s1)
    80004f1a:	09c4a703          	lw	a4,156(s1)
    80004f1e:	02f71163          	bne	a4,a5,80004f40 <consoleread+0x76>
      if(killed(myproc())){
    80004f22:	ee1fb0ef          	jal	ra,80000e02 <myproc>
    80004f26:	f6afc0ef          	jal	ra,80001690 <killed>
    80004f2a:	e125                	bnez	a0,80004f8a <consoleread+0xc0>
      sleep(&cons.r, &cons.lock);
    80004f2c:	85a6                	mv	a1,s1
    80004f2e:	854a                	mv	a0,s2
    80004f30:	d28fc0ef          	jal	ra,80001458 <sleep>
    while(cons.r == cons.w){
    80004f34:	0984a783          	lw	a5,152(s1)
    80004f38:	09c4a703          	lw	a4,156(s1)
    80004f3c:	fef703e3          	beq	a4,a5,80004f22 <consoleread+0x58>
    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    80004f40:	0017871b          	addiw	a4,a5,1
    80004f44:	08e4ac23          	sw	a4,152(s1)
    80004f48:	07f7f713          	andi	a4,a5,127
    80004f4c:	9726                	add	a4,a4,s1
    80004f4e:	01874703          	lbu	a4,24(a4)
    80004f52:	00070d1b          	sext.w	s10,a4
    if(c == C('D')){  // end-of-file
    80004f56:	057d0f63          	beq	s10,s7,80004fb4 <consoleread+0xea>
    cbuf = c;
    80004f5a:	f8e40fa3          	sb	a4,-97(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80004f5e:	4685                	li	a3,1
    80004f60:	f9f40613          	addi	a2,s0,-97
    80004f64:	85d2                	mv	a1,s4
    80004f66:	8556                	mv	a0,s5
    80004f68:	84dfc0ef          	jal	ra,800017b4 <either_copyout>
    80004f6c:	01850663          	beq	a0,s8,80004f78 <consoleread+0xae>
    dst++;
    80004f70:	0a05                	addi	s4,s4,1
    --n;
    80004f72:	39fd                	addiw	s3,s3,-1
    if(c == '\n'){
    80004f74:	f99d1fe3          	bne	s10,s9,80004f12 <consoleread+0x48>
      // a whole line has arrived, return to
      // the user-level read().
      break;
    }
  }
  release(&cons.lock);
    80004f78:	0001c517          	auipc	a0,0x1c
    80004f7c:	e6850513          	addi	a0,a0,-408 # 80020de0 <cons>
    80004f80:	123000ef          	jal	ra,800058a2 <release>

  return target - n;
    80004f84:	413b053b          	subw	a0,s6,s3
    80004f88:	a801                	j	80004f98 <consoleread+0xce>
        release(&cons.lock);
    80004f8a:	0001c517          	auipc	a0,0x1c
    80004f8e:	e5650513          	addi	a0,a0,-426 # 80020de0 <cons>
    80004f92:	111000ef          	jal	ra,800058a2 <release>
        return -1;
    80004f96:	557d                	li	a0,-1
}
    80004f98:	70a6                	ld	ra,104(sp)
    80004f9a:	7406                	ld	s0,96(sp)
    80004f9c:	64e6                	ld	s1,88(sp)
    80004f9e:	6946                	ld	s2,80(sp)
    80004fa0:	69a6                	ld	s3,72(sp)
    80004fa2:	6a06                	ld	s4,64(sp)
    80004fa4:	7ae2                	ld	s5,56(sp)
    80004fa6:	7b42                	ld	s6,48(sp)
    80004fa8:	7ba2                	ld	s7,40(sp)
    80004faa:	7c02                	ld	s8,32(sp)
    80004fac:	6ce2                	ld	s9,24(sp)
    80004fae:	6d42                	ld	s10,16(sp)
    80004fb0:	6165                	addi	sp,sp,112
    80004fb2:	8082                	ret
      if(n < target){
    80004fb4:	0009871b          	sext.w	a4,s3
    80004fb8:	fd6770e3          	bgeu	a4,s6,80004f78 <consoleread+0xae>
        cons.r--;
    80004fbc:	0001c717          	auipc	a4,0x1c
    80004fc0:	eaf72e23          	sw	a5,-324(a4) # 80020e78 <cons+0x98>
    80004fc4:	bf55                	j	80004f78 <consoleread+0xae>

0000000080004fc6 <consputc>:
{
    80004fc6:	1141                	addi	sp,sp,-16
    80004fc8:	e406                	sd	ra,8(sp)
    80004fca:	e022                	sd	s0,0(sp)
    80004fcc:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80004fce:	10000793          	li	a5,256
    80004fd2:	00f50863          	beq	a0,a5,80004fe2 <consputc+0x1c>
    uartputc_sync(c);
    80004fd6:	5d4000ef          	jal	ra,800055aa <uartputc_sync>
}
    80004fda:	60a2                	ld	ra,8(sp)
    80004fdc:	6402                	ld	s0,0(sp)
    80004fde:	0141                	addi	sp,sp,16
    80004fe0:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80004fe2:	4521                	li	a0,8
    80004fe4:	5c6000ef          	jal	ra,800055aa <uartputc_sync>
    80004fe8:	02000513          	li	a0,32
    80004fec:	5be000ef          	jal	ra,800055aa <uartputc_sync>
    80004ff0:	4521                	li	a0,8
    80004ff2:	5b8000ef          	jal	ra,800055aa <uartputc_sync>
    80004ff6:	b7d5                	j	80004fda <consputc+0x14>

0000000080004ff8 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    80004ff8:	1101                	addi	sp,sp,-32
    80004ffa:	ec06                	sd	ra,24(sp)
    80004ffc:	e822                	sd	s0,16(sp)
    80004ffe:	e426                	sd	s1,8(sp)
    80005000:	e04a                	sd	s2,0(sp)
    80005002:	1000                	addi	s0,sp,32
    80005004:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    80005006:	0001c517          	auipc	a0,0x1c
    8000500a:	dda50513          	addi	a0,a0,-550 # 80020de0 <cons>
    8000500e:	7fc000ef          	jal	ra,8000580a <acquire>

  switch(c){
    80005012:	47d5                	li	a5,21
    80005014:	0af48063          	beq	s1,a5,800050b4 <consoleintr+0xbc>
    80005018:	0297c663          	blt	a5,s1,80005044 <consoleintr+0x4c>
    8000501c:	47a1                	li	a5,8
    8000501e:	0cf48f63          	beq	s1,a5,800050fc <consoleintr+0x104>
    80005022:	47c1                	li	a5,16
    80005024:	10f49063          	bne	s1,a5,80005124 <consoleintr+0x12c>
  case C('P'):  // Print process list.
    procdump();
    80005028:	821fc0ef          	jal	ra,80001848 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    8000502c:	0001c517          	auipc	a0,0x1c
    80005030:	db450513          	addi	a0,a0,-588 # 80020de0 <cons>
    80005034:	06f000ef          	jal	ra,800058a2 <release>
}
    80005038:	60e2                	ld	ra,24(sp)
    8000503a:	6442                	ld	s0,16(sp)
    8000503c:	64a2                	ld	s1,8(sp)
    8000503e:	6902                	ld	s2,0(sp)
    80005040:	6105                	addi	sp,sp,32
    80005042:	8082                	ret
  switch(c){
    80005044:	07f00793          	li	a5,127
    80005048:	0af48a63          	beq	s1,a5,800050fc <consoleintr+0x104>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    8000504c:	0001c717          	auipc	a4,0x1c
    80005050:	d9470713          	addi	a4,a4,-620 # 80020de0 <cons>
    80005054:	0a072783          	lw	a5,160(a4)
    80005058:	09872703          	lw	a4,152(a4)
    8000505c:	9f99                	subw	a5,a5,a4
    8000505e:	07f00713          	li	a4,127
    80005062:	fcf765e3          	bltu	a4,a5,8000502c <consoleintr+0x34>
      c = (c == '\r') ? '\n' : c;
    80005066:	47b5                	li	a5,13
    80005068:	0cf48163          	beq	s1,a5,8000512a <consoleintr+0x132>
      consputc(c);
    8000506c:	8526                	mv	a0,s1
    8000506e:	f59ff0ef          	jal	ra,80004fc6 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80005072:	0001c797          	auipc	a5,0x1c
    80005076:	d6e78793          	addi	a5,a5,-658 # 80020de0 <cons>
    8000507a:	0a07a683          	lw	a3,160(a5)
    8000507e:	0016871b          	addiw	a4,a3,1
    80005082:	0007061b          	sext.w	a2,a4
    80005086:	0ae7a023          	sw	a4,160(a5)
    8000508a:	07f6f693          	andi	a3,a3,127
    8000508e:	97b6                	add	a5,a5,a3
    80005090:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80005094:	47a9                	li	a5,10
    80005096:	0af48f63          	beq	s1,a5,80005154 <consoleintr+0x15c>
    8000509a:	4791                	li	a5,4
    8000509c:	0af48c63          	beq	s1,a5,80005154 <consoleintr+0x15c>
    800050a0:	0001c797          	auipc	a5,0x1c
    800050a4:	dd87a783          	lw	a5,-552(a5) # 80020e78 <cons+0x98>
    800050a8:	9f1d                	subw	a4,a4,a5
    800050aa:	08000793          	li	a5,128
    800050ae:	f6f71fe3          	bne	a4,a5,8000502c <consoleintr+0x34>
    800050b2:	a04d                	j	80005154 <consoleintr+0x15c>
    while(cons.e != cons.w &&
    800050b4:	0001c717          	auipc	a4,0x1c
    800050b8:	d2c70713          	addi	a4,a4,-724 # 80020de0 <cons>
    800050bc:	0a072783          	lw	a5,160(a4)
    800050c0:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    800050c4:	0001c497          	auipc	s1,0x1c
    800050c8:	d1c48493          	addi	s1,s1,-740 # 80020de0 <cons>
    while(cons.e != cons.w &&
    800050cc:	4929                	li	s2,10
    800050ce:	f4f70fe3          	beq	a4,a5,8000502c <consoleintr+0x34>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    800050d2:	37fd                	addiw	a5,a5,-1
    800050d4:	07f7f713          	andi	a4,a5,127
    800050d8:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    800050da:	01874703          	lbu	a4,24(a4)
    800050de:	f52707e3          	beq	a4,s2,8000502c <consoleintr+0x34>
      cons.e--;
    800050e2:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    800050e6:	10000513          	li	a0,256
    800050ea:	eddff0ef          	jal	ra,80004fc6 <consputc>
    while(cons.e != cons.w &&
    800050ee:	0a04a783          	lw	a5,160(s1)
    800050f2:	09c4a703          	lw	a4,156(s1)
    800050f6:	fcf71ee3          	bne	a4,a5,800050d2 <consoleintr+0xda>
    800050fa:	bf0d                	j	8000502c <consoleintr+0x34>
    if(cons.e != cons.w){
    800050fc:	0001c717          	auipc	a4,0x1c
    80005100:	ce470713          	addi	a4,a4,-796 # 80020de0 <cons>
    80005104:	0a072783          	lw	a5,160(a4)
    80005108:	09c72703          	lw	a4,156(a4)
    8000510c:	f2f700e3          	beq	a4,a5,8000502c <consoleintr+0x34>
      cons.e--;
    80005110:	37fd                	addiw	a5,a5,-1
    80005112:	0001c717          	auipc	a4,0x1c
    80005116:	d6f72723          	sw	a5,-658(a4) # 80020e80 <cons+0xa0>
      consputc(BACKSPACE);
    8000511a:	10000513          	li	a0,256
    8000511e:	ea9ff0ef          	jal	ra,80004fc6 <consputc>
    80005122:	b729                	j	8000502c <consoleintr+0x34>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80005124:	f00484e3          	beqz	s1,8000502c <consoleintr+0x34>
    80005128:	b715                	j	8000504c <consoleintr+0x54>
      consputc(c);
    8000512a:	4529                	li	a0,10
    8000512c:	e9bff0ef          	jal	ra,80004fc6 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80005130:	0001c797          	auipc	a5,0x1c
    80005134:	cb078793          	addi	a5,a5,-848 # 80020de0 <cons>
    80005138:	0a07a703          	lw	a4,160(a5)
    8000513c:	0017069b          	addiw	a3,a4,1
    80005140:	0006861b          	sext.w	a2,a3
    80005144:	0ad7a023          	sw	a3,160(a5)
    80005148:	07f77713          	andi	a4,a4,127
    8000514c:	97ba                	add	a5,a5,a4
    8000514e:	4729                	li	a4,10
    80005150:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    80005154:	0001c797          	auipc	a5,0x1c
    80005158:	d2c7a423          	sw	a2,-728(a5) # 80020e7c <cons+0x9c>
        wakeup(&cons.r);
    8000515c:	0001c517          	auipc	a0,0x1c
    80005160:	d1c50513          	addi	a0,a0,-740 # 80020e78 <cons+0x98>
    80005164:	b40fc0ef          	jal	ra,800014a4 <wakeup>
    80005168:	b5d1                	j	8000502c <consoleintr+0x34>

000000008000516a <consoleinit>:

void
consoleinit(void)
{
    8000516a:	1141                	addi	sp,sp,-16
    8000516c:	e406                	sd	ra,8(sp)
    8000516e:	e022                	sd	s0,0(sp)
    80005170:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80005172:	00002597          	auipc	a1,0x2
    80005176:	73e58593          	addi	a1,a1,1854 # 800078b0 <syscalls+0x458>
    8000517a:	0001c517          	auipc	a0,0x1c
    8000517e:	c6650513          	addi	a0,a0,-922 # 80020de0 <cons>
    80005182:	608000ef          	jal	ra,8000578a <initlock>

  uartinit();
    80005186:	3d8000ef          	jal	ra,8000555e <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    8000518a:	00013797          	auipc	a5,0x13
    8000518e:	abe78793          	addi	a5,a5,-1346 # 80017c48 <devsw>
    80005192:	00000717          	auipc	a4,0x0
    80005196:	d3870713          	addi	a4,a4,-712 # 80004eca <consoleread>
    8000519a:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    8000519c:	00000717          	auipc	a4,0x0
    800051a0:	cd470713          	addi	a4,a4,-812 # 80004e70 <consolewrite>
    800051a4:	ef98                	sd	a4,24(a5)
}
    800051a6:	60a2                	ld	ra,8(sp)
    800051a8:	6402                	ld	s0,0(sp)
    800051aa:	0141                	addi	sp,sp,16
    800051ac:	8082                	ret

00000000800051ae <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    800051ae:	7179                	addi	sp,sp,-48
    800051b0:	f406                	sd	ra,40(sp)
    800051b2:	f022                	sd	s0,32(sp)
    800051b4:	ec26                	sd	s1,24(sp)
    800051b6:	e84a                	sd	s2,16(sp)
    800051b8:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    800051ba:	c219                	beqz	a2,800051c0 <printint+0x12>
    800051bc:	06054f63          	bltz	a0,8000523a <printint+0x8c>
    x = -xx;
  else
    x = xx;
    800051c0:	4881                	li	a7,0
    800051c2:	fd040693          	addi	a3,s0,-48

  i = 0;
    800051c6:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    800051c8:	00002617          	auipc	a2,0x2
    800051cc:	71060613          	addi	a2,a2,1808 # 800078d8 <digits>
    800051d0:	883e                	mv	a6,a5
    800051d2:	2785                	addiw	a5,a5,1
    800051d4:	02b57733          	remu	a4,a0,a1
    800051d8:	9732                	add	a4,a4,a2
    800051da:	00074703          	lbu	a4,0(a4)
    800051de:	00e68023          	sb	a4,0(a3)
  } while((x /= base) != 0);
    800051e2:	872a                	mv	a4,a0
    800051e4:	02b55533          	divu	a0,a0,a1
    800051e8:	0685                	addi	a3,a3,1
    800051ea:	feb773e3          	bgeu	a4,a1,800051d0 <printint+0x22>

  if(sign)
    800051ee:	00088b63          	beqz	a7,80005204 <printint+0x56>
    buf[i++] = '-';
    800051f2:	fe040713          	addi	a4,s0,-32
    800051f6:	97ba                	add	a5,a5,a4
    800051f8:	02d00713          	li	a4,45
    800051fc:	fee78823          	sb	a4,-16(a5)
    80005200:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
    80005204:	02f05563          	blez	a5,8000522e <printint+0x80>
    80005208:	fd040713          	addi	a4,s0,-48
    8000520c:	00f704b3          	add	s1,a4,a5
    80005210:	fff70913          	addi	s2,a4,-1
    80005214:	993e                	add	s2,s2,a5
    80005216:	37fd                	addiw	a5,a5,-1
    80005218:	1782                	slli	a5,a5,0x20
    8000521a:	9381                	srli	a5,a5,0x20
    8000521c:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    80005220:	fff4c503          	lbu	a0,-1(s1)
    80005224:	da3ff0ef          	jal	ra,80004fc6 <consputc>
  while(--i >= 0)
    80005228:	14fd                	addi	s1,s1,-1
    8000522a:	ff249be3          	bne	s1,s2,80005220 <printint+0x72>
}
    8000522e:	70a2                	ld	ra,40(sp)
    80005230:	7402                	ld	s0,32(sp)
    80005232:	64e2                	ld	s1,24(sp)
    80005234:	6942                	ld	s2,16(sp)
    80005236:	6145                	addi	sp,sp,48
    80005238:	8082                	ret
    x = -xx;
    8000523a:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    8000523e:	4885                	li	a7,1
    x = -xx;
    80005240:	b749                	j	800051c2 <printint+0x14>

0000000080005242 <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    80005242:	7155                	addi	sp,sp,-208
    80005244:	e506                	sd	ra,136(sp)
    80005246:	e122                	sd	s0,128(sp)
    80005248:	fca6                	sd	s1,120(sp)
    8000524a:	f8ca                	sd	s2,112(sp)
    8000524c:	f4ce                	sd	s3,104(sp)
    8000524e:	f0d2                	sd	s4,96(sp)
    80005250:	ecd6                	sd	s5,88(sp)
    80005252:	e8da                	sd	s6,80(sp)
    80005254:	e4de                	sd	s7,72(sp)
    80005256:	e0e2                	sd	s8,64(sp)
    80005258:	fc66                	sd	s9,56(sp)
    8000525a:	f86a                	sd	s10,48(sp)
    8000525c:	f46e                	sd	s11,40(sp)
    8000525e:	0900                	addi	s0,sp,144
    80005260:	8a2a                	mv	s4,a0
    80005262:	e40c                	sd	a1,8(s0)
    80005264:	e810                	sd	a2,16(s0)
    80005266:	ec14                	sd	a3,24(s0)
    80005268:	f018                	sd	a4,32(s0)
    8000526a:	f41c                	sd	a5,40(s0)
    8000526c:	03043823          	sd	a6,48(s0)
    80005270:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2, locking;
  char *s;

  locking = pr.locking;
    80005274:	0001c797          	auipc	a5,0x1c
    80005278:	c2c7a783          	lw	a5,-980(a5) # 80020ea0 <pr+0x18>
    8000527c:	f6f43c23          	sd	a5,-136(s0)
  if(locking)
    80005280:	eb9d                	bnez	a5,800052b6 <printf+0x74>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80005282:	00840793          	addi	a5,s0,8
    80005286:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000528a:	00054503          	lbu	a0,0(a0)
    8000528e:	24050463          	beqz	a0,800054d6 <printf+0x294>
    80005292:	4981                	li	s3,0
    if(cx != '%'){
    80005294:	02500a93          	li	s5,37
    i++;
    c0 = fmt[i+0] & 0xff;
    c1 = c2 = 0;
    if(c0) c1 = fmt[i+1] & 0xff;
    if(c1) c2 = fmt[i+2] & 0xff;
    if(c0 == 'd'){
    80005298:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if(c0 == 'l' && c1 == 'd'){
    8000529c:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    800052a0:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    800052a4:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    800052a8:	07000d93          	li	s11,112
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800052ac:	00002b97          	auipc	s7,0x2
    800052b0:	62cb8b93          	addi	s7,s7,1580 # 800078d8 <digits>
    800052b4:	a081                	j	800052f4 <printf+0xb2>
    acquire(&pr.lock);
    800052b6:	0001c517          	auipc	a0,0x1c
    800052ba:	bd250513          	addi	a0,a0,-1070 # 80020e88 <pr>
    800052be:	54c000ef          	jal	ra,8000580a <acquire>
  va_start(ap, fmt);
    800052c2:	00840793          	addi	a5,s0,8
    800052c6:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    800052ca:	000a4503          	lbu	a0,0(s4)
    800052ce:	f171                	bnez	a0,80005292 <printf+0x50>
#endif
  }
  va_end(ap);

  if(locking)
    release(&pr.lock);
    800052d0:	0001c517          	auipc	a0,0x1c
    800052d4:	bb850513          	addi	a0,a0,-1096 # 80020e88 <pr>
    800052d8:	5ca000ef          	jal	ra,800058a2 <release>
    800052dc:	aaed                	j	800054d6 <printf+0x294>
      consputc(cx);
    800052de:	ce9ff0ef          	jal	ra,80004fc6 <consputc>
      continue;
    800052e2:	84ce                	mv	s1,s3
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    800052e4:	0014899b          	addiw	s3,s1,1
    800052e8:	013a07b3          	add	a5,s4,s3
    800052ec:	0007c503          	lbu	a0,0(a5)
    800052f0:	1c050f63          	beqz	a0,800054ce <printf+0x28c>
    if(cx != '%'){
    800052f4:	ff5515e3          	bne	a0,s5,800052de <printf+0x9c>
    i++;
    800052f8:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i+0] & 0xff;
    800052fc:	009a07b3          	add	a5,s4,s1
    80005300:	0007c903          	lbu	s2,0(a5)
    if(c0) c1 = fmt[i+1] & 0xff;
    80005304:	1c090563          	beqz	s2,800054ce <printf+0x28c>
    80005308:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    8000530c:	86be                	mv	a3,a5
    if(c1) c2 = fmt[i+2] & 0xff;
    8000530e:	c789                	beqz	a5,80005318 <printf+0xd6>
    80005310:	009a0733          	add	a4,s4,s1
    80005314:	00274683          	lbu	a3,2(a4)
    if(c0 == 'd'){
    80005318:	03690463          	beq	s2,s6,80005340 <printf+0xfe>
    } else if(c0 == 'l' && c1 == 'd'){
    8000531c:	03890e63          	beq	s2,s8,80005358 <printf+0x116>
    } else if(c0 == 'u'){
    80005320:	0b990d63          	beq	s2,s9,800053da <printf+0x198>
    } else if(c0 == 'x'){
    80005324:	11a90363          	beq	s2,s10,8000542a <printf+0x1e8>
    } else if(c0 == 'p'){
    80005328:	13b90b63          	beq	s2,s11,8000545e <printf+0x21c>
    } else if(c0 == 's'){
    8000532c:	07300793          	li	a5,115
    80005330:	16f90363          	beq	s2,a5,80005496 <printf+0x254>
    } else if(c0 == '%'){
    80005334:	03591c63          	bne	s2,s5,8000536c <printf+0x12a>
      consputc('%');
    80005338:	8556                	mv	a0,s5
    8000533a:	c8dff0ef          	jal	ra,80004fc6 <consputc>
    8000533e:	b75d                	j	800052e4 <printf+0xa2>
      printint(va_arg(ap, int), 10, 1);
    80005340:	f8843783          	ld	a5,-120(s0)
    80005344:	00878713          	addi	a4,a5,8
    80005348:	f8e43423          	sd	a4,-120(s0)
    8000534c:	4605                	li	a2,1
    8000534e:	45a9                	li	a1,10
    80005350:	4388                	lw	a0,0(a5)
    80005352:	e5dff0ef          	jal	ra,800051ae <printint>
    80005356:	b779                	j	800052e4 <printf+0xa2>
    } else if(c0 == 'l' && c1 == 'd'){
    80005358:	03678163          	beq	a5,s6,8000537a <printf+0x138>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000535c:	03878d63          	beq	a5,s8,80005396 <printf+0x154>
    } else if(c0 == 'l' && c1 == 'u'){
    80005360:	09978963          	beq	a5,s9,800053f2 <printf+0x1b0>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80005364:	03878b63          	beq	a5,s8,8000539a <printf+0x158>
    } else if(c0 == 'l' && c1 == 'x'){
    80005368:	0da78d63          	beq	a5,s10,80005442 <printf+0x200>
      consputc('%');
    8000536c:	8556                	mv	a0,s5
    8000536e:	c59ff0ef          	jal	ra,80004fc6 <consputc>
      consputc(c0);
    80005372:	854a                	mv	a0,s2
    80005374:	c53ff0ef          	jal	ra,80004fc6 <consputc>
    80005378:	b7b5                	j	800052e4 <printf+0xa2>
      printint(va_arg(ap, uint64), 10, 1);
    8000537a:	f8843783          	ld	a5,-120(s0)
    8000537e:	00878713          	addi	a4,a5,8
    80005382:	f8e43423          	sd	a4,-120(s0)
    80005386:	4605                	li	a2,1
    80005388:	45a9                	li	a1,10
    8000538a:	6388                	ld	a0,0(a5)
    8000538c:	e23ff0ef          	jal	ra,800051ae <printint>
      i += 1;
    80005390:	0029849b          	addiw	s1,s3,2
    80005394:	bf81                	j	800052e4 <printf+0xa2>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    80005396:	03668463          	beq	a3,s6,800053be <printf+0x17c>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    8000539a:	07968a63          	beq	a3,s9,8000540e <printf+0x1cc>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    8000539e:	fda697e3          	bne	a3,s10,8000536c <printf+0x12a>
      printint(va_arg(ap, uint64), 16, 0);
    800053a2:	f8843783          	ld	a5,-120(s0)
    800053a6:	00878713          	addi	a4,a5,8
    800053aa:	f8e43423          	sd	a4,-120(s0)
    800053ae:	4601                	li	a2,0
    800053b0:	45c1                	li	a1,16
    800053b2:	6388                	ld	a0,0(a5)
    800053b4:	dfbff0ef          	jal	ra,800051ae <printint>
      i += 2;
    800053b8:	0039849b          	addiw	s1,s3,3
    800053bc:	b725                	j	800052e4 <printf+0xa2>
      printint(va_arg(ap, uint64), 10, 1);
    800053be:	f8843783          	ld	a5,-120(s0)
    800053c2:	00878713          	addi	a4,a5,8
    800053c6:	f8e43423          	sd	a4,-120(s0)
    800053ca:	4605                	li	a2,1
    800053cc:	45a9                	li	a1,10
    800053ce:	6388                	ld	a0,0(a5)
    800053d0:	ddfff0ef          	jal	ra,800051ae <printint>
      i += 2;
    800053d4:	0039849b          	addiw	s1,s3,3
    800053d8:	b731                	j	800052e4 <printf+0xa2>
      printint(va_arg(ap, int), 10, 0);
    800053da:	f8843783          	ld	a5,-120(s0)
    800053de:	00878713          	addi	a4,a5,8
    800053e2:	f8e43423          	sd	a4,-120(s0)
    800053e6:	4601                	li	a2,0
    800053e8:	45a9                	li	a1,10
    800053ea:	4388                	lw	a0,0(a5)
    800053ec:	dc3ff0ef          	jal	ra,800051ae <printint>
    800053f0:	bdd5                	j	800052e4 <printf+0xa2>
      printint(va_arg(ap, uint64), 10, 0);
    800053f2:	f8843783          	ld	a5,-120(s0)
    800053f6:	00878713          	addi	a4,a5,8
    800053fa:	f8e43423          	sd	a4,-120(s0)
    800053fe:	4601                	li	a2,0
    80005400:	45a9                	li	a1,10
    80005402:	6388                	ld	a0,0(a5)
    80005404:	dabff0ef          	jal	ra,800051ae <printint>
      i += 1;
    80005408:	0029849b          	addiw	s1,s3,2
    8000540c:	bde1                	j	800052e4 <printf+0xa2>
      printint(va_arg(ap, uint64), 10, 0);
    8000540e:	f8843783          	ld	a5,-120(s0)
    80005412:	00878713          	addi	a4,a5,8
    80005416:	f8e43423          	sd	a4,-120(s0)
    8000541a:	4601                	li	a2,0
    8000541c:	45a9                	li	a1,10
    8000541e:	6388                	ld	a0,0(a5)
    80005420:	d8fff0ef          	jal	ra,800051ae <printint>
      i += 2;
    80005424:	0039849b          	addiw	s1,s3,3
    80005428:	bd75                	j	800052e4 <printf+0xa2>
      printint(va_arg(ap, int), 16, 0);
    8000542a:	f8843783          	ld	a5,-120(s0)
    8000542e:	00878713          	addi	a4,a5,8
    80005432:	f8e43423          	sd	a4,-120(s0)
    80005436:	4601                	li	a2,0
    80005438:	45c1                	li	a1,16
    8000543a:	4388                	lw	a0,0(a5)
    8000543c:	d73ff0ef          	jal	ra,800051ae <printint>
    80005440:	b555                	j	800052e4 <printf+0xa2>
      printint(va_arg(ap, uint64), 16, 0);
    80005442:	f8843783          	ld	a5,-120(s0)
    80005446:	00878713          	addi	a4,a5,8
    8000544a:	f8e43423          	sd	a4,-120(s0)
    8000544e:	4601                	li	a2,0
    80005450:	45c1                	li	a1,16
    80005452:	6388                	ld	a0,0(a5)
    80005454:	d5bff0ef          	jal	ra,800051ae <printint>
      i += 1;
    80005458:	0029849b          	addiw	s1,s3,2
    8000545c:	b561                	j	800052e4 <printf+0xa2>
      printptr(va_arg(ap, uint64));
    8000545e:	f8843783          	ld	a5,-120(s0)
    80005462:	00878713          	addi	a4,a5,8
    80005466:	f8e43423          	sd	a4,-120(s0)
    8000546a:	0007b983          	ld	s3,0(a5)
  consputc('0');
    8000546e:	03000513          	li	a0,48
    80005472:	b55ff0ef          	jal	ra,80004fc6 <consputc>
  consputc('x');
    80005476:	856a                	mv	a0,s10
    80005478:	b4fff0ef          	jal	ra,80004fc6 <consputc>
    8000547c:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    8000547e:	03c9d793          	srli	a5,s3,0x3c
    80005482:	97de                	add	a5,a5,s7
    80005484:	0007c503          	lbu	a0,0(a5)
    80005488:	b3fff0ef          	jal	ra,80004fc6 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    8000548c:	0992                	slli	s3,s3,0x4
    8000548e:	397d                	addiw	s2,s2,-1
    80005490:	fe0917e3          	bnez	s2,8000547e <printf+0x23c>
    80005494:	bd81                	j	800052e4 <printf+0xa2>
      if((s = va_arg(ap, char*)) == 0)
    80005496:	f8843783          	ld	a5,-120(s0)
    8000549a:	00878713          	addi	a4,a5,8
    8000549e:	f8e43423          	sd	a4,-120(s0)
    800054a2:	0007b903          	ld	s2,0(a5)
    800054a6:	00090d63          	beqz	s2,800054c0 <printf+0x27e>
      for(; *s; s++)
    800054aa:	00094503          	lbu	a0,0(s2)
    800054ae:	e2050be3          	beqz	a0,800052e4 <printf+0xa2>
        consputc(*s);
    800054b2:	b15ff0ef          	jal	ra,80004fc6 <consputc>
      for(; *s; s++)
    800054b6:	0905                	addi	s2,s2,1
    800054b8:	00094503          	lbu	a0,0(s2)
    800054bc:	f97d                	bnez	a0,800054b2 <printf+0x270>
    800054be:	b51d                	j	800052e4 <printf+0xa2>
        s = "(null)";
    800054c0:	00002917          	auipc	s2,0x2
    800054c4:	3f890913          	addi	s2,s2,1016 # 800078b8 <syscalls+0x460>
      for(; *s; s++)
    800054c8:	02800513          	li	a0,40
    800054cc:	b7dd                	j	800054b2 <printf+0x270>
  if(locking)
    800054ce:	f7843783          	ld	a5,-136(s0)
    800054d2:	de079fe3          	bnez	a5,800052d0 <printf+0x8e>

  return 0;
}
    800054d6:	4501                	li	a0,0
    800054d8:	60aa                	ld	ra,136(sp)
    800054da:	640a                	ld	s0,128(sp)
    800054dc:	74e6                	ld	s1,120(sp)
    800054de:	7946                	ld	s2,112(sp)
    800054e0:	79a6                	ld	s3,104(sp)
    800054e2:	7a06                	ld	s4,96(sp)
    800054e4:	6ae6                	ld	s5,88(sp)
    800054e6:	6b46                	ld	s6,80(sp)
    800054e8:	6ba6                	ld	s7,72(sp)
    800054ea:	6c06                	ld	s8,64(sp)
    800054ec:	7ce2                	ld	s9,56(sp)
    800054ee:	7d42                	ld	s10,48(sp)
    800054f0:	7da2                	ld	s11,40(sp)
    800054f2:	6169                	addi	sp,sp,208
    800054f4:	8082                	ret

00000000800054f6 <panic>:

void
panic(char *s)
{
    800054f6:	1101                	addi	sp,sp,-32
    800054f8:	ec06                	sd	ra,24(sp)
    800054fa:	e822                	sd	s0,16(sp)
    800054fc:	e426                	sd	s1,8(sp)
    800054fe:	1000                	addi	s0,sp,32
    80005500:	84aa                	mv	s1,a0
  pr.locking = 0;
    80005502:	0001c797          	auipc	a5,0x1c
    80005506:	9807af23          	sw	zero,-1634(a5) # 80020ea0 <pr+0x18>
  printf("panic: ");
    8000550a:	00002517          	auipc	a0,0x2
    8000550e:	3b650513          	addi	a0,a0,950 # 800078c0 <syscalls+0x468>
    80005512:	d31ff0ef          	jal	ra,80005242 <printf>
  printf("%s\n", s);
    80005516:	85a6                	mv	a1,s1
    80005518:	00002517          	auipc	a0,0x2
    8000551c:	3b050513          	addi	a0,a0,944 # 800078c8 <syscalls+0x470>
    80005520:	d23ff0ef          	jal	ra,80005242 <printf>
  panicked = 1; // freeze uart output from other CPUs
    80005524:	4785                	li	a5,1
    80005526:	00002717          	auipc	a4,0x2
    8000552a:	46f72b23          	sw	a5,1142(a4) # 8000799c <panicked>
  for(;;)
    8000552e:	a001                	j	8000552e <panic+0x38>

0000000080005530 <printfinit>:
    ;
}

void
printfinit(void)
{
    80005530:	1101                	addi	sp,sp,-32
    80005532:	ec06                	sd	ra,24(sp)
    80005534:	e822                	sd	s0,16(sp)
    80005536:	e426                	sd	s1,8(sp)
    80005538:	1000                	addi	s0,sp,32
  initlock(&pr.lock, "pr");
    8000553a:	0001c497          	auipc	s1,0x1c
    8000553e:	94e48493          	addi	s1,s1,-1714 # 80020e88 <pr>
    80005542:	00002597          	auipc	a1,0x2
    80005546:	38e58593          	addi	a1,a1,910 # 800078d0 <syscalls+0x478>
    8000554a:	8526                	mv	a0,s1
    8000554c:	23e000ef          	jal	ra,8000578a <initlock>
  pr.locking = 1;
    80005550:	4785                	li	a5,1
    80005552:	cc9c                	sw	a5,24(s1)
}
    80005554:	60e2                	ld	ra,24(sp)
    80005556:	6442                	ld	s0,16(sp)
    80005558:	64a2                	ld	s1,8(sp)
    8000555a:	6105                	addi	sp,sp,32
    8000555c:	8082                	ret

000000008000555e <uartinit>:

void uartstart();

void
uartinit(void)
{
    8000555e:	1141                	addi	sp,sp,-16
    80005560:	e406                	sd	ra,8(sp)
    80005562:	e022                	sd	s0,0(sp)
    80005564:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80005566:	100007b7          	lui	a5,0x10000
    8000556a:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    8000556e:	f8000713          	li	a4,-128
    80005572:	00e781a3          	sb	a4,3(a5)

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80005576:	470d                	li	a4,3
    80005578:	00e78023          	sb	a4,0(a5)

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    8000557c:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80005580:	00e781a3          	sb	a4,3(a5)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80005584:	469d                	li	a3,7
    80005586:	00d78123          	sb	a3,2(a5)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    8000558a:	00e780a3          	sb	a4,1(a5)

  initlock(&uart_tx_lock, "uart");
    8000558e:	00002597          	auipc	a1,0x2
    80005592:	36258593          	addi	a1,a1,866 # 800078f0 <digits+0x18>
    80005596:	0001c517          	auipc	a0,0x1c
    8000559a:	91250513          	addi	a0,a0,-1774 # 80020ea8 <uart_tx_lock>
    8000559e:	1ec000ef          	jal	ra,8000578a <initlock>
}
    800055a2:	60a2                	ld	ra,8(sp)
    800055a4:	6402                	ld	s0,0(sp)
    800055a6:	0141                	addi	sp,sp,16
    800055a8:	8082                	ret

00000000800055aa <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    800055aa:	1101                	addi	sp,sp,-32
    800055ac:	ec06                	sd	ra,24(sp)
    800055ae:	e822                	sd	s0,16(sp)
    800055b0:	e426                	sd	s1,8(sp)
    800055b2:	1000                	addi	s0,sp,32
    800055b4:	84aa                	mv	s1,a0
  push_off();
    800055b6:	214000ef          	jal	ra,800057ca <push_off>

  if(panicked){
    800055ba:	00002797          	auipc	a5,0x2
    800055be:	3e27a783          	lw	a5,994(a5) # 8000799c <panicked>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800055c2:	10000737          	lui	a4,0x10000
  if(panicked){
    800055c6:	c391                	beqz	a5,800055ca <uartputc_sync+0x20>
    for(;;)
    800055c8:	a001                	j	800055c8 <uartputc_sync+0x1e>
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800055ca:	00574783          	lbu	a5,5(a4) # 10000005 <_entry-0x6ffffffb>
    800055ce:	0207f793          	andi	a5,a5,32
    800055d2:	dfe5                	beqz	a5,800055ca <uartputc_sync+0x20>
    ;
  WriteReg(THR, c);
    800055d4:	0ff4f513          	zext.b	a0,s1
    800055d8:	100007b7          	lui	a5,0x10000
    800055dc:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    800055e0:	26e000ef          	jal	ra,8000584e <pop_off>
}
    800055e4:	60e2                	ld	ra,24(sp)
    800055e6:	6442                	ld	s0,16(sp)
    800055e8:	64a2                	ld	s1,8(sp)
    800055ea:	6105                	addi	sp,sp,32
    800055ec:	8082                	ret

00000000800055ee <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    800055ee:	00002797          	auipc	a5,0x2
    800055f2:	3b27b783          	ld	a5,946(a5) # 800079a0 <uart_tx_r>
    800055f6:	00002717          	auipc	a4,0x2
    800055fa:	3b273703          	ld	a4,946(a4) # 800079a8 <uart_tx_w>
    800055fe:	06f70c63          	beq	a4,a5,80005676 <uartstart+0x88>
{
    80005602:	7139                	addi	sp,sp,-64
    80005604:	fc06                	sd	ra,56(sp)
    80005606:	f822                	sd	s0,48(sp)
    80005608:	f426                	sd	s1,40(sp)
    8000560a:	f04a                	sd	s2,32(sp)
    8000560c:	ec4e                	sd	s3,24(sp)
    8000560e:	e852                	sd	s4,16(sp)
    80005610:	e456                	sd	s5,8(sp)
    80005612:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      ReadReg(ISR);
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80005614:	10000937          	lui	s2,0x10000
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80005618:	0001ca17          	auipc	s4,0x1c
    8000561c:	890a0a13          	addi	s4,s4,-1904 # 80020ea8 <uart_tx_lock>
    uart_tx_r += 1;
    80005620:	00002497          	auipc	s1,0x2
    80005624:	38048493          	addi	s1,s1,896 # 800079a0 <uart_tx_r>
    if(uart_tx_w == uart_tx_r){
    80005628:	00002997          	auipc	s3,0x2
    8000562c:	38098993          	addi	s3,s3,896 # 800079a8 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80005630:	00594703          	lbu	a4,5(s2) # 10000005 <_entry-0x6ffffffb>
    80005634:	02077713          	andi	a4,a4,32
    80005638:	c715                	beqz	a4,80005664 <uartstart+0x76>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    8000563a:	01f7f713          	andi	a4,a5,31
    8000563e:	9752                	add	a4,a4,s4
    80005640:	01874a83          	lbu	s5,24(a4)
    uart_tx_r += 1;
    80005644:	0785                	addi	a5,a5,1
    80005646:	e09c                	sd	a5,0(s1)
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    80005648:	8526                	mv	a0,s1
    8000564a:	e5bfb0ef          	jal	ra,800014a4 <wakeup>
    
    WriteReg(THR, c);
    8000564e:	01590023          	sb	s5,0(s2)
    if(uart_tx_w == uart_tx_r){
    80005652:	609c                	ld	a5,0(s1)
    80005654:	0009b703          	ld	a4,0(s3)
    80005658:	fcf71ce3          	bne	a4,a5,80005630 <uartstart+0x42>
      ReadReg(ISR);
    8000565c:	100007b7          	lui	a5,0x10000
    80005660:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
  }
}
    80005664:	70e2                	ld	ra,56(sp)
    80005666:	7442                	ld	s0,48(sp)
    80005668:	74a2                	ld	s1,40(sp)
    8000566a:	7902                	ld	s2,32(sp)
    8000566c:	69e2                	ld	s3,24(sp)
    8000566e:	6a42                	ld	s4,16(sp)
    80005670:	6aa2                	ld	s5,8(sp)
    80005672:	6121                	addi	sp,sp,64
    80005674:	8082                	ret
      ReadReg(ISR);
    80005676:	100007b7          	lui	a5,0x10000
    8000567a:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
      return;
    8000567e:	8082                	ret

0000000080005680 <uartputc>:
{
    80005680:	7179                	addi	sp,sp,-48
    80005682:	f406                	sd	ra,40(sp)
    80005684:	f022                	sd	s0,32(sp)
    80005686:	ec26                	sd	s1,24(sp)
    80005688:	e84a                	sd	s2,16(sp)
    8000568a:	e44e                	sd	s3,8(sp)
    8000568c:	e052                	sd	s4,0(sp)
    8000568e:	1800                	addi	s0,sp,48
    80005690:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    80005692:	0001c517          	auipc	a0,0x1c
    80005696:	81650513          	addi	a0,a0,-2026 # 80020ea8 <uart_tx_lock>
    8000569a:	170000ef          	jal	ra,8000580a <acquire>
  if(panicked){
    8000569e:	00002797          	auipc	a5,0x2
    800056a2:	2fe7a783          	lw	a5,766(a5) # 8000799c <panicked>
    800056a6:	efbd                	bnez	a5,80005724 <uartputc+0xa4>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800056a8:	00002717          	auipc	a4,0x2
    800056ac:	30073703          	ld	a4,768(a4) # 800079a8 <uart_tx_w>
    800056b0:	00002797          	auipc	a5,0x2
    800056b4:	2f07b783          	ld	a5,752(a5) # 800079a0 <uart_tx_r>
    800056b8:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    800056bc:	0001b997          	auipc	s3,0x1b
    800056c0:	7ec98993          	addi	s3,s3,2028 # 80020ea8 <uart_tx_lock>
    800056c4:	00002497          	auipc	s1,0x2
    800056c8:	2dc48493          	addi	s1,s1,732 # 800079a0 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800056cc:	00002917          	auipc	s2,0x2
    800056d0:	2dc90913          	addi	s2,s2,732 # 800079a8 <uart_tx_w>
    800056d4:	00e79d63          	bne	a5,a4,800056ee <uartputc+0x6e>
    sleep(&uart_tx_r, &uart_tx_lock);
    800056d8:	85ce                	mv	a1,s3
    800056da:	8526                	mv	a0,s1
    800056dc:	d7dfb0ef          	jal	ra,80001458 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800056e0:	00093703          	ld	a4,0(s2)
    800056e4:	609c                	ld	a5,0(s1)
    800056e6:	02078793          	addi	a5,a5,32
    800056ea:	fee787e3          	beq	a5,a4,800056d8 <uartputc+0x58>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    800056ee:	0001b497          	auipc	s1,0x1b
    800056f2:	7ba48493          	addi	s1,s1,1978 # 80020ea8 <uart_tx_lock>
    800056f6:	01f77793          	andi	a5,a4,31
    800056fa:	97a6                	add	a5,a5,s1
    800056fc:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    80005700:	0705                	addi	a4,a4,1
    80005702:	00002797          	auipc	a5,0x2
    80005706:	2ae7b323          	sd	a4,678(a5) # 800079a8 <uart_tx_w>
  uartstart();
    8000570a:	ee5ff0ef          	jal	ra,800055ee <uartstart>
  release(&uart_tx_lock);
    8000570e:	8526                	mv	a0,s1
    80005710:	192000ef          	jal	ra,800058a2 <release>
}
    80005714:	70a2                	ld	ra,40(sp)
    80005716:	7402                	ld	s0,32(sp)
    80005718:	64e2                	ld	s1,24(sp)
    8000571a:	6942                	ld	s2,16(sp)
    8000571c:	69a2                	ld	s3,8(sp)
    8000571e:	6a02                	ld	s4,0(sp)
    80005720:	6145                	addi	sp,sp,48
    80005722:	8082                	ret
    for(;;)
    80005724:	a001                	j	80005724 <uartputc+0xa4>

0000000080005726 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80005726:	1141                	addi	sp,sp,-16
    80005728:	e422                	sd	s0,8(sp)
    8000572a:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    8000572c:	100007b7          	lui	a5,0x10000
    80005730:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80005734:	8b85                	andi	a5,a5,1
    80005736:	cb91                	beqz	a5,8000574a <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    80005738:	100007b7          	lui	a5,0x10000
    8000573c:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
    80005740:	0ff57513          	zext.b	a0,a0
  } else {
    return -1;
  }
}
    80005744:	6422                	ld	s0,8(sp)
    80005746:	0141                	addi	sp,sp,16
    80005748:	8082                	ret
    return -1;
    8000574a:	557d                	li	a0,-1
    8000574c:	bfe5                	j	80005744 <uartgetc+0x1e>

000000008000574e <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    8000574e:	1101                	addi	sp,sp,-32
    80005750:	ec06                	sd	ra,24(sp)
    80005752:	e822                	sd	s0,16(sp)
    80005754:	e426                	sd	s1,8(sp)
    80005756:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80005758:	54fd                	li	s1,-1
    8000575a:	a019                	j	80005760 <uartintr+0x12>
      break;
    consoleintr(c);
    8000575c:	89dff0ef          	jal	ra,80004ff8 <consoleintr>
    int c = uartgetc();
    80005760:	fc7ff0ef          	jal	ra,80005726 <uartgetc>
    if(c == -1)
    80005764:	fe951ce3          	bne	a0,s1,8000575c <uartintr+0xe>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    80005768:	0001b497          	auipc	s1,0x1b
    8000576c:	74048493          	addi	s1,s1,1856 # 80020ea8 <uart_tx_lock>
    80005770:	8526                	mv	a0,s1
    80005772:	098000ef          	jal	ra,8000580a <acquire>
  uartstart();
    80005776:	e79ff0ef          	jal	ra,800055ee <uartstart>
  release(&uart_tx_lock);
    8000577a:	8526                	mv	a0,s1
    8000577c:	126000ef          	jal	ra,800058a2 <release>
}
    80005780:	60e2                	ld	ra,24(sp)
    80005782:	6442                	ld	s0,16(sp)
    80005784:	64a2                	ld	s1,8(sp)
    80005786:	6105                	addi	sp,sp,32
    80005788:	8082                	ret

000000008000578a <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    8000578a:	1141                	addi	sp,sp,-16
    8000578c:	e422                	sd	s0,8(sp)
    8000578e:	0800                	addi	s0,sp,16
  lk->name = name;
    80005790:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80005792:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80005796:	00053823          	sd	zero,16(a0)
}
    8000579a:	6422                	ld	s0,8(sp)
    8000579c:	0141                	addi	sp,sp,16
    8000579e:	8082                	ret

00000000800057a0 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    800057a0:	411c                	lw	a5,0(a0)
    800057a2:	e399                	bnez	a5,800057a8 <holding+0x8>
    800057a4:	4501                	li	a0,0
  return r;
}
    800057a6:	8082                	ret
{
    800057a8:	1101                	addi	sp,sp,-32
    800057aa:	ec06                	sd	ra,24(sp)
    800057ac:	e822                	sd	s0,16(sp)
    800057ae:	e426                	sd	s1,8(sp)
    800057b0:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    800057b2:	6904                	ld	s1,16(a0)
    800057b4:	e32fb0ef          	jal	ra,80000de6 <mycpu>
    800057b8:	40a48533          	sub	a0,s1,a0
    800057bc:	00153513          	seqz	a0,a0
}
    800057c0:	60e2                	ld	ra,24(sp)
    800057c2:	6442                	ld	s0,16(sp)
    800057c4:	64a2                	ld	s1,8(sp)
    800057c6:	6105                	addi	sp,sp,32
    800057c8:	8082                	ret

00000000800057ca <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    800057ca:	1101                	addi	sp,sp,-32
    800057cc:	ec06                	sd	ra,24(sp)
    800057ce:	e822                	sd	s0,16(sp)
    800057d0:	e426                	sd	s1,8(sp)
    800057d2:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800057d4:	100024f3          	csrr	s1,sstatus
    800057d8:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800057dc:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800057de:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    800057e2:	e04fb0ef          	jal	ra,80000de6 <mycpu>
    800057e6:	5d3c                	lw	a5,120(a0)
    800057e8:	cb99                	beqz	a5,800057fe <push_off+0x34>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    800057ea:	dfcfb0ef          	jal	ra,80000de6 <mycpu>
    800057ee:	5d3c                	lw	a5,120(a0)
    800057f0:	2785                	addiw	a5,a5,1
    800057f2:	dd3c                	sw	a5,120(a0)
}
    800057f4:	60e2                	ld	ra,24(sp)
    800057f6:	6442                	ld	s0,16(sp)
    800057f8:	64a2                	ld	s1,8(sp)
    800057fa:	6105                	addi	sp,sp,32
    800057fc:	8082                	ret
    mycpu()->intena = old;
    800057fe:	de8fb0ef          	jal	ra,80000de6 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80005802:	8085                	srli	s1,s1,0x1
    80005804:	8885                	andi	s1,s1,1
    80005806:	dd64                	sw	s1,124(a0)
    80005808:	b7cd                	j	800057ea <push_off+0x20>

000000008000580a <acquire>:
{
    8000580a:	1101                	addi	sp,sp,-32
    8000580c:	ec06                	sd	ra,24(sp)
    8000580e:	e822                	sd	s0,16(sp)
    80005810:	e426                	sd	s1,8(sp)
    80005812:	1000                	addi	s0,sp,32
    80005814:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80005816:	fb5ff0ef          	jal	ra,800057ca <push_off>
  if(holding(lk))
    8000581a:	8526                	mv	a0,s1
    8000581c:	f85ff0ef          	jal	ra,800057a0 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80005820:	4705                	li	a4,1
  if(holding(lk))
    80005822:	e105                	bnez	a0,80005842 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80005824:	87ba                	mv	a5,a4
    80005826:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    8000582a:	2781                	sext.w	a5,a5
    8000582c:	ffe5                	bnez	a5,80005824 <acquire+0x1a>
  __sync_synchronize();
    8000582e:	0ff0000f          	fence
  lk->cpu = mycpu();
    80005832:	db4fb0ef          	jal	ra,80000de6 <mycpu>
    80005836:	e888                	sd	a0,16(s1)
}
    80005838:	60e2                	ld	ra,24(sp)
    8000583a:	6442                	ld	s0,16(sp)
    8000583c:	64a2                	ld	s1,8(sp)
    8000583e:	6105                	addi	sp,sp,32
    80005840:	8082                	ret
    panic("acquire");
    80005842:	00002517          	auipc	a0,0x2
    80005846:	0b650513          	addi	a0,a0,182 # 800078f8 <digits+0x20>
    8000584a:	cadff0ef          	jal	ra,800054f6 <panic>

000000008000584e <pop_off>:

void
pop_off(void)
{
    8000584e:	1141                	addi	sp,sp,-16
    80005850:	e406                	sd	ra,8(sp)
    80005852:	e022                	sd	s0,0(sp)
    80005854:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80005856:	d90fb0ef          	jal	ra,80000de6 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000585a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000585e:	8b89                	andi	a5,a5,2
  if(intr_get())
    80005860:	e78d                	bnez	a5,8000588a <pop_off+0x3c>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80005862:	5d3c                	lw	a5,120(a0)
    80005864:	02f05963          	blez	a5,80005896 <pop_off+0x48>
    panic("pop_off");
  c->noff -= 1;
    80005868:	37fd                	addiw	a5,a5,-1
    8000586a:	0007871b          	sext.w	a4,a5
    8000586e:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80005870:	eb09                	bnez	a4,80005882 <pop_off+0x34>
    80005872:	5d7c                	lw	a5,124(a0)
    80005874:	c799                	beqz	a5,80005882 <pop_off+0x34>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80005876:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000587a:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000587e:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80005882:	60a2                	ld	ra,8(sp)
    80005884:	6402                	ld	s0,0(sp)
    80005886:	0141                	addi	sp,sp,16
    80005888:	8082                	ret
    panic("pop_off - interruptible");
    8000588a:	00002517          	auipc	a0,0x2
    8000588e:	07650513          	addi	a0,a0,118 # 80007900 <digits+0x28>
    80005892:	c65ff0ef          	jal	ra,800054f6 <panic>
    panic("pop_off");
    80005896:	00002517          	auipc	a0,0x2
    8000589a:	08250513          	addi	a0,a0,130 # 80007918 <digits+0x40>
    8000589e:	c59ff0ef          	jal	ra,800054f6 <panic>

00000000800058a2 <release>:
{
    800058a2:	1101                	addi	sp,sp,-32
    800058a4:	ec06                	sd	ra,24(sp)
    800058a6:	e822                	sd	s0,16(sp)
    800058a8:	e426                	sd	s1,8(sp)
    800058aa:	1000                	addi	s0,sp,32
    800058ac:	84aa                	mv	s1,a0
  if(!holding(lk))
    800058ae:	ef3ff0ef          	jal	ra,800057a0 <holding>
    800058b2:	c105                	beqz	a0,800058d2 <release+0x30>
  lk->cpu = 0;
    800058b4:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    800058b8:	0ff0000f          	fence
  __sync_lock_release(&lk->locked);
    800058bc:	0f50000f          	fence	iorw,ow
    800058c0:	0804a02f          	amoswap.w	zero,zero,(s1)
  pop_off();
    800058c4:	f8bff0ef          	jal	ra,8000584e <pop_off>
}
    800058c8:	60e2                	ld	ra,24(sp)
    800058ca:	6442                	ld	s0,16(sp)
    800058cc:	64a2                	ld	s1,8(sp)
    800058ce:	6105                	addi	sp,sp,32
    800058d0:	8082                	ret
    panic("release");
    800058d2:	00002517          	auipc	a0,0x2
    800058d6:	04e50513          	addi	a0,a0,78 # 80007920 <digits+0x48>
    800058da:	c1dff0ef          	jal	ra,800054f6 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	8282                	jr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
